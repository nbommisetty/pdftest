cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [];
  module.exports.metadata = {
    "cordova-plugin-remote-injection": "0.5.2"
  };
});