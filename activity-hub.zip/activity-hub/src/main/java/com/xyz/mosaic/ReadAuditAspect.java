package com.xyz.mosaic;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Aspect
@Component
public class ReadAuditAspect {

    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;
    
    @Value("${KAFKA_AUDIT_READ_TOPIC:activityhub.access-logs.v1}")
    private String topic;

    public ReadAuditAspect(KafkaTemplate<String, String> kafkaTemplate, ObjectMapper objectMapper) {
        this.kafkaTemplate = kafkaTemplate;
        this.objectMapper = objectMapper;
    }

    @Async // Forces execution off the main associate HTTP request thread
    @AfterReturning(value = "@annotation(auditAnnotation)", returning = "result")
    public void logReadAccess(JoinPoint joinPoint, AuditReadLog auditAnnotation, Object result) {
        try {
            // 1. Extract context
            String associateId = SecurityContextHolder.getContext().getAuthentication().getName();
            String sessionId = "extract-from-request-context"; // Fetch from WebRequest/Filter
            
            // 2. Build the payload
            Map<String, Object> payload = new HashMap<>();
            payload.put("eventId", UUID.randomUUID().toString());
            payload.put("associateId", associateId);
            payload.put("sessionId", sessionId);
            payload.put("actionType", auditAnnotation.action());
            payload.put("timestamp", Instant.now().toString());
            
            // 3. Serialize and Send
            String jsonPayload = objectMapper.writeValueAsString(payload);
            kafkaTemplate.send(topic, sessionId, jsonPayload); // Partition by sessionId
            
        } catch (Exception e) {
            // Log locally. Do not throw exception back to the user, this is a passive audit.
            System.err.println("Failed to publish read audit log: " + e.getMessage());
        }
    }
}