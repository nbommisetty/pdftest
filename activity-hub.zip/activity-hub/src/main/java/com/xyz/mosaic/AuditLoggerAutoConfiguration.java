package com.xyz.mosaic;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.mosaic.audit")
public class AuditLoggerAutoConfiguration {
    // Spring will automatically load the Aspect, Kafka Config, and Outbox Listener
}