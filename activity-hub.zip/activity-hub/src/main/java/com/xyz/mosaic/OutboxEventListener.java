package com.xyz.mosaic;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

@Component
public class OutboxEventListener {

    private final OutboxRepository outboxRepository;
    private final ObjectMapper objectMapper;

    public OutboxEventListener(OutboxRepository outboxRepository, ObjectMapper objectMapper) {
        this.outboxRepository = outboxRepository;
        this.objectMapper = objectMapper;
    }

    // Triggers exactly when Hibernate prepares to flush the SQL, before the commit
    @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
    public void captureDomainEvent(DomainEvent event) {
        try {
            OutboxEntity outbox = new OutboxEntity();
            outbox.setAggregateId(event.getAggregateId());
            outbox.setAggregateType(event.getAggregateType());
            outbox.setEventType(event.getEventType());
            
            // Runtime serialization captures all custom fields added by the domain teams
            outbox.setPayload(objectMapper.writeValueAsString(event));
            
            outboxRepository.save(outbox);
        } catch (JsonProcessingException e) {
            // If serialization fails, we MUST throw a RuntimeException to rollback the 
            // entire business transaction. We cannot save data without the audit trail.
            throw new AuditSerializationException("Failed to serialize Outbox payload", e);
        }
    }
}
