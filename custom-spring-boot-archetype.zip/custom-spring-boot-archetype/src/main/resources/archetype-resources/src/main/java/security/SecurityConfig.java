package ${package}.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final HmacAuthFilter hmacAuthFilter;

    public SecurityConfig(HmacAuthFilter hmacAuthFilter) {
        this.hmacAuthFilter = hmacAuthFilter;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // 1. Disable CSRF since we are a stateless API
            .csrf(AbstractHttpConfigurer::disable)
            
            // 2. Disable Sessions (No JSESSIONID cookies)
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            
            // 3. Define Public vs Private endpoints
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/actuator/**", "/swagger-ui/**", "/v3/api-docs/**").permitAll()
                .anyRequest().authenticated()
            )
            
            // 4. Inject our custom HMAC filter BEFORE the standard authentication filter
            .addFilterBefore(hmacAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
