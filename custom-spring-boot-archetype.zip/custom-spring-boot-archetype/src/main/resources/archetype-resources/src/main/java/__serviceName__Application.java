#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
#if( $serviceName == "AppService" )
  #set( $parts = $artifactId.split("-") )
  #set( $pascalName = "" )
  #foreach($part in $parts)
    #set( $pascalName = "${pascalName}$part.substring(0,1).toUpperCase()$part.substring(1)" )
  #end
#else
  #set( $pascalName = $serviceName )
#end
package ${package};

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ${pascalName}Application {

    public static void main(String[] args) {
        SpringApplication.run(${pascalName}Application.class, args);
    }
}
