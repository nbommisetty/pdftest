#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
#if( $serviceName == "AppService" )
  #set( $parts = $artifactId.split("-") )
  #set( $pascalName = "" )
  #foreach($part in $parts)
    #set( $pascalName = "${pascalName}$part.substring(0,1).toUpperCase()$part.substring(1)" )
  #end
#else
  #set( $pascalName = $serviceName )
#end
package ${package}.service;

public interface ${pascalName}Service {
    
    /**
     * Standard health check method.
     */
    String getServiceStatus();
    
    // Add additional unversioned business logic methods here
}
