package ${package}.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Component
public class HmacAuthFilter extends OncePerRequestFilter {

    private static final String HMAC_ALGO = "HmacSHA256";
    private static final String SIGNATURE_HEADER = "X-HMAC-Signature";
    private static final String TIMESTAMP_HEADER = "X-Timestamp";
    
    // Injecting the secret from application.yml
    @Value("${symbol_dollar}{mosaic.security.hmac.secret}")
    private String hmacSecret;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) 
            throws ServletException, IOException {
            
        // 1. Wrap the request so the body can be read multiple times
        ContentCachingRequestWrapper wrappedRequest = new ContentCachingRequestWrapper(request);

        // Allow Swagger and Actuator health checks to bypass HMAC
        String path = wrappedRequest.getRequestURI();
        if (path.startsWith("/swagger-ui") || path.startsWith("/v3/api-docs") || path.startsWith("/actuator")) {
            filterChain.doFilter(wrappedRequest, response);
            return;
        }

        // 2. Extract Headers
        String providedSignature = wrappedRequest.getHeader(SIGNATURE_HEADER);
        String timestamp = wrappedRequest.getHeader(TIMESTAMP_HEADER);

        if (providedSignature == null || timestamp == null) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Missing HMAC Headers");
            return;
        }

        // Optional: Validate Timestamp to prevent Replay Attacks (e.g., within 5 minutes)
        // validateTimestamp(timestamp);

        // 3. Force the wrapper to read the body (required before calculating hash)
        wrappedRequest.getParameterMap(); 
        byte[] body = wrappedRequest.getContentAsByteArray();
        String payload = new String(body, StandardCharsets.UTF_8);

        // 4. Recreate the string to sign (Method + URI + Timestamp + Payload)
        String stringToSign = wrappedRequest.getMethod() + wrappedRequest.getRequestURI() + timestamp + payload;

        // 5. Calculate and Verify Signature
        try {
            String calculatedSignature = calculateHmac(stringToSign, hmacSecret);
            if (!calculatedSignature.equals(providedSignature)) {
                response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Invalid HMAC Signature");
                return;
            }
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error validating signature");
            return;
        }

        // 6. Continue the filter chain with the WRAPPED request
        filterChain.doFilter(wrappedRequest, response);
    }

    private String calculateHmac(String data, String secret) throws Exception {
        Mac sha256Hmac = Mac.getInstance(HMAC_ALGO);
        SecretKeySpec secretKey = new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), HMAC_ALGO);
        sha256Hmac.init(secretKey);
        byte[] hashBytes = sha256Hmac.doFinal(data.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(hashBytes);
    }
}
