#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
#if( $serviceName == "AppService" )
  #set( $parts = $artifactId.split("-") )
  #set( $pascalName = "" )
  #foreach($part in $parts)
    #set( $pascalName = "${pascalName}$part.substring(0,1).toUpperCase()$part.substring(1)" )
  #end
#else
  #set( $pascalName = $serviceName )
#end
package ${package}.controller.v1;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/${artifactId}")
public class ${pascalName}Controller {

    @GetMapping("/health")
    public String healthCheck() {
        return "${pascalName} is running!";
    }
}
