#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
#if( $serviceName == "AppService" )
  #set( $parts = $artifactId.split("-") )
  #set( $pascalName = "" )
  #foreach($part in $parts)
    #set( $pascalName = "${pascalName}$part.substring(0,1).toUpperCase()$part.substring(1)" )
  #end
#else
  #set( $pascalName = $serviceName )
#end
package ${package}.repository;

import org.springframework.stereotype.Repository;

/**
 * Standard Repository interface.
 * If using Spring Data JPA, you can change this to:
 * public interface ${pascalName}Repository extends JpaRepository<YourEntity, Long>
 */
@Repository
public interface ${pascalName}Repository {
    
    // Define your database interaction methods here
    
}
