#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
#if( $serviceName == "AppService" )
  #set( $parts = $artifactId.split("-") )
  #set( $pascalName = "" )
  #foreach($part in $parts)
    #set( $pascalName = "${pascalName}$part.substring(0,1).toUpperCase()$part.substring(1)" )
  #end
#else
  #set( $pascalName = $serviceName )
#end
package ${package}.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("${pascalName} API")
                        .version("v1")
                        .description("Interactive API documentation for the Mosaic ${pascalName} microservice."));
    }
}
