package com.yourcompany.config.service;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PageUpdateRequest { // For PUT /features/{featureId}/pages/{pageId}
    private String pageName;
    private Integer pageOrder;
    private List<FormNestedUpdateRequest> forms;
    private List<FieldNestedUpdateRequest> fields; // Fields directly on page
}