package com.yourcompany.config.service;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// Theme DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ThemeCreateRequest {
    private String themeName;
    private String themeDescription;
    private JsonNode themeData;
}