package com.yourcompany.config.service;

import java.util.List;

import com.yourcompany.config.model.Field;
import com.yourcompany.config.model.Form;

public interface FormService {
    Form getFormById(Long formId);
    Form createForm(Long pageId, FormCreateRequest request);
    void deleteForm(Long pageId, Long formId);
    List<Field> getFieldsByForm(Long formId);
}