package com.yourcompany.config.service;

import com.yourcompany.config.model.*;
import com.yourcompany.config.repository.*;

// Lombok Imports
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// --- DTOs for Request/Response (matching OpenAPI spec) ---

// Tenant DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TenantCreateRequest {
    private String tenantName;
    private Long themeId; // Optional initial theme
}






// --- Service Interfaces ---




// --- Service Implementations (Basic CRUD for scaffolding) ---

