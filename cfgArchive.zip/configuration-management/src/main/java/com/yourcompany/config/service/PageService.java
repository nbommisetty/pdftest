package com.yourcompany.config.service;

import java.util.List;

import com.yourcompany.config.model.Form;
import com.yourcompany.config.model.Page;

public interface PageService {
    Page getPageById(Long pageId);
    Page createPage(Long featureId, PageCreateRequest request);
    Page updatePage(Long featureId, Long pageId, PageUpdateRequest request);
    void deletePage(Long featureId, Long pageId);
    List<Form> getFormsByPage(Long pageId);
}