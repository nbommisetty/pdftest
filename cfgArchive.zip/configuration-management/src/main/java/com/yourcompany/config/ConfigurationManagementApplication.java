package com.yourcompany.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

// OpenAPI Imports
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.tags.Tag;

@SpringBootApplication
@EnableJpaAuditing
@OpenAPIDefinition(
    info = @Info(
        title = "Configuration Management API",
        version = "1.0.0",
        description = "REST API for managing self-service feature configurations across tenants, applications, and user roles."
    ),
    tags = { // Define the order of tags for Swagger UI display
        @Tag(name = "Tenants", description = "Management of banking tenants."),
        @Tag(name = "Applications", description = "Management of banking applications (e.g., Online Banking, Mobile Banking)."),
        @Tag(name = "Features", description = "Management of self-service features (e.g., Wire Transfers, Direct Deposits)."),
        @Tag(name = "Pages", description = "Management of pages within features."),
        @Tag(name = "Forms", description = "Management of forms within pages."),
        @Tag(name = "Fields", description = "Management of fields within forms or directly on pages."),
        @Tag(name = "User Roles", description = "Management of user roles within applications."),
        @Tag(name = "Themes", description = "Management of UI themes."),
        @Tag(name = "Feature Availability", description = "Mapping which features are available in which applications."),
        @Tag(name = "Tenant Feature Configuration", description = "Managing feature enablement/disablement per tenant, application, and user role."),
        @Tag(name = "Tenant Field Configuration", description = "Managing field properties (label, validation, enablement) per tenant and application."),
        @Tag(name = "Tenant Theme Configuration", description = "Managing default and hierarchical UI theme overrides for tenants.")
    }
)
public class ConfigurationManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConfigurationManagementApplication.class, args);
    }

}