package com.yourcompany.config.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yourcompany.config.model.Field;
import com.yourcompany.config.model.Form;
import com.yourcompany.config.model.Page;
import com.yourcompany.config.repository.FeatureRepository;
import com.yourcompany.config.repository.FieldRepository;
import com.yourcompany.config.repository.FormRepository;
import com.yourcompany.config.repository.PageRepository;
import com.yourcompany.config.exception.*;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PageServiceImpl implements PageService {
    private final PageRepository pageRepository;
    private final FormRepository formRepository;
    private final FieldRepository fieldRepository;
    private final FeatureRepository featureRepository; // To validate featureId

    @Override
    public Page getPageById(Long pageId) {
        return pageRepository.findById(pageId)
                .orElseThrow(() -> new ResourceNotFoundException("Page not found with ID: " + pageId));
    }

    @Override
    @Transactional
    public Page createPage(Long featureId, PageCreateRequest request) {
        if (!featureRepository.existsById(featureId)) {
            throw new ResourceNotFoundException("Feature not found with ID: " + featureId);
        }
        if (pageRepository.findByFeatureIdAndPageName(featureId, request.getPageName()).isPresent()) {
            throw new ResourceConflictException("Page with name '" + request.getPageName() + "' already exists for feature ID: " + featureId);
        }

        Page page = new Page();
        page.setFeatureId(featureId);
        page.setPageName(request.getPageName());
        page.setPageOrder(request.getPageOrder());
        page.setCreatedBy("system_init");
        page.setUpdatedBy("system_init");
        return pageRepository.save(page);
    }

    @Override
    @Transactional
    public Page updatePage(Long featureId, Long pageId, PageUpdateRequest request) {
        Page existingPage = getPageById(pageId);

        // Validate featureId consistency if provided in path
        if (!existingPage.getFeatureId().equals(featureId)) {
            throw new BadRequestException("Page ID " + pageId + " does not belong to Feature ID " + featureId);
        }

        // Handle page name uniqueness if changed
        if (!existingPage.getPageName().equals(request.getPageName())) {
            if (pageRepository.findByFeatureIdAndPageName(featureId, request.getPageName()).isPresent()) {
                throw new ResourceConflictException("Page with name '" + request.getPageName() + "' already exists for feature ID: " + featureId);
            }
        }

        existingPage.setPageName(request.getPageName());
        existingPage.setPageOrder(request.getPageOrder());
        existingPage.setUpdatedBy("system_update");
        Page savedPage = pageRepository.save(existingPage);

        // --- Handle nested forms ---
        if (request.getForms() != null) {
            // Get existing forms for this page
            List<Form> existingForms = formRepository.findByPageId(pageId);
            Set<Long> updatedOrCreatedFormIds = new HashSet<>();

            for (FormNestedUpdateRequest formRequest : request.getForms()) {
                if (Boolean.TRUE.equals(formRequest.get_delete())) {
                    if (formRequest.getFormId() != null) {
                        formRepository.deleteById(formRequest.getFormId());
                    } // else: new form marked for delete, ignore
                } else if (formRequest.getFormId() != null) {
                    // Update existing form
                    Form existingForm = formRepository.findById(formRequest.getFormId())
                            .orElseThrow(() -> new ResourceNotFoundException("Form not found with ID: " + formRequest.getFormId()));
                    if (!existingForm.getPageId().equals(pageId)) {
                        throw new BadRequestException("Form ID " + formRequest.getFormId() + " does not belong to Page ID " + pageId);
                    }
                    existingForm.setFormName(formRequest.getFormName());
                    existingForm.setFormOrder(formRequest.getFormOrder());
                    existingForm.setUpdatedBy("system_update_nested");
                    formRepository.save(existingForm);
                    updatedOrCreatedFormIds.add(existingForm.getFormId());
                    // Handle nested fields under this form
                    if (formRequest.getFields() != null) {
                        handleNestedFields(existingForm.getFormId(), formRequest.getFields());
                    }
                } else {
                    // Create new form
                    if (formRepository.findByPageIdAndFormName(pageId, formRequest.getFormName()).isPresent()) {
                        throw new ResourceConflictException("Form with name '" + formRequest.getFormName() + "' already exists for page ID: " + pageId);
                    }
                    Form newForm = new Form();
                    newForm.setPageId(pageId);
                    newForm.setFormName(formRequest.getFormName());
                    newForm.setFormOrder(formRequest.getFormOrder());
                    newForm.setCreatedBy("system_create_nested");
                    newForm.setUpdatedBy("system_create_nested");
                    Form createdForm = formRepository.save(newForm);
                    updatedOrCreatedFormIds.add(createdForm.getFormId());
                    // Handle nested fields for newly created form
                    if (formRequest.getFields() != null) {
                        handleNestedFields(createdForm.getFormId(), formRequest.getFields());
                    }
                }
            }
            // Delete forms that existed but were not in the request and not explicitly marked for delete
            List<Form> formsToDelete = existingForms.stream()
                    .filter(f -> !updatedOrCreatedFormIds.contains(f.getFormId()))
                    .collect(Collectors.toList());
            formRepository.deleteAll(formsToDelete);
        } else {
             // If forms array is null, client didn't send updates for forms. Do nothing or clear all forms
             // For PUT, usually means clear all forms. Depends on exact semantics.
             // For simplicity in this scaffold, if array is null, we assume no change to forms.
             // If it's an empty array, it means delete all existing forms for this page.
             if (request.getForms() != null && request.getForms().isEmpty()) {
                 formRepository.deleteAll(formRepository.findByPageId(pageId));
             }
        }

        return savedPage;
    }

    @Override
    @Transactional
    public void deletePage(Long featureId, Long pageId) {
        Page page = getPageById(pageId);
        if (!page.getFeatureId().equals(featureId)) {
            throw new BadRequestException("Page ID " + pageId + " does not belong to Feature ID " + featureId);
        }
        // Due to ON DELETE CASCADE in DBML, associated forms and fields will be deleted automatically.
        // Also TenantApplicationFieldConfig entries for these fields will be deleted.
        pageRepository.delete(page);
    }

    @Override
    public List<Form> getFormsByPage(Long pageId) {
        return formRepository.findByPageId(pageId);
    }

    // Helper for nested field updates (for fields inside forms)
    private void handleNestedFields(Long formId, List<FieldNestedUpdateRequest> fieldRequests) {
        // Get existing fields for this formId
        List<Field> existingFields = fieldRepository.findByFormId(formId);
        Set<Long> updatedOrCreatedFieldIds = new HashSet<>();

        for (FieldNestedUpdateRequest fieldRequest : fieldRequests) {
            if (Boolean.TRUE.equals(fieldRequest.get_delete())) {
                if (fieldRequest.getFieldId() != null) {
                    fieldRepository.deleteById(fieldRequest.getFieldId());
                }
            } else if (fieldRequest.getFieldId() != null) {
                // Update existing field
                Field existingField = fieldRepository.findById(fieldRequest.getFieldId())
                        .orElseThrow(() -> new ResourceNotFoundException("Field not found with ID: " + fieldRequest.getFieldId()));
                if (!existingField.getFormId().equals(formId)) {
                    throw new BadRequestException("Field ID " + fieldRequest.getFieldId() + " does not belong to Form ID " + formId);
                }
                updateFieldFromRequest(existingField, fieldRequest);
                existingField.setUpdatedBy("system_update_nested");
                fieldRepository.save(existingField);
                updatedOrCreatedFieldIds.add(existingField.getFieldId());
            } else {
                // Create new field
                if (fieldRepository.findByFormIdAndFieldName(formId, fieldRequest.getFieldName()).isPresent()) {
                    throw new ResourceConflictException("Field with name '" + fieldRequest.getFieldName() + "' already exists for form ID: " + formId);
                }
                Field newField = new Field();
                newField.setFormId(formId);
                //newField.setPageId(formRepository.findById(formId).get().getPageId()); // Derive pageId from formId
                updateFieldFromRequest(newField, fieldRequest);
                newField.setCreatedBy("system_create_nested");
                newField.setUpdatedBy("system_create_nested");
                Field createdField = fieldRepository.save(newField);
                updatedOrCreatedFieldIds.add(createdField.getFieldId());
            }
        }
        // Delete fields that existed but were not in the request and not explicitly marked for delete
        List<Field> fieldsToDelete = existingFields.stream()
                .filter(f -> !updatedOrCreatedFieldIds.contains(f.getFieldId()))
                .collect(Collectors.toList());
        fieldRepository.deleteAll(fieldsToDelete);
    }

    private void updateFieldFromRequest(Field field, FieldNestedUpdateRequest request) {
        field.setFieldName(request.getFieldName());
        field.setFieldType(request.getFieldType());
        field.setInputType(request.getInputType());
        field.setDefaultLabel(request.getDefaultLabel());
        field.setDefaultValidationRules(request.getDefaultValidationRules());
    }
}