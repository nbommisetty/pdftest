package com.yourcompany.config.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yourcompany.config.model.Field;
import com.yourcompany.config.model.Form;
import com.yourcompany.config.repository.FieldRepository;
import com.yourcompany.config.repository.FormRepository;
import com.yourcompany.config.repository.PageRepository;
import com.yourcompany.config.exception.*;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class FormServiceImpl implements FormService {
    private final FormRepository formRepository;
    private final PageRepository pageRepository; // To validate pageId
    private final FieldRepository fieldRepository;

    @Override
    public Form getFormById(Long formId) {
        return formRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Form not found with ID: " + formId));
    }

    @Override
    @Transactional
    public Form createForm(Long pageId, FormCreateRequest request) {
        if (!pageRepository.existsById(pageId)) {
            throw new ResourceNotFoundException("Page not found with ID: " + pageId);
        }
        if (formRepository.findByPageIdAndFormName(pageId, request.getFormName()).isPresent()) {
            throw new ResourceConflictException("Form with name '" + request.getFormName() + "' already exists for page ID: " + pageId);
        }

        Form form = new Form();
        form.setPageId(pageId);
        form.setFormName(request.getFormName());
        form.setFormOrder(request.getFormOrder());
        form.setCreatedBy("system_init");
        form.setUpdatedBy("system_init");
        return formRepository.save(form);
    }

    @Override
    @Transactional
    public void deleteForm(Long pageId, Long formId) {
        Form form = getFormById(formId);
        if (!form.getPageId().equals(pageId)) {
            throw new BadRequestException("Form ID " + formId + " does not belong to Page ID " + pageId);
        }
        // Due to ON DELETE CASCADE in DBML, associated fields will be deleted automatically.
        // Also TenantApplicationFieldConfig entries for these fields will be deleted.
        formRepository.delete(form);
    }

    @Override
    public List<Field> getFieldsByForm(Long formId) {
        return fieldRepository.findByFormId(formId);
    }
}