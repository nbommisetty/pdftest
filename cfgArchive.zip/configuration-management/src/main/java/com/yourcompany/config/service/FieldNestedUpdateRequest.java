package com.yourcompany.config.service;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// Field Nested DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FieldNestedUpdateRequest {
    private Long fieldId; // Null if new field
    private String fieldName;
    private String fieldType;
    private String inputType;
    private String defaultLabel;
    private JsonNode defaultValidationRules;
    private Boolean _delete; // Flag for deletion
}