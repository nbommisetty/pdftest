package com.yourcompany.config.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yourcompany.config.model.TenantApplicationFieldConfig;
import com.yourcompany.config.repository.ApplicationRepository;
import com.yourcompany.config.repository.FieldRepository;
import com.yourcompany.config.repository.TenantApplicationFieldConfigRepository;
import com.yourcompany.config.repository.TenantRepository;
import com.yourcompany.config.exception.*;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TenantApplicationFieldConfigServiceImpl implements TenantApplicationFieldConfigService {
    private final TenantApplicationFieldConfigRepository configRepository;
    private final TenantRepository tenantRepository;
    private final ApplicationRepository applicationRepository;
    private final FieldRepository fieldRepository;

    @Override
    public TenantApplicationFieldConfig getConfig(Long tenantId, Long applicationId, Long fieldId) {
        return configRepository.findByTenantIdAndApplicationIdAndFieldId(tenantId, applicationId, fieldId)
                .orElseThrow(() -> new ResourceNotFoundException("Config not found for Tenant: " + tenantId + ", App: " + applicationId + ", Field: " + fieldId));
    }

    @Override
    @Transactional
    public TenantApplicationFieldConfig createOrUpdateConfig(Long tenantId, Long applicationId, Long fieldId, TenantApplicationFieldConfigUpdateRequest request) {
        validateConfigDependencies(tenantId, applicationId, fieldId);

        Optional<TenantApplicationFieldConfig> existingConfig = configRepository.findByTenantIdAndApplicationIdAndFieldId(tenantId, applicationId, fieldId);
        TenantApplicationFieldConfig config = existingConfig.orElseGet(TenantApplicationFieldConfig::new);

        boolean isNew = config.getConfigId() == null;

        config.setTenantId(tenantId);
        config.setApplicationId(applicationId);
        config.setFieldId(fieldId);
        config.setIsEnabled(request.getIsEnabled());
        config.setCustomLabel(request.getCustomLabel());
        config.setCustomValidationRules(request.getCustomValidationRules());

        if (isNew) {
            config.setCreatedBy("system_config_create");
        }
        config.setUpdatedBy("system_config_update");

        return configRepository.save(config);
    }

    @Override
    @Transactional
    public TenantApplicationFieldConfig patchConfig(Long tenantId, Long applicationId, Long fieldId, TenantApplicationFieldConfigPatchRequest request) {
        TenantApplicationFieldConfig existingConfig = getConfig(tenantId, applicationId, fieldId);

        if (request.getIsEnabled() != null) {
            existingConfig.setIsEnabled(request.getIsEnabled());
        }
        if (request.getCustomLabel() != null) {
            existingConfig.setCustomLabel(request.getCustomLabel());
        }
        if (request.getCustomValidationRules() != null) {
            existingConfig.setCustomValidationRules(request.getCustomValidationRules());
        }

        existingConfig.setUpdatedBy("system_config_patch");
        return configRepository.save(existingConfig);
    }

    @Override
    @Transactional
    public void deleteConfig(Long tenantId, Long applicationId, Long fieldId) {
        TenantApplicationFieldConfig config = getConfig(tenantId, applicationId, fieldId);
        configRepository.delete(config);
    }

    @Override
    public List<TenantApplicationFieldConfig> getConfigsByTenantApp(Long tenantId, Long applicationId) {
        return configRepository.findByTenantIdAndApplicationId(tenantId, applicationId);
    }

    private void validateConfigDependencies(Long tenantId, Long applicationId, Long fieldId) {
        tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant not found with ID: " + tenantId));
        applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found with ID: " + applicationId));
        fieldRepository.findById(fieldId)
                .orElseThrow(() -> new ResourceNotFoundException("Field not found with ID: " + fieldId));
    }
}