package com.yourcompany.config.service;

import java.util.List;

import com.yourcompany.config.model.Theme;

public interface ThemeService {
    List<Theme> getAllThemes();
    Theme getThemeById(Long themeId);
    Theme createTheme(ThemeCreateRequest request);
    Theme updateTheme(Long themeId, ThemeUpdateRequest request);
    Theme patchTheme(Long themeId, ThemePatchRequest request);
    void deleteTheme(Long themeId);
}