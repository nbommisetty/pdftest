package com.yourcompany.config.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// Feature DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FeatureCreateRequest {
    private String featureName;
    private String featureDescription;
}