package com.yourcompany.config.model;

import com.fasterxml.jackson.annotation.JsonRawValue;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "TenantApplicationFeatureConfig")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class TenantApplicationFeatureConfig extends AuditableEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "config_id")
    private Long configId;

    @NotNull
    @Column(name = "tenant_id", nullable = false)
    private Long tenantId; // FK to Tenant

    @NotNull
    @Column(name = "application_id", nullable = false)
    private Long applicationId; // FK to Application

    @Column(name = "role_id")
    private Long roleId; // FK to UserRole, nullable

    @NotNull
    @Column(name = "feature_id", nullable = false)
    private Long featureId; // FK to Feature

    @NotNull
    @Column(name = "is_enabled", nullable = false)
    private Boolean isEnabled;

    @Column(name = "theme_id")
    private Long themeId; // FK to Theme, nullable
}
