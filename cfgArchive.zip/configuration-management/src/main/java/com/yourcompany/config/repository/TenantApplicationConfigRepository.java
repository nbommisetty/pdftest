package com.yourcompany.config.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yourcompany.config.model.TenantApplicationConfig;

@Repository
public interface TenantApplicationConfigRepository extends JpaRepository<TenantApplicationConfig, Long> {
    // For the specific Tenant+Application Theme config
    Optional<TenantApplicationConfig> findByTenantIdAndApplicationId(Long tenantId, Long applicationId);
}