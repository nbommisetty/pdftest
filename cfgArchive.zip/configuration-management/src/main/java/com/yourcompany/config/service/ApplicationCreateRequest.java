package com.yourcompany.config.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// Application DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationCreateRequest {
    private String applicationName;
    private String applicationDescription;
}