package com.yourcompany.config.service;

import java.util.List;

import com.yourcompany.config.model.Tenant;
import com.yourcompany.config.model.Theme;

public interface TenantService {
    List<Tenant> getAllTenants(String tenantNameFilter, int page, int size);
    Tenant getTenantById(Long tenantId);
    Tenant createTenant(TenantCreateRequest request);
    Tenant updateTenant(Long tenantId, TenantUpdateRequest request);
    void deleteTenant(Long tenantId);
    Theme getTenantDefaultTheme(Long tenantId);
    Tenant setTenantDefaultTheme(Long tenantId, Long themeId);
}