package com.yourcompany.config.service;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TenantApplicationFeatureConfigPatchRequest {
    private Boolean isEnabled;
    private Long themeId; // Nullable
}