package com.yourcompany.config.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yourcompany.config.model.Feature;
import com.yourcompany.config.model.Page;
import com.yourcompany.config.repository.FeatureRepository;
import com.yourcompany.config.repository.PageRepository;
import com.yourcompany.config.exception.*;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class FeatureServiceImpl implements FeatureService {
    private final FeatureRepository featureRepository;
    private final PageRepository pageRepository; // To support getPagesByFeature

    @Override
    public List<Feature> getAllFeatures() {
        return featureRepository.findAll();
    }

    @Override
    public Feature getFeatureById(Long featureId) {
        return featureRepository.findById(featureId)
                .orElseThrow(() -> new ResourceNotFoundException("Feature not found with ID: " + featureId));
    }

    @Override
    @Transactional
    public Feature createFeature(FeatureCreateRequest request) {
        if (featureRepository.findByFeatureName(request.getFeatureName()).isPresent()) {
            throw new ResourceConflictException("Feature with name '" + request.getFeatureName() + "' already exists.");
        }
        Feature feature = new Feature();
        feature.setFeatureName(request.getFeatureName());
        feature.setFeatureDescription(request.getFeatureDescription());
        feature.setCreatedBy("system_init");
        feature.setUpdatedBy("system_init");
        return featureRepository.save(feature);
    }

    @Override
    @Transactional
    public Feature updateFeature(Long featureId, FeatureUpdateRequest request) {
        Feature existingFeature = getFeatureById(featureId);
        if (!existingFeature.getFeatureName().equals(request.getFeatureName())) {
            if (featureRepository.findByFeatureName(request.getFeatureName()).isPresent()) {
                throw new ResourceConflictException("Feature with name '" + request.getFeatureName() + "' already exists.");
            }
        }
        existingFeature.setFeatureName(request.getFeatureName());
        existingFeature.setFeatureDescription(request.getFeatureDescription());
        existingFeature.setUpdatedBy("system_update");
        return featureRepository.save(existingFeature);
    }

    @Override
    @Transactional
    public Feature patchFeature(Long featureId, FeaturePatchRequest request) {
        Feature existingFeature = getFeatureById(featureId);
        if (request.getFeatureName() != null && !existingFeature.getFeatureName().equals(request.getFeatureName())) {
            if (featureRepository.findByFeatureName(request.getFeatureName()).isPresent()) {
                throw new ResourceConflictException("Feature with name '" + request.getFeatureName() + "' already exists.");
            }
            existingFeature.setFeatureName(request.getFeatureName());
        }
        if (request.getFeatureDescription() != null) {
            existingFeature.setFeatureDescription(request.getFeatureDescription());
        }
        existingFeature.setUpdatedBy("system_patch");
        return featureRepository.save(existingFeature);
    }

    @Override
    @Transactional
    public void deleteFeature(Long featureId) {
        if (!featureRepository.existsById(featureId)) {
            throw new ResourceNotFoundException("Feature not found with ID: " + featureId);
        }
        featureRepository.deleteById(featureId);
    }

    @Override
    public List<Page> getPagesByFeature(Long featureId) {
        return pageRepository.findByFeatureId(featureId);
    }
}