package com.yourcompany.config.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yourcompany.config.model.Page;

@Repository
public interface PageRepository extends JpaRepository<Page, Long> {
    // Custom query to find page by featureId and pageName (unique index)
    Optional<Page> findByFeatureIdAndPageName(Long featureId, String pageName);

    List<Page> findByFeatureId(Long featureId);
}