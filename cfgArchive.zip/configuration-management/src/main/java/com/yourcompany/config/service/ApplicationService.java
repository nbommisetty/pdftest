package com.yourcompany.config.service;

import java.util.List;

import com.yourcompany.config.model.Application;
import com.yourcompany.config.model.Feature;
import com.yourcompany.config.model.FeatureApplication;

public interface ApplicationService {
    List<Application> getAllApplications();
    Application getApplicationById(Long applicationId);
    Application createApplication(ApplicationCreateRequest request);
    Application updateApplication(Long applicationId, ApplicationUpdateRequest request);
    Application patchApplication(Long applicationId, ApplicationPatchRequest request);
    void deleteApplication(Long applicationId);
    List<Feature> getFeaturesByApplication(Long applicationId);
    FeatureApplication addFeatureToApplication(Long applicationId, Long featureId);
    void removeFeatureFromApplication(Long applicationId, Long featureId);
}