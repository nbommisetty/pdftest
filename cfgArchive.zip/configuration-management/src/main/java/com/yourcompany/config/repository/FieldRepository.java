package com.yourcompany.config.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yourcompany.config.model.Field;

@Repository
public interface FieldRepository extends JpaRepository<Field, Long> {
    // Custom query to find field by formId and fieldName (unique index)
    Optional<Field> findByFormIdAndFieldName(Long formId, String fieldName);

    List<Field> findByFormId(Long formId);
}