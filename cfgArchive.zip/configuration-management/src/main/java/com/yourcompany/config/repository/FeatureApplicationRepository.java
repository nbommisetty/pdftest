package com.yourcompany.config.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yourcompany.config.model.FeatureApplication;

@Repository
public interface FeatureApplicationRepository extends JpaRepository<FeatureApplication, Long> {
    Optional<FeatureApplication> findByFeatureIdAndApplicationId(Long featureId, Long applicationId);
    List<FeatureApplication> findByApplicationId(Long applicationId);
    List<FeatureApplication> findByFeatureId(Long featureId);
}