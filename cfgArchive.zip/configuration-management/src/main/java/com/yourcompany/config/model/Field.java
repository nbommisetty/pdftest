package com.yourcompany.config.model;

import com.fasterxml.jackson.annotation.JsonRawValue;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;

import org.hibernate.annotations.JdbcTypeCode; // NEW IMPORT
import org.hibernate.type.SqlTypes; 

@Entity
@Table(name = "Field")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class Field extends AuditableEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "field_id")
    private Long fieldId;

    @NotNull
    @Column(name = "form_id", nullable = false)
    private Long formId; // FK to Form (now required)

    @NotBlank
    @Size(max = 100)
    @Column(name = "field_name", nullable = false)
    private String fieldName;

    @NotBlank
    @Size(max = 50)
    @Column(name = "field_type", nullable = false)
    private String fieldType;

    @NotBlank
    @Size(max = 50)
    @Column(name = "input_type", nullable = false)
    private String inputType;

    @NotBlank
    @Size(max = 255)
    @Column(name = "default_label", nullable = false)
    private String defaultLabel;

    @Column(name = "default_validation_rules")
    @JdbcTypeCode(SqlTypes.JSON) // NEW: Use SqlTypes.JSON for JSONB mapping
    private JsonNode defaultValidationRules;
}
