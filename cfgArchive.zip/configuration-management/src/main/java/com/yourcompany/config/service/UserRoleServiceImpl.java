package com.yourcompany.config.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yourcompany.config.model.UserRole;
import com.yourcompany.config.repository.UserRoleRepository;
import com.yourcompany.config.exception.*;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserRoleServiceImpl implements UserRoleService {
    private final UserRoleRepository userRoleRepository;

    @Override
    public List<UserRole> getAllUserRoles() {
        return userRoleRepository.findAll();
    }

    @Override
    public UserRole getUserRoleById(Long roleId) {
        return userRoleRepository.findById(roleId)
                .orElseThrow(() -> new ResourceNotFoundException("UserRole not found with ID: " + roleId));
    }

    @Override
    @Transactional
    public UserRole createUserRole(UserRoleCreateRequest request) {
        if (userRoleRepository.findByRoleName(request.getRoleName()).isPresent()) {
            throw new ResourceConflictException("UserRole with name '" + request.getRoleName() + "' already exists.");
        }
        UserRole userRole = new UserRole();
        userRole.setRoleName(request.getRoleName());
        userRole.setRoleDescription(request.getRoleDescription());
        userRole.setCreatedBy("system_init");
        userRole.setUpdatedBy("system_init");
        return userRoleRepository.save(userRole);
    }

    @Override
    @Transactional
    public UserRole updateUserRole(Long roleId, UserRoleUpdateRequest request) {
        UserRole existingRole = getUserRoleById(roleId);
        if (!existingRole.getRoleName().equals(request.getRoleName())) {
            if (userRoleRepository.findByRoleName(request.getRoleName()).isPresent()) {
                throw new ResourceConflictException("UserRole with name '" + request.getRoleName() + "' already exists.");
            }
        }
        existingRole.setRoleName(request.getRoleName());
        existingRole.setRoleDescription(request.getRoleDescription());
        existingRole.setUpdatedBy("system_update");
        return userRoleRepository.save(existingRole);
    }

    @Override
    @Transactional
    public UserRole patchUserRole(Long roleId, UserRolePatchRequest request) {
        UserRole existingRole = getUserRoleById(roleId);
        if (request.getRoleName() != null && !existingRole.getRoleName().equals(request.getRoleName())) {
            if (userRoleRepository.findByRoleName(request.getRoleName()).isPresent()) {
                throw new ResourceConflictException("UserRole with name '" + request.getRoleName() + "' already exists.");
            }
            existingRole.setRoleName(request.getRoleName());
        }
        if (request.getRoleDescription() != null) {
            existingRole.setRoleDescription(request.getRoleDescription());
        }
        existingRole.setUpdatedBy("system_patch");
        return userRoleRepository.save(existingRole);
    }

    @Override
    @Transactional
    public void deleteUserRole(Long roleId) {
        if (!userRoleRepository.existsById(roleId)) {
            throw new ResourceNotFoundException("UserRole not found with ID: " + roleId);
        }
        userRoleRepository.deleteById(roleId);
    }
}