package com.yourcompany.config.service;

import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yourcompany.config.model.TenantApplicationConfig;
import com.yourcompany.config.repository.ApplicationRepository;
import com.yourcompany.config.repository.TenantApplicationConfigRepository;
import com.yourcompany.config.repository.TenantRepository;
import com.yourcompany.config.repository.ThemeRepository;
import com.yourcompany.config.exception.*;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TenantApplicationConfigServiceImpl implements TenantApplicationConfigService {
    private final TenantApplicationConfigRepository configRepository;
    private final TenantRepository tenantRepository;
    private final ApplicationRepository applicationRepository;
    private final ThemeRepository themeRepository;

    @Override
    public TenantApplicationConfig getThemeConfig(Long tenantId, Long applicationId) {
        return configRepository.findByTenantIdAndApplicationId(tenantId, applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Theme config not found for Tenant: " + tenantId + ", App: " + applicationId));
    }

    @Override
    @Transactional
    public TenantApplicationConfig createOrUpdateThemeConfig(Long tenantId, Long applicationId, TenantApplicationThemeConfigUpdateRequest request) {
        validateThemeConfigDependencies(tenantId, applicationId, request.getThemeId());

        Optional<TenantApplicationConfig> existingConfig = configRepository.findByTenantIdAndApplicationId(tenantId, applicationId);
        TenantApplicationConfig config = existingConfig.orElseGet(TenantApplicationConfig::new);

        boolean isNew = config.getConfigId() == null;

        config.setTenantId(tenantId);
        config.setApplicationId(applicationId);
        config.setThemeId(request.getThemeId());

        if (isNew) {
            config.setCreatedBy("system_theme_config_create");
        }
        config.setUpdatedBy("system_theme_config_update");

        return configRepository.save(config);
    }

    @Override
    @Transactional
    public TenantApplicationConfig patchThemeConfig(Long tenantId, Long applicationId, TenantApplicationThemeConfigPatchRequest request) {
        TenantApplicationConfig existingConfig = getThemeConfig(tenantId, applicationId);

        if (request.getThemeId() != null) {
            if (!themeRepository.existsById(request.getThemeId())) {
                throw new BadRequestException("Invalid ThemeId: " + request.getThemeId());
            }
            existingConfig.setThemeId(request.getThemeId());
        }

        existingConfig.setUpdatedBy("system_theme_config_patch");
        return configRepository.save(existingConfig);
    }

    @Override
    @Transactional
    public void deleteThemeConfig(Long tenantId, Long applicationId) {
        TenantApplicationConfig config = getThemeConfig(tenantId, applicationId);
        configRepository.delete(config);
    }

    private void validateThemeConfigDependencies(Long tenantId, Long applicationId, Long themeId) {
        tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant not found with ID: " + tenantId));
        applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found with ID: " + applicationId));
        themeRepository.findById(themeId)
                .orElseThrow(() -> new ResourceNotFoundException("Theme not found with ID: " + themeId));
    }
}