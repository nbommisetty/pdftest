package com.yourcompany.config.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yourcompany.config.model.Theme;
import com.yourcompany.config.repository.ThemeRepository;
import com.yourcompany.config.exception.*;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ThemeServiceImpl implements ThemeService {
    private final ThemeRepository themeRepository;

    @Override
    public List<Theme> getAllThemes() {
        return themeRepository.findAll();
    }

    @Override
    public Theme getThemeById(Long themeId) {
        return themeRepository.findById(themeId)
                .orElseThrow(() -> new ResourceNotFoundException("Theme not found with ID: " + themeId));
    }

    @Override
    @Transactional
    public Theme createTheme(ThemeCreateRequest request) {
        if (themeRepository.findByThemeName(request.getThemeName()).isPresent()) {
            throw new ResourceConflictException("Theme with name '" + request.getThemeName() + "' already exists.");
        }
        Theme theme = new Theme();
        theme.setThemeName(request.getThemeName());
        theme.setThemeDescription(request.getThemeDescription());
        theme.setThemeData(request.getThemeData());
        theme.setCreatedBy("system_init");
        theme.setUpdatedBy("system_init");
        return themeRepository.save(theme);
    }

    @Override
    @Transactional
    public Theme updateTheme(Long themeId, ThemeUpdateRequest request) {
        Theme existingTheme = getThemeById(themeId);
        if (!existingTheme.getThemeName().equals(request.getThemeName())) {
            if (themeRepository.findByThemeName(request.getThemeName()).isPresent()) {
                throw new ResourceConflictException("Theme with name '" + request.getThemeName() + "' already exists.");
            }
        }
        existingTheme.setThemeName(request.getThemeName());
        existingTheme.setThemeDescription(request.getThemeDescription());
        existingTheme.setThemeData(request.getThemeData());
        existingTheme.setUpdatedBy("system_update");
        return themeRepository.save(existingTheme);
    }

    @Override
    @Transactional
    public Theme patchTheme(Long themeId, ThemePatchRequest request) {
        Theme existingTheme = getThemeById(themeId);
        if (request.getThemeName() != null && !existingTheme.getThemeName().equals(request.getThemeName())) {
            if (themeRepository.findByThemeName(request.getThemeName()).isPresent()) {
                throw new ResourceConflictException("Theme with name '" + request.getThemeName() + "' already exists.");
            }
            existingTheme.setThemeName(request.getThemeName());
        }
        if (request.getThemeDescription() != null) {
            existingTheme.setThemeDescription(request.getThemeDescription());
        }
        if (request.getThemeData() != null) {
            existingTheme.setThemeData(request.getThemeData());
        }
        existingTheme.setUpdatedBy("system_patch");
        return themeRepository.save(existingTheme);
    }

    @Override
    @Transactional
    public void deleteTheme(Long themeId) {
        if (!themeRepository.existsById(themeId)) {
            throw new ResourceNotFoundException("Theme not found with ID: " + themeId);
        }
        themeRepository.deleteById(themeId);
    }
}