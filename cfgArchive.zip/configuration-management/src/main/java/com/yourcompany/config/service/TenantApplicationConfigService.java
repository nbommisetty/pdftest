package com.yourcompany.config.service;

import com.yourcompany.config.model.TenantApplicationConfig;

public interface TenantApplicationConfigService {
    TenantApplicationConfig getThemeConfig(Long tenantId, Long applicationId);
    TenantApplicationConfig createOrUpdateThemeConfig(Long tenantId, Long applicationId, TenantApplicationThemeConfigUpdateRequest request);
    TenantApplicationConfig patchThemeConfig(Long tenantId, Long applicationId, TenantApplicationThemeConfigPatchRequest request);
    void deleteThemeConfig(Long tenantId, Long applicationId);
}