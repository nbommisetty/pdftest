package com.yourcompany.config.model;

// --- Custom Converter for JSONB (required for JsonNode mapping) ---
// This class needs to be defined in a separate file, e.g., JsonNodeConverter.java
// It handles conversion between JsonNode and String (for database persistence)
// For PostgreSQL, Spring Boot + Hibernate with 'jsonb' columnDefinition usually handles this well
// if you include 'hibernate-types' or configure custom UserType.
// For H2 (used in this scaffold), JSONB support is simulated with TEXT.
// This converter provides a generic way to manage JsonNode.


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = true)
public class JsonNodeConverter implements AttributeConverter<JsonNode, String> {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String convertToDatabaseColumn(JsonNode jsonNode) {
        if (jsonNode == null) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(jsonNode);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Error converting JsonNode to String", e);
        }
    }

    @Override
    public JsonNode convertToEntityAttribute(String jsonString) {
        if (jsonString == null || jsonString.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.readTree(jsonString);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Error converting String to JsonNode", e);
        }
    }
}

