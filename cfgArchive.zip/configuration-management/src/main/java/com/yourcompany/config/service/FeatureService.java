package com.yourcompany.config.service;

import java.util.List;

import com.yourcompany.config.model.Feature;
import com.yourcompany.config.model.Page;

public interface FeatureService {
    List<Feature> getAllFeatures();
    Feature getFeatureById(Long featureId);
    Feature createFeature(FeatureCreateRequest request);
    Feature updateFeature(Long featureId, FeatureUpdateRequest request);
    Feature patchFeature(Long featureId, FeaturePatchRequest request);
    void deleteFeature(Long featureId);
    List<Page> getPagesByFeature(Long featureId);
}