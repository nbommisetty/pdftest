package com.yourcompany.config.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yourcompany.config.model.TenantApplicationFeatureConfig;

@Repository
public interface TenantApplicationFeatureConfigRepository extends JpaRepository<TenantApplicationFeatureConfig, Long> {
    // Find by full composite key, handling nullable roleId
    Optional<TenantApplicationFeatureConfig> findByTenantIdAndApplicationIdAndRoleIdAndFeatureId(
            Long tenantId, Long applicationId, Long roleId, Long featureId);

    // Find without roleId (for unauthenticated config)
    Optional<TenantApplicationFeatureConfig> findByTenantIdAndApplicationIdAndFeatureIdAndRoleIdIsNull(
            Long tenantId, Long applicationId, Long featureId);

    List<TenantApplicationFeatureConfig> findByTenantIdAndApplicationId(Long tenantId, Long applicationId);
    List<TenantApplicationFeatureConfig> findByTenantIdAndApplicationIdAndRoleId(Long tenantId, Long applicationId, Long roleId);
    List<TenantApplicationFeatureConfig> findByTenantIdAndApplicationIdAndRoleIdIsNull(Long tenantId, Long applicationId);
}