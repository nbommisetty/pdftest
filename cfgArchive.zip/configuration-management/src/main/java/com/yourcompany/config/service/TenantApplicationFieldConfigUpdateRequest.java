package com.yourcompany.config.service;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// Tenant Application Field Config DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TenantApplicationFieldConfigUpdateRequest {
    private Boolean isEnabled;
    private String customLabel;
    private JsonNode customValidationRules;
}