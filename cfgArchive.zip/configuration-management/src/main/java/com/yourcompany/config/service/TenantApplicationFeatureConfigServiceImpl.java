package com.yourcompany.config.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yourcompany.config.model.TenantApplicationFeatureConfig;
import com.yourcompany.config.repository.ApplicationRepository;
import com.yourcompany.config.repository.FeatureApplicationRepository;
import com.yourcompany.config.repository.FeatureRepository;
import com.yourcompany.config.repository.TenantApplicationFeatureConfigRepository;
import com.yourcompany.config.repository.TenantRepository;
import com.yourcompany.config.repository.ThemeRepository;
import com.yourcompany.config.repository.UserRoleRepository;
import com.yourcompany.config.exception.*;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TenantApplicationFeatureConfigServiceImpl implements TenantApplicationFeatureConfigService {
    private final TenantApplicationFeatureConfigRepository configRepository;
    private final TenantRepository tenantRepository;
    private final ApplicationRepository applicationRepository;
    private final UserRoleRepository userRoleRepository;
    private final FeatureRepository featureRepository;
    private final ThemeRepository themeRepository;
    private final FeatureApplicationRepository featureApplicationRepository;

    @Override
    public TenantApplicationFeatureConfig getConfig(Long tenantId, Long applicationId, Long roleId, Long featureId) {
        if (roleId != null) {
            return configRepository.findByTenantIdAndApplicationIdAndRoleIdAndFeatureId(tenantId, applicationId, roleId, featureId)
                    .orElseThrow(() -> new ResourceNotFoundException("Config not found for Tenant: " + tenantId + ", App: " + applicationId + ", Role: " + roleId + ", Feature: " + featureId));
        } else {
            // Handle null roleId for unique config (requires partial index in DB)
            return configRepository.findByTenantIdAndApplicationIdAndFeatureIdAndRoleIdIsNull(tenantId, applicationId, featureId)
                    .orElseThrow(() -> new ResourceNotFoundException("Config not found for Tenant: " + tenantId + ", App: " + applicationId + ", Feature: " + featureId + " (no role)"));
        }
    }

    @Override
    @Transactional
    public TenantApplicationFeatureConfig createOrUpdateConfig(Long tenantId, Long applicationId, Long roleId, Long featureId, TenantApplicationFeatureConfigUpdateRequest request) {
        validateConfigDependencies(tenantId, applicationId, roleId, featureId, request.getThemeId());

        Optional<TenantApplicationFeatureConfig> existingConfig;
        if (roleId != null) {
            existingConfig = configRepository.findByTenantIdAndApplicationIdAndRoleIdAndFeatureId(tenantId, applicationId, roleId, featureId);
        } else {
            existingConfig = configRepository.findByTenantIdAndApplicationIdAndFeatureIdAndRoleIdIsNull(tenantId, applicationId, featureId);
        }

        TenantApplicationFeatureConfig config = existingConfig.orElseGet(TenantApplicationFeatureConfig::new);

        boolean isNew = config.getConfigId() == null;

        config.setTenantId(tenantId);
        config.setApplicationId(applicationId);
        config.setRoleId(roleId);
        config.setFeatureId(featureId);
        config.setIsEnabled(request.getIsEnabled());
        config.setThemeId(request.getThemeId());

        if (isNew) {
            config.setCreatedBy("system_config_create");
        }
        config.setUpdatedBy("system_config_update");

        return configRepository.save(config);
    }

    @Override
    @Transactional
    public TenantApplicationFeatureConfig patchConfig(Long tenantId, Long applicationId, Long roleId, Long featureId, TenantApplicationFeatureConfigPatchRequest request) {
        TenantApplicationFeatureConfig existingConfig = getConfig(tenantId, applicationId, roleId, featureId);

        if (request.getIsEnabled() != null) {
            existingConfig.setIsEnabled(request.getIsEnabled());
        }
        if (request.getThemeId() != null) {
            if (!themeRepository.existsById(request.getThemeId())) {
                throw new BadRequestException("Invalid ThemeId: " + request.getThemeId());
            }
            existingConfig.setThemeId(request.getThemeId());
        }

        existingConfig.setUpdatedBy("system_config_patch");
        return configRepository.save(existingConfig);
    }

    @Override
    @Transactional
    public void deleteConfig(Long tenantId, Long applicationId, Long roleId, Long featureId) {
        TenantApplicationFeatureConfig config = getConfig(tenantId, applicationId, roleId, featureId);
        configRepository.delete(config);
    }

    @Override
    public List<TenantApplicationFeatureConfig> getConfigsByTenantApp(Long tenantId, Long applicationId, Long roleId) {
        if (roleId != null) {
            return configRepository.findByTenantIdAndApplicationIdAndRoleId(tenantId, applicationId, roleId);
        } else {
            return configRepository.findByTenantIdAndApplicationIdAndRoleIdIsNull(tenantId, applicationId);
        }
    }

    private void validateConfigDependencies(Long tenantId, Long applicationId, Long roleId, Long featureId, Long themeId) {
        tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant not found with ID: " + tenantId));
        applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found with ID: " + applicationId));
        featureRepository.findById(featureId)
                .orElseThrow(() -> new ResourceNotFoundException("Feature not found with ID: " + featureId));
        if (roleId != null) {
            userRoleRepository.findById(roleId)
                    .orElseThrow(() -> new ResourceNotFoundException("UserRole not found with ID: " + roleId));
        }
        if (themeId != null) {
            themeRepository.findById(themeId)
                    .orElseThrow(() -> new ResourceNotFoundException("Theme not found with ID: " + themeId));
        }
        // Additional validation: Ensure feature is actually associated with the application (feature_application table)
        if (featureApplicationRepository.findByFeatureIdAndApplicationId(featureId, applicationId).isEmpty()) {
             throw new BadRequestException("Feature ID " + featureId + " is not available for Application ID " + applicationId + ". Add it via /applications/{applicationId}/features first.");
        }
    }
}