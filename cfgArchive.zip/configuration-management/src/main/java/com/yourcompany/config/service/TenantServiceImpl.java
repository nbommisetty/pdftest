package com.yourcompany.config.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yourcompany.config.model.Tenant;
import com.yourcompany.config.model.Theme;
import com.yourcompany.config.repository.TenantRepository;
import com.yourcompany.config.repository.ThemeRepository;
import com.yourcompany.config.exception.*;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TenantServiceImpl implements TenantService {
    private final TenantRepository tenantRepository;
    private final ThemeRepository themeRepository; // Inject ThemeRepository to validate themeId

    @Override
    public List<Tenant> getAllTenants(String tenantNameFilter, int page, int size) {
        // Implement filtering and pagination logic
        return tenantRepository.findAll(); // Simplified for scaffold
    }

    @Override
    public Tenant getTenantById(Long tenantId) {
        return tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant not found with ID: " + tenantId));
    }

    @Override
    @Transactional
    public Tenant createTenant(TenantCreateRequest request) {
        if (tenantRepository.findByTenantName(request.getTenantName()).isPresent()) {
            throw new ResourceConflictException("Tenant with name '" + request.getTenantName() + "' already exists.");
        }
        if (request.getThemeId() != null && !themeRepository.existsById(request.getThemeId())) {
            throw new BadRequestException("Invalid ThemeId: " + request.getThemeId());
        }

        Tenant tenant = new Tenant();
        tenant.setTenantName(request.getTenantName());
        tenant.setThemeId(request.getThemeId());
        // Set createdBy/updatedBy (e.g., from SecurityContextHolder or a default value)
        tenant.setCreatedBy("system_init"); // Placeholder
        tenant.setUpdatedBy("system_init"); // Placeholder
        return tenantRepository.save(tenant);
    }

    @Override
    @Transactional
    public Tenant updateTenant(Long tenantId, TenantUpdateRequest request) {
        Tenant existingTenant = getTenantById(tenantId);

        // Check for unique name conflict if name is changed
        if (!existingTenant.getTenantName().equals(request.getTenantName())) {
            if (tenantRepository.findByTenantName(request.getTenantName()).isPresent()) {
                throw new ResourceConflictException("Tenant with name '" + request.getTenantName() + "' already exists.");
            }
        }
        if (request.getThemeId() != null && !themeRepository.existsById(request.getThemeId())) {
            throw new BadRequestException("Invalid ThemeId: " + request.getThemeId());
        }

        existingTenant.setTenantName(request.getTenantName());
        existingTenant.setThemeId(request.getThemeId());
        existingTenant.setUpdatedBy("system_update"); // Placeholder
        return tenantRepository.save(existingTenant);
    }

    @Override
    @Transactional
    public void deleteTenant(Long tenantId) {
        if (!tenantRepository.existsById(tenantId)) {
            throw new ResourceNotFoundException("Tenant not found with ID: " + tenantId);
        }
        tenantRepository.deleteById(tenantId);
    }

    @Override
    public Theme getTenantDefaultTheme(Long tenantId) {
        Tenant tenant = getTenantById(tenantId);
        if (tenant.getThemeId() == null) {
            throw new ResourceNotFoundException("No default theme configured for tenant ID: " + tenantId);
        }
        return themeRepository.findById(tenant.getThemeId())
                .orElseThrow(() -> new ResourceNotFoundException("Theme not found with ID: " + tenant.getThemeId() + " for tenant: " + tenantId));
    }

    @Override
    @Transactional
    public Tenant setTenantDefaultTheme(Long tenantId, Long themeId) {
        Tenant tenant = getTenantById(tenantId);
        if (!themeRepository.existsById(themeId)) {
            throw new ResourceNotFoundException("Theme not found with ID: " + themeId);
        }
        tenant.setThemeId(themeId);
        tenant.setUpdatedBy("system_theme_update"); // Placeholder
        return tenantRepository.save(tenant);
    }
}