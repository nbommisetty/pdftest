package com.yourcompany.config.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yourcompany.config.model.Form;

@Repository
public interface FormRepository extends JpaRepository<Form, Long> {
    // Custom query to find form by pageId and formName (unique index)
    Optional<Form> findByPageIdAndFormName(Long pageId, String formName);

    List<Form> findByPageId(Long pageId);
}