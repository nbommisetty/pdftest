package com.yourcompany.config.model;

import com.fasterxml.jackson.annotation.JsonRawValue;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;

import org.hibernate.annotations.JdbcTypeCode; // NEW IMPORT
import org.hibernate.type.SqlTypes; 

@Entity
@Table(name = "TenantApplicationFieldConfig")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class TenantApplicationFieldConfig extends AuditableEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "config_id")
    private Long configId;

    @NotNull
    @Column(name = "tenant_id", nullable = false)
    private Long tenantId; // FK to Tenant

    @NotNull
    @Column(name = "application_id", nullable = false)
    private Long applicationId; // FK to Application

    @NotNull
    @Column(name = "field_id", nullable = false)
    private Long fieldId; // FK to Field

    @NotNull
    @Column(name = "is_enabled", nullable = false)
    private Boolean isEnabled;

    @Column(name = "custom_label")
    private String customLabel;

    @Column(name = "custom_validation_rules")
    @JdbcTypeCode(SqlTypes.JSON)
    private JsonNode customValidationRules;
}
