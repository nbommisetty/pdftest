package com.yourcompany.config.service;

import java.util.List;

import com.yourcompany.config.model.TenantApplicationFeatureConfig;

public interface TenantApplicationFeatureConfigService {
    TenantApplicationFeatureConfig getConfig(Long tenantId, Long applicationId, Long roleId, Long featureId);
    TenantApplicationFeatureConfig createOrUpdateConfig(Long tenantId, Long applicationId, Long roleId, Long featureId, TenantApplicationFeatureConfigUpdateRequest request);
    TenantApplicationFeatureConfig patchConfig(Long tenantId, Long applicationId, Long roleId, Long featureId, TenantApplicationFeatureConfigPatchRequest request);
    void deleteConfig(Long tenantId, Long applicationId, Long roleId, Long featureId);
    List<TenantApplicationFeatureConfig> getConfigsByTenantApp(Long tenantId, Long applicationId, Long roleId);
}