package com.yourcompany.config.service;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// Form Nested DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FormNestedUpdateRequest {
    private Long formId; // Null if new form
    private String formName;
    private Integer formOrder;
    private Boolean _delete; // Flag for deletion
    private List<FieldNestedUpdateRequest> fields;
}