package com.yourcompany.config.service;

import java.util.List;

import com.yourcompany.config.model.TenantApplicationFieldConfig;

public interface TenantApplicationFieldConfigService {
    TenantApplicationFieldConfig getConfig(Long tenantId, Long applicationId, Long fieldId);
    TenantApplicationFieldConfig createOrUpdateConfig(Long tenantId, Long applicationId, Long fieldId, TenantApplicationFieldConfigUpdateRequest request);
    TenantApplicationFieldConfig patchConfig(Long tenantId, Long applicationId, Long fieldId, TenantApplicationFieldConfigPatchRequest request);
    void deleteConfig(Long tenantId, Long applicationId, Long fieldId);
    List<TenantApplicationFieldConfig> getConfigsByTenantApp(Long tenantId, Long applicationId);
}