package com.yourcompany.config.controller;

import com.yourcompany.config.model.*;
import com.yourcompany.config.service.*;
import com.yourcompany.config.exception.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.util.List;

import io.swagger.v3.oas.annotations.tags.Tag; // Import for @Tag

@RestController
@RequestMapping("/config/v1")
@RequiredArgsConstructor
//@Tag(name = "Configuration Management", description = "Endpoints for managing all configuration entities")
public class ConfigurationController {

    private final TenantService tenantService;
    private final ApplicationService applicationService;
    private final FeatureService featureService;
    private final UserRoleService userRoleService;
    private final PageService pageService;
    private final FormService formService;
    private final FieldService fieldService;
    private final ThemeService themeService;
    private final TenantApplicationFeatureConfigService tenantApplicationFeatureConfigService;
    private final TenantApplicationFieldConfigService tenantApplicationFieldConfigService;
    private final TenantApplicationConfigService tenantApplicationConfigService;


    // --- Tenant Endpoints ---
    @GetMapping("/tenants")
    @Tag(name = "Tenants") // Keep method-level tags for finer grouping/filtering
    public ResponseEntity<List<Tenant>> getAllTenants(
            @RequestParam(required = false) String tenantName,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "20") int size) {
        List<Tenant> tenants = tenantService.getAllTenants(tenantName, page, size);
        return ResponseEntity.ok(tenants);
    }

    @PostMapping("/tenants")
    @Tag(name = "Tenants")
    public ResponseEntity<Tenant> createTenant(@Valid @RequestBody TenantCreateRequest request) {
        Tenant tenant = tenantService.createTenant(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(tenant);
    }

    @GetMapping("/tenants/{tenantId}")
    @Tag(name = "Tenants")
    public ResponseEntity<Tenant> getTenantById(@PathVariable Long tenantId) {
        Tenant tenant = tenantService.getTenantById(tenantId);
        return ResponseEntity.ok(tenant);
    }

    @PutMapping("/tenants/{tenantId}")
    @Tag(name = "Tenants")
    public ResponseEntity<Tenant> updateTenant(@PathVariable Long tenantId, @Valid @RequestBody TenantUpdateRequest request) {
        Tenant updatedTenant = tenantService.updateTenant(tenantId, request);
        return ResponseEntity.ok(updatedTenant);
    }

    @DeleteMapping("/tenants/{tenantId}")
    @Tag(name = "Tenants")
    public ResponseEntity<Void> deleteTenant(@PathVariable Long tenantId) {
        tenantService.deleteTenant(tenantId);
        return ResponseEntity.noContent().build();
    }

    // --- Tenant Default Theme Management ---
    @GetMapping("/tenants/{tenantId}/theme")
    @Tag(name = "Tenant Theme Configuration") // Specific tag for theme config
    public ResponseEntity<Theme> getTenantDefaultTheme(@PathVariable Long tenantId) {
        Theme theme = tenantService.getTenantDefaultTheme(tenantId);
        return ResponseEntity.ok(theme);
    }

    @PutMapping("/tenants/{tenantId}/theme")
    @Tag(name = "Tenant Theme Configuration")
    public ResponseEntity<Tenant> setTenantDefaultTheme(@PathVariable Long tenantId, @Valid @RequestBody Long themeId) {
        // Request body will directly be the themeId
        Tenant updatedTenant = tenantService.setTenantDefaultTheme(tenantId, themeId);
        return ResponseEntity.ok(updatedTenant);
    }


    // --- Application Endpoints ---
    @GetMapping("/applications")
    @Tag(name = "Applications")
    public ResponseEntity<List<Application>> getAllApplications() {
        List<Application> applications = applicationService.getAllApplications();
        return ResponseEntity.ok(applications);
    }

    @PostMapping("/applications")
    @Tag(name = "Applications")
    public ResponseEntity<Application> createApplication(@Valid @RequestBody ApplicationCreateRequest request) {
        Application application = applicationService.createApplication(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(application);
    }

    @GetMapping("/applications/{applicationId}")
    @Tag(name = "Applications")
    public ResponseEntity<Application> getApplicationById(@PathVariable Long applicationId) {
        Application application = applicationService.getApplicationById(applicationId);
        return ResponseEntity.ok(application);
    }

    @PutMapping("/applications/{applicationId}")
    @Tag(name = "Applications")
    public ResponseEntity<Application> updateApplication(@PathVariable Long applicationId, @Valid @RequestBody ApplicationUpdateRequest request) {
        Application updatedApplication = applicationService.updateApplication(applicationId, request);
        return ResponseEntity.ok(updatedApplication);
    }

    @PatchMapping("/applications/{applicationId}")
    @Tag(name = "Applications")
    public ResponseEntity<Application> patchApplication(@PathVariable Long applicationId, @Valid @RequestBody ApplicationPatchRequest request) {
        Application patchedApplication = applicationService.patchApplication(applicationId, request);
        return ResponseEntity.ok(patchedApplication);
    }

    @DeleteMapping("/applications/{applicationId}")
    @Tag(name = "Applications")
    public ResponseEntity<Void> deleteApplication(@PathVariable Long applicationId) {
        applicationService.deleteApplication(applicationId);
        return ResponseEntity.noContent().build();
    }

    // --- Feature Availability (FeatureApplication) ---
    @GetMapping("/applications/{applicationId}/features")
    @Tag(name = "Feature Availability")
    public ResponseEntity<List<Feature>> getFeaturesByApplication(@PathVariable Long applicationId) {
        List<Feature> features = applicationService.getFeaturesByApplication(applicationId);
        return ResponseEntity.ok(features);
    }

    @PostMapping("/applications/{applicationId}/features/{featureId}")
    @Tag(name = "Feature Availability")
    public ResponseEntity<FeatureApplication> addFeatureToApplication(
            @PathVariable Long applicationId,
            @PathVariable Long featureId) {
        FeatureApplication association = applicationService.addFeatureToApplication(applicationId, featureId);
        return ResponseEntity.status(HttpStatus.CREATED).body(association);
    }

    @DeleteMapping("/applications/{applicationId}/features/{featureId}")
    @Tag(name = "Feature Availability")
    public ResponseEntity<Void> removeFeatureFromApplication(
            @PathVariable Long applicationId,
            @PathVariable Long featureId) {
        applicationService.removeFeatureFromApplication(applicationId, featureId);
        return ResponseEntity.noContent().build();
    }

    // --- Feature Endpoints ---
    @GetMapping("/features")
    @Tag(name = "Features")
    public ResponseEntity<List<Feature>> getAllFeatures() {
        List<Feature> features = featureService.getAllFeatures();
        return ResponseEntity.ok(features);
    }

    @PostMapping("/features")
    @Tag(name = "Features")
    public ResponseEntity<Feature> createFeature(@Valid @RequestBody FeatureCreateRequest request) {
        Feature feature = featureService.createFeature(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(feature);
    }

    @GetMapping("/features/{featureId}")
    @Tag(name = "Features")
    public ResponseEntity<Feature> getFeatureById(@PathVariable Long featureId) {
        Feature feature = featureService.getFeatureById(featureId);
        return ResponseEntity.ok(feature);
    }

    @PutMapping("/features/{featureId}")
    @Tag(name = "Features")
    public ResponseEntity<Feature> updateFeature(@PathVariable Long featureId, @Valid @RequestBody FeatureUpdateRequest request) {
        Feature updatedFeature = featureService.updateFeature(featureId, request);
        return ResponseEntity.ok(updatedFeature);
    }

    @PatchMapping("/features/{featureId}")
    @Tag(name = "Features")
    public ResponseEntity<Feature> patchFeature(@PathVariable Long featureId, @Valid @RequestBody FeaturePatchRequest request) {
        Feature patchedFeature = featureService.patchFeature(featureId, request);
        return ResponseEntity.ok(patchedFeature);
    }

    @DeleteMapping("/features/{featureId}")
    @Tag(name = "Features")
    public ResponseEntity<Void> deleteFeature(@PathVariable Long featureId) {
        featureService.deleteFeature(featureId);
        return ResponseEntity.noContent().build();
    }

    // --- UserRole Endpoints ---
    @GetMapping("/user-roles")
    @Tag(name = "User Roles")
    public ResponseEntity<List<UserRole>> getAllUserRoles() {
        List<UserRole> userRoles = userRoleService.getAllUserRoles();
        return ResponseEntity.ok(userRoles);
    }

    @PostMapping("/user-roles")
    @Tag(name = "User Roles")
    public ResponseEntity<UserRole> createUserRole(@Valid @RequestBody UserRoleCreateRequest request) {
        UserRole userRole = userRoleService.createUserRole(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(userRole);
    }

    @GetMapping("/user-roles/{roleId}")
    @Tag(name = "User Roles")
    public ResponseEntity<UserRole> getUserRoleById(@PathVariable Long roleId) {
        UserRole userRole = userRoleService.getUserRoleById(roleId);
        return ResponseEntity.ok(userRole);
    }

    @PutMapping("/user-roles/{roleId}")
    @Tag(name = "User Roles")
    public ResponseEntity<UserRole> updateUserRole(@PathVariable Long roleId, @Valid @RequestBody UserRoleUpdateRequest request) {
        UserRole updatedRole = userRoleService.updateUserRole(roleId, request);
        return ResponseEntity.ok(updatedRole);
    }

    @PatchMapping("/user-roles/{roleId}")
    @Tag(name = "User Roles")
    public ResponseEntity<UserRole> patchUserRole(@PathVariable Long roleId, @Valid @RequestBody UserRolePatchRequest request) {
        UserRole patchedRole = userRoleService.patchUserRole(roleId, request);
        return ResponseEntity.ok(patchedRole);
    }

    @DeleteMapping("/user-roles/{roleId}")
    @Tag(name = "User Roles")
    public ResponseEntity<Void> deleteUserRole(@PathVariable Long roleId) {
        userRoleService.deleteUserRole(roleId);
        return ResponseEntity.noContent().build();
    }

    // --- Page Endpoints ---
    @GetMapping("/features/{featureId}/pages")
    @Tag(name = "Pages")
    public ResponseEntity<List<Page>> getPagesByFeature(@PathVariable Long featureId) {
        // Calling FeatureService to get pages by feature, as per RESTful hierarchy
        List<Page> pages = featureService.getPagesByFeature(featureId);
        return ResponseEntity.ok(pages);
    }

    @PostMapping("/features/{featureId}/pages")
    @Tag(name = "Pages")
    public ResponseEntity<Page> createPage(@PathVariable Long featureId, @Valid @RequestBody PageCreateRequest request) {
        Page page = pageService.createPage(featureId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(page);
    }

    @GetMapping("/features/{featureId}/pages/{pageId}")
    @Tag(name = "Pages")
    public ResponseEntity<Page> getPageById(@PathVariable Long featureId, @PathVariable Long pageId) {
        // Ensure page belongs to feature for consistency with nested path
        Page page = pageService.getPageById(pageId);
        if (!page.getFeatureId().equals(featureId)) {
            throw new ResourceNotFoundException("Page ID " + pageId + " not found within Feature ID " + featureId);
        }
        return ResponseEntity.ok(page);
    }

    @PutMapping("/features/{featureId}/pages/{pageId}")
    @Tag(name = "Pages")
    public ResponseEntity<Page> updatePage(@PathVariable Long featureId, @PathVariable Long pageId, @Valid @RequestBody PageUpdateRequest request) {
        Page updatedPage = pageService.updatePage(featureId, pageId, request);
        return ResponseEntity.ok(updatedPage);
    }

    @DeleteMapping("/features/{featureId}/pages/{pageId}")
    @Tag(name = "Pages")
    public ResponseEntity<Void> deletePage(@PathVariable Long featureId, @PathVariable Long pageId) {
        pageService.deletePage(featureId, pageId);
        return ResponseEntity.noContent().build();
    }

    // --- Form Endpoints ---
    @GetMapping("/pages/{pageId}/forms")
    @Tag(name = "Forms")
    public ResponseEntity<List<Form>> getFormsByPage(@PathVariable Long pageId) {
        List<Form> forms = pageService.getFormsByPage(pageId);
        return ResponseEntity.ok(forms);
    }

    @PostMapping("/pages/{pageId}/forms")
    @Tag(name = "Forms")
    public ResponseEntity<Form> createForm(@PathVariable Long pageId, @Valid @RequestBody FormCreateRequest request) {
        Form form = formService.createForm(pageId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(form);
    }

    @GetMapping("/pages/{pageId}/forms/{formId}")
    @Tag(name = "Forms")
    public ResponseEntity<Form> getFormById(@PathVariable Long pageId, @PathVariable Long formId) {
        // Ensure form belongs to page for consistency with nested path
        Form form = formService.getFormById(formId);
        if (!form.getPageId().equals(pageId)) {
            throw new ResourceNotFoundException("Form ID " + formId + " not found within Page ID " + pageId);
        }
        return ResponseEntity.ok(form);
    }

    @DeleteMapping("/pages/{pageId}/forms/{formId}")
    @Tag(name = "Forms")
    public ResponseEntity<Void> deleteForm(@PathVariable Long pageId, @PathVariable Long formId) {
        formService.deleteForm(pageId, formId);
        return ResponseEntity.noContent().build();
    }

    // --- Nested Resources: Fields within Forms ---
    @GetMapping("/forms/{formId}/fields")
    @Tag(name = "Fields")
    public ResponseEntity<List<Field>> getFieldsByForm(@PathVariable Long formId) {
        List<Field> fields = formService.getFieldsByForm(formId);
        return ResponseEntity.ok(fields);
    }

    @PostMapping("/fields")
    @Tag(name = "Fields")
    public ResponseEntity<Field> createField(@Valid @RequestBody FieldCreateRequest request) {
        Field field = fieldService.createField(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(field);
    }

    @GetMapping("/fields/{fieldId}")
    @Tag(name = "Fields")
    public ResponseEntity<Field> getFieldById(@PathVariable Long fieldId) {
        Field field = fieldService.getFieldById(fieldId);
        return ResponseEntity.ok(field);
    }

    @DeleteMapping("/fields/{fieldId}")
    @Tag(name = "Fields")
    public ResponseEntity<Void> deleteField(@PathVariable Long fieldId) {
        fieldService.deleteField(fieldId);
        return ResponseEntity.noContent().build();
    }


    // --- Theme Endpoints ---
    @GetMapping("/themes")
    @Tag(name = "Themes")
    public ResponseEntity<List<Theme>> getAllThemes() {
        List<Theme> themes = themeService.getAllThemes();
        return ResponseEntity.ok(themes);
    }

    @PostMapping("/themes")
    @Tag(name = "Themes")
    public ResponseEntity<Theme> createTheme(@Valid @RequestBody ThemeCreateRequest request) {
        Theme theme = themeService.createTheme(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(theme);
    }

    @GetMapping("/themes/{themeId}")
    @Tag(name = "Themes")
    public ResponseEntity<Theme> getThemeById(@PathVariable Long themeId) {
        Theme theme = themeService.getThemeById(themeId);
        return ResponseEntity.ok(theme);
    }

    @PutMapping("/themes/{themeId}")
    @Tag(name = "Themes")
    public ResponseEntity<Theme> updateTheme(@PathVariable Long themeId, @Valid @RequestBody ThemeUpdateRequest request) {
        Theme updatedTheme = themeService.updateTheme(themeId, request);
        return ResponseEntity.ok(updatedTheme);
    }

    @PatchMapping("/themes/{themeId}")
    @Tag(name = "Themes")
    public ResponseEntity<Theme> patchTheme(@PathVariable Long themeId, @Valid @RequestBody ThemePatchRequest request) {
        Theme patchedTheme = themeService.patchTheme(themeId, request);
        return ResponseEntity.ok(patchedTheme);
    }

    @DeleteMapping("/themes/{themeId}")
    @Tag(name = "Themes")
    public ResponseEntity<Void> deleteTheme(@PathVariable Long themeId) {
        themeService.deleteTheme(themeId);
        return ResponseEntity.noContent().build();
    }


    // --- Tenant Application Feature Configuration Endpoints ---
    @GetMapping("/tenants/{tenantId}/applications/{applicationId}/feature-configs")
    @Tag(name = "Tenant Feature Configuration")
    public ResponseEntity<List<TenantApplicationFeatureConfig>> getTenantAppFeatureConfigs(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId,
            @RequestParam(required = false) Long roleId,
            @RequestParam(required = false) Long featureId) {
        // Implement filtering logic based on roleId and featureId
        List<TenantApplicationFeatureConfig> configs = tenantApplicationFeatureConfigService.getConfigsByTenantApp(tenantId, applicationId, roleId);
        return ResponseEntity.ok(configs);
    }

    @GetMapping("/tenants/{tenantId}/applications/{applicationId}/roles/{roleId}/features/{featureId}/config")
    @Tag(name = "Tenant Feature Configuration")
    public ResponseEntity<TenantApplicationFeatureConfig> getTenantAppRoleFeatureConfig(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId,
            @PathVariable("roleId") String roleIdStr, // Use String to handle "unauthenticated"
            @PathVariable Long featureId) {
        Long roleId = parseRoleId(roleIdStr);
        TenantApplicationFeatureConfig config = tenantApplicationFeatureConfigService.getConfig(tenantId, applicationId, roleId, featureId);
        return ResponseEntity.ok(config);
    }

    @PutMapping("/tenants/{tenantId}/applications/{applicationId}/roles/{roleId}/features/{featureId}/config")
    @Tag(name = "Tenant Feature Configuration")
    public ResponseEntity<TenantApplicationFeatureConfig> createOrUpdateTenantAppRoleFeatureConfig(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId,
            @PathVariable("roleId") String roleIdStr,
            @PathVariable Long featureId,
            @Valid @RequestBody TenantApplicationFeatureConfigUpdateRequest request) {
        Long roleId = parseRoleId(roleIdStr);
        TenantApplicationFeatureConfig config = tenantApplicationFeatureConfigService.createOrUpdateConfig(tenantId, applicationId, roleId, featureId, request);
        return ResponseEntity.status(HttpStatus.OK).body(config); // Or HttpStatus.CREATED if new
    }

    @PatchMapping("/tenants/{tenantId}/applications/{applicationId}/roles/{roleId}/features/{featureId}/config")
    @Tag(name = "Tenant Feature Configuration")
    public ResponseEntity<TenantApplicationFeatureConfig> patchTenantAppRoleFeatureConfig(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId,
            @PathVariable("roleId") String roleIdStr,
            @PathVariable Long featureId,
            @Valid @RequestBody TenantApplicationFeatureConfigPatchRequest request) {
        Long roleId = parseRoleId(roleIdStr);
        TenantApplicationFeatureConfig config = tenantApplicationFeatureConfigService.patchConfig(tenantId, applicationId, roleId, featureId, request);
        return ResponseEntity.ok(config);
    }

    @DeleteMapping("/tenants/{tenantId}/applications/{applicationId}/roles/{roleId}/features/{featureId}/config")
    @Tag(name = "Tenant Feature Configuration")
    public ResponseEntity<Void> deleteTenantAppRoleFeatureConfig(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId,
            @PathVariable("roleId") String roleIdStr,
            @PathVariable Long featureId) {
        Long roleId = parseRoleId(roleIdStr);
        tenantApplicationFeatureConfigService.deleteConfig(tenantId, applicationId, roleId, featureId);
        return ResponseEntity.noContent().build();
    }

    // Helper method to parse roleId from path (handles "unauthenticated" for null)
    private Long parseRoleId(String roleIdStr) {
        if ("unauthenticated".equalsIgnoreCase(roleIdStr) || "null".equalsIgnoreCase(roleIdStr)) {
            return null;
        }
        try {
            return Long.parseLong(roleIdStr);
        } catch (NumberFormatException e) {
            throw new BadRequestException("Invalid roleId format. Must be numeric or 'unauthenticated'.");
        }
    }


    // --- Tenant Application Field Configuration Endpoints ---
    @GetMapping("/tenants/{tenantId}/applications/{applicationId}/field-configs")
    @Tag(name = "Tenant Field Configuration")
    public ResponseEntity<List<TenantApplicationFieldConfig>> getTenantAppFieldConfigs(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId,
            @RequestParam(required = false) Long fieldId) {
        // Implement filtering logic based on fieldId
        List<TenantApplicationFieldConfig> configs = tenantApplicationFieldConfigService.getConfigsByTenantApp(tenantId, applicationId);
        return ResponseEntity.ok(configs);
    }

    @GetMapping("/tenants/{tenantId}/applications/{applicationId}/fields/{fieldId}/config")
    @Tag(name = "Tenant Field Configuration")
    public ResponseEntity<TenantApplicationFieldConfig> getTenantAppFieldConfig(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId,
            @PathVariable Long fieldId) {
        TenantApplicationFieldConfig config = tenantApplicationFieldConfigService.getConfig(tenantId, applicationId, fieldId);
        return ResponseEntity.ok(config);
    }

    @PutMapping("/tenants/{tenantId}/applications/{applicationId}/fields/{fieldId}/config")
    @Tag(name = "Tenant Field Configuration")
    public ResponseEntity<TenantApplicationFieldConfig> createOrUpdateTenantAppFieldConfig(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId,
            @PathVariable Long fieldId,
            @Valid @RequestBody TenantApplicationFieldConfigUpdateRequest request) {
        TenantApplicationFieldConfig config = tenantApplicationFieldConfigService.createOrUpdateConfig(tenantId, applicationId, fieldId, request);
        return ResponseEntity.status(HttpStatus.OK).body(config); // Or HttpStatus.CREATED if new
    }

    @PatchMapping("/tenants/{tenantId}/applications/{applicationId}/fields/{fieldId}/config")
    @Tag(name = "Tenant Field Configuration")
    public ResponseEntity<TenantApplicationFieldConfig> patchTenantAppFieldConfig(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId,
            @PathVariable Long fieldId,
            @Valid @RequestBody TenantApplicationFieldConfigPatchRequest request) {
        TenantApplicationFieldConfig config = tenantApplicationFieldConfigService.patchConfig(tenantId, applicationId, fieldId, request);
        return ResponseEntity.ok(config);
    }

    @DeleteMapping("/tenants/{tenantId}/applications/{applicationId}/fields/{fieldId}/config")
    @Tag(name = "Tenant Field Configuration")
    public ResponseEntity<Void> deleteTenantAppFieldConfig(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId,
            @PathVariable Long fieldId) {
        tenantApplicationFieldConfigService.deleteConfig(tenantId, applicationId, fieldId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/tenants/{tenantId}/applications/{applicationId}/theme-config")
    @Tag(name = "Tenant Theme Configuration")
    public ResponseEntity<TenantApplicationConfig> getTenantAppThemeConfig(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId) {
        TenantApplicationConfig config = tenantApplicationConfigService.getThemeConfig(tenantId, applicationId);
        return ResponseEntity.ok(config);
    }

    @PutMapping("/tenants/{tenantId}/applications/{applicationId}/theme-config")
    @Tag(name = "Tenant Theme Configuration")
    public ResponseEntity<TenantApplicationConfig> createOrUpdateTenantAppThemeConfig(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId,
            @Valid @RequestBody TenantApplicationThemeConfigUpdateRequest request) {
        TenantApplicationConfig config = tenantApplicationConfigService.createOrUpdateThemeConfig(tenantId, applicationId, request);
        return ResponseEntity.status(HttpStatus.OK).body(config); // Or HttpStatus.CREATED if new
    }

    @PatchMapping("/tenants/{tenantId}/applications/{applicationId}/theme-config")
    @Tag(name = "Tenant Theme Configuration")
    public ResponseEntity<TenantApplicationConfig> patchTenantAppThemeConfig(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId,
            @Valid @RequestBody TenantApplicationThemeConfigPatchRequest request) {
        TenantApplicationConfig config = tenantApplicationConfigService.patchThemeConfig(tenantId, applicationId, request);
        return ResponseEntity.ok(config);
    }

    @DeleteMapping("/tenants/{tenantId}/applications/{applicationId}/theme-config")
    @Tag(name = "Tenant Theme Configuration")
    public ResponseEntity<Void> deleteTenantAppThemeConfig(
            @PathVariable Long tenantId,
            @PathVariable Long applicationId) {
        tenantApplicationConfigService.deleteThemeConfig(tenantId, applicationId);
        return ResponseEntity.noContent().build();
    }
}
