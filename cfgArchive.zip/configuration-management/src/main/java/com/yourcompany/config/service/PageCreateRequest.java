package com.yourcompany.config.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// Page DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PageCreateRequest {
    private String pageName;
    private Integer pageOrder;
}