package com.yourcompany.config.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yourcompany.config.model.Field;
import com.yourcompany.config.repository.FieldRepository;
import com.yourcompany.config.repository.FormRepository;
import com.yourcompany.config.exception.*;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class FieldServiceImpl implements FieldService {
    private final FieldRepository fieldRepository;
    private final FormRepository formRepository; // To validate formId

    @Override
    public Field getFieldById(Long fieldId) {
        return fieldRepository.findById(fieldId)
                .orElseThrow(() -> new ResourceNotFoundException("Field not found with ID: " + fieldId));
    }

    @Override
    @Transactional
    public Field createField(FieldCreateRequest request) {
        if (!formRepository.existsById(request.getFormId())) {
            throw new ResourceNotFoundException("Form not found with ID: " + request.getFormId());
        }
        if (fieldRepository.findByFormIdAndFieldName(request.getFormId(), request.getFieldName()).isPresent()) {
            throw new ResourceConflictException("Field with name '" + request.getFieldName() + "' already exists for form ID: " + request.getFormId());
        }
        
        Field field = new Field();
        field.setFormId(request.getFormId());
        field.setFieldName(request.getFieldName());
        field.setFieldType(request.getFieldType());
        field.setInputType(request.getInputType());
        field.setDefaultLabel(request.getDefaultLabel());
        field.setDefaultValidationRules(request.getDefaultValidationRules());
        
        // // Derive pageId from the form
        // formRepository.findById(request.getFormId()).ifPresent(form -> field.setPageId(form.getPageId()));
        // if (field.getPageId() == null) {
        //     throw new IllegalStateException("Could not derive pageId from formId. This indicates a data integrity issue.");
        // }
        field.setCreatedBy("system_init");
        field.setUpdatedBy("system_init");
        return fieldRepository.save(field);
    }

    @Override
    @Transactional
    public void deleteField(Long fieldId) {
        if (!fieldRepository.existsById(fieldId)) {
            throw new ResourceNotFoundException("Field not found with ID: " + fieldId);
        }
        fieldRepository.deleteById(fieldId);
    }
}