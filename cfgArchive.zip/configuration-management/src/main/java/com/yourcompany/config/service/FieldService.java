package com.yourcompany.config.service;

import com.yourcompany.config.model.Field;

public interface FieldService {
    Field getFieldById(Long fieldId);
    Field createField(FieldCreateRequest request);
    void deleteField(Long fieldId);
}