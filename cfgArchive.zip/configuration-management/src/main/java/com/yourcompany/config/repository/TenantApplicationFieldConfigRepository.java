package com.yourcompany.config.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yourcompany.config.model.TenantApplicationFieldConfig;

@Repository
public interface TenantApplicationFieldConfigRepository extends JpaRepository<TenantApplicationFieldConfig, Long> {
    Optional<TenantApplicationFieldConfig> findByTenantIdAndApplicationIdAndFieldId(Long tenantId, Long applicationId, Long fieldId);
    List<TenantApplicationFieldConfig> findByTenantIdAndApplicationId(Long tenantId, Long applicationId);
}