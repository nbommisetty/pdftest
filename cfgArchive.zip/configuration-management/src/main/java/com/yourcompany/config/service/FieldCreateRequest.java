package com.yourcompany.config.service;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FieldCreateRequest { // ADDED - for POST /fields
    private Long formId;
    private String fieldName;
    private String fieldType;
    private String inputType;
    private String defaultLabel;
    private JsonNode defaultValidationRules;
}