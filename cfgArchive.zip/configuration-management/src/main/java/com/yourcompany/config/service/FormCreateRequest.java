package com.yourcompany.config.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FormCreateRequest { // ADDED - for POST /pages/{pageId}/forms
    private String formName;
    private Integer formOrder;
}
