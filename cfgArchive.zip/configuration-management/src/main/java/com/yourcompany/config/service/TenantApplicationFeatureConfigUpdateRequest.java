package com.yourcompany.config.service;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// Tenant Application Feature Config DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TenantApplicationFeatureConfigUpdateRequest {
    private Boolean isEnabled;
    private Long themeId; // Nullable
}