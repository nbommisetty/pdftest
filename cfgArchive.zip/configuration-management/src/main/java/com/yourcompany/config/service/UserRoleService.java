package com.yourcompany.config.service;

import java.util.List;

import com.yourcompany.config.model.UserRole;

public interface UserRoleService {
    List<UserRole> getAllUserRoles();
    UserRole getUserRoleById(Long roleId);
    UserRole createUserRole(UserRoleCreateRequest request);
    UserRole updateUserRole(Long roleId, UserRoleUpdateRequest request);
    UserRole patchUserRole(Long roleId, UserRolePatchRequest request);
    void deleteUserRole(Long roleId);
}