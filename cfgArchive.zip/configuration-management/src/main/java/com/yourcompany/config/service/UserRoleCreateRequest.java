package com.yourcompany.config.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

// UserRole DTOs
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserRoleCreateRequest {
    private String roleName;
    private String roleDescription;
}