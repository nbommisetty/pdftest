package com.yourcompany.config.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yourcompany.config.model.Application;
import com.yourcompany.config.model.Feature;
import com.yourcompany.config.model.FeatureApplication;
import com.yourcompany.config.repository.ApplicationRepository;
import com.yourcompany.config.repository.FeatureApplicationRepository;
import com.yourcompany.config.repository.FeatureRepository;
import com.yourcompany.config.exception.*;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ApplicationServiceImpl implements ApplicationService {
    private final ApplicationRepository applicationRepository;
    private final FeatureApplicationRepository featureApplicationRepository;
    private final FeatureRepository featureRepository;

    @Override
    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }

    @Override
    public Application getApplicationById(Long applicationId) {
        return applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found with ID: " + applicationId));
    }

    @Override
    @Transactional
    public Application createApplication(ApplicationCreateRequest request) {
        if (applicationRepository.findByApplicationName(request.getApplicationName()).isPresent()) {
            throw new ResourceConflictException("Application with name '" + request.getApplicationName() + "' already exists.");
        }
        Application application = new Application();
        application.setApplicationName(request.getApplicationName());
        application.setApplicationDescription(request.getApplicationDescription());
        application.setCreatedBy("system_init"); // Placeholder
        application.setUpdatedBy("system_init"); // Placeholder
        return applicationRepository.save(application);
    }

    @Override
    @Transactional
    public Application updateApplication(Long applicationId, ApplicationUpdateRequest request) {
        Application existingApp = getApplicationById(applicationId);
        if (!existingApp.getApplicationName().equals(request.getApplicationName())) {
            if (applicationRepository.findByApplicationName(request.getApplicationName()).isPresent()) {
                throw new ResourceConflictException("Application with name '" + request.getApplicationName() + "' already exists.");
            }
        }
        existingApp.setApplicationName(request.getApplicationName());
        existingApp.setApplicationDescription(request.getApplicationDescription());
        existingApp.setUpdatedBy("system_update");
        return applicationRepository.save(existingApp);
    }

    @Override
    @Transactional
    public Application patchApplication(Long applicationId, ApplicationPatchRequest request) {
        Application existingApp = getApplicationById(applicationId);
        if (request.getApplicationName() != null && !existingApp.getApplicationName().equals(request.getApplicationName())) {
            if (applicationRepository.findByApplicationName(request.getApplicationName()).isPresent()) {
                throw new ResourceConflictException("Application with name '" + request.getApplicationName() + "' already exists.");
            }
            existingApp.setApplicationName(request.getApplicationName());
        }
        if (request.getApplicationDescription() != null) {
            existingApp.setApplicationDescription(request.getApplicationDescription());
        }
        existingApp.setUpdatedBy("system_patch");
        return applicationRepository.save(existingApp);
    }

    @Override
    @Transactional
    public void deleteApplication(Long applicationId) {
        if (!applicationRepository.existsById(applicationId)) {
            throw new ResourceNotFoundException("Application not found with ID: " + applicationId);
        }
        applicationRepository.deleteById(applicationId);
    }

    @Override
    public List<Feature> getFeaturesByApplication(Long applicationId) {
        // This would typically involve a join to retrieve actual Feature objects, not just FeatureApplication records
        // For scaffold, we return empty list or mock data
        return featureApplicationRepository.findByApplicationId(applicationId).stream()
                .map(fa -> new Feature(fa.getFeatureId(), null, null)) // Mock feature
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public FeatureApplication addFeatureToApplication(Long applicationId, Long featureId) {
        if (!applicationRepository.existsById(applicationId)) {
            throw new ResourceNotFoundException("Application not found with ID: " + applicationId);
        }
        if (!featureRepository.existsById(featureId)) { // Mock FeatureRepository usage
            throw new ResourceNotFoundException("Feature not found with ID: " + featureId);
        }
        if (featureApplicationRepository.findByFeatureIdAndApplicationId(featureId, applicationId).isPresent()) {
            throw new ResourceConflictException("Feature ID " + featureId + " already associated with Application ID " + applicationId);
        }
        FeatureApplication fa = new FeatureApplication();
        fa.setFeatureId(featureId);
        fa.setApplicationId(applicationId);
        fa.setCreatedBy("system_associate");
        fa.setUpdatedBy("system_associate");
        return featureApplicationRepository.save(fa);
    }

    @Override
    @Transactional
    public void removeFeatureFromApplication(Long applicationId, Long featureId) {
        FeatureApplication fa = featureApplicationRepository.findByFeatureIdAndApplicationId(featureId, applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Association not found for Feature ID " + featureId + " and Application ID " + applicationId));
        featureApplicationRepository.delete(fa);
    }
}