package com.yourcompany.config;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Implementation of AuditorAware to provide the current auditing user.
 * In a real application, this would integrate with Spring Security
 * to get the authenticated user's principal (e.g., username).
 * For this scaffold, it returns a hardcoded value.
 */
@Component
public class AuditorAwareImpl implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        // In a real application, retrieve the current authenticated user's username
        // from Spring SecurityContextHolder.
        // Example: return Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication().getName());
        return Optional.of("system_user"); // Hardcoded for scaffold/demo purposes
    }
}
