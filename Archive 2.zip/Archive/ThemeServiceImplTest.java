package com.yourcompany.config.service;

import com.yourcompany.config.exception.BadRequestException;
import com.yourcompany.config.exception.ResourceConflictException;
import com.yourcompany.config.exception.ResourceNotFoundException;
import com.yourcompany.config.model.Theme;
import com.yourcompany.config.repository.ThemeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("Theme Service Unit Tests")
public class ThemeServiceImplTest {

    @Mock
    private ThemeRepository themeRepository;

    @InjectMocks
    private ThemeServiceImpl themeService;

    private Theme theme1;
    private Theme theme2;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        LocalDateTime now = LocalDateTime.now();
        String user = "test_user";
        objectMapper = new ObjectMapper();

        ObjectNode themeData1 = objectMapper.createObjectNode();
        themeData1.put("primaryColor", "#000000");
        themeData1.put("secondaryColor", "#333333");

        ObjectNode themeData2 = objectMapper.createObjectNode();
        themeData2.put("backgroundColor", "#F0F0F0");

        theme1 = new Theme();
        theme1.setThemeId(1L);
        theme1.setThemeName("dark");
        theme1.setThemeDescription("Dark mode UI theme.");
        theme1.setThemeData(themeData1);
        theme1.setCreatedAt(now);
        theme1.setUpdatedAt(now);
        theme1.setCreatedBy(user);
        theme1.setUpdatedBy(user);

        theme2 = new Theme();
        theme2.setThemeId(2L);
        theme2.setThemeName("classic");
        theme2.setThemeDescription("Classic UI theme.");
        theme2.setThemeData(themeData2);
        theme2.setCreatedAt(now);
        theme2.setUpdatedAt(now);
        theme2.setCreatedBy(user);
        theme2.setUpdatedBy(user);
    }

    @Test
    @DisplayName("Should return all themes")
    void getAllThemes_shouldReturnAllThemes() {
        when(themeRepository.findAll()).thenReturn(Arrays.asList(theme1, theme2));

        List<Theme> themes = themeService.getAllThemes();

        assertNotNull(themes);
        assertEquals(2, themes.size());
        assertEquals("dark", themes.get(0).getThemeName());
        verify(themeRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Should return theme by ID")
    void getThemeById_shouldReturnTheme() {
        when(themeRepository.findById(1L)).thenReturn(Optional.of(theme1));

        Theme foundTheme = themeService.getThemeById(1L);

        assertNotNull(foundTheme);
        assertEquals("dark", foundTheme.getThemeName());
        verify(themeRepository, times(1)).findById(1L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if theme not found by ID")
    void getThemeById_shouldThrowNotFoundException() {
        when(themeRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> themeService.getThemeById(99L));
        verify(themeRepository, times(1)).findById(99L);
    }

    @Test
    @DisplayName("Should create a new theme successfully")
    void createTheme_shouldCreateTheme() {
        ThemeCreateRequest request = new ThemeCreateRequest("new-theme", "New Theme Description", null);
        when(themeRepository.findByThemeName(request.getThemeName())).thenReturn(Optional.empty());
        when(themeRepository.save(any(Theme.class))).thenReturn(theme1);

        Theme createdTheme = themeService.createTheme(request);

        assertNotNull(createdTheme);
        assertEquals("dark", createdTheme.getThemeName()); // Assuming theme1 is returned after save
        verify(themeRepository, times(1)).findByThemeName("new-theme");
        verify(themeRepository, times(1)).save(any(Theme.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if theme name already exists during creation")
    void createTheme_shouldThrowConflictExceptionIfNameExists() {
        ThemeCreateRequest request = new ThemeCreateRequest("dark", "Existing Theme Description", null);
        when(themeRepository.findByThemeName(request.getThemeName())).thenReturn(Optional.of(theme1));

        assertThrows(ResourceConflictException.class, () -> themeService.createTheme(request));
        verify(themeRepository, times(1)).findByThemeName("dark");
        verify(themeRepository, never()).save(any(Theme.class));
    }

    @Test
    @DisplayName("Should update an existing theme successfully (full replacement)")
    void updateTheme_shouldUpdateTheme() {
        ThemeUpdateRequest request = new ThemeUpdateRequest("updated-dark", "Updated Description", null);
        when(themeRepository.findById(1L)).thenReturn(Optional.of(theme1));
        when(themeRepository.findByThemeName(request.getThemeName())).thenReturn(Optional.empty());
        when(themeRepository.save(any(Theme.class))).thenReturn(theme1);

        Theme updatedTheme = themeService.updateTheme(1L, request);

        assertNotNull(updatedTheme);
        assertEquals("updated-dark", updatedTheme.getThemeName());
        assertEquals("Updated Description", updatedTheme.getThemeDescription());
        verify(themeRepository, times(1)).findById(1L);
        verify(themeRepository, times(1)).findByThemeName("updated-dark");
        verify(themeRepository, times(1)).save(theme1);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if theme not found during update")
    void updateTheme_shouldThrowNotFoundException() {
        ThemeUpdateRequest request = new ThemeUpdateRequest("UpdatedTheme", null, null);
        when(themeRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> themeService.updateTheme(99L, request));
        verify(themeRepository, times(1)).findById(99L);
        verify(themeRepository, never()).save(any(Theme.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if updated theme name already exists")
    void updateTheme_shouldThrowConflictExceptionIfNameExists() {
        ThemeUpdateRequest request = new ThemeUpdateRequest("classic", null, null);
        when(themeRepository.findById(1L)).thenReturn(Optional.of(theme1));
        when(themeRepository.findByThemeName("classic")).thenReturn(Optional.of(theme2));

        assertThrows(ResourceConflictException.class, () -> themeService.updateTheme(1L, request));
        verify(themeRepository, times(1)).findById(1L);
        verify(themeRepository, times(1)).findByThemeName("classic");
        verify(themeRepository, never()).save(any(Theme.class));
    }

    @Test
    @DisplayName("Should partially update an existing theme successfully")
    void patchTheme_shouldPatchTheme() {
        ThemePatchRequest request = new ThemePatchRequest();
        request.setThemeDescription("Patched Description");
        when(themeRepository.findById(1L)).thenReturn(Optional.of(theme1));
        when(themeRepository.save(any(Theme.class))).thenReturn(theme1);

        Theme patchedTheme = themeService.patchTheme(1L, request);

        assertNotNull(patchedTheme);
        assertEquals("dark", patchedTheme.getThemeName());
        assertEquals("Patched Description", patchedTheme.getThemeDescription());
        verify(themeRepository, times(1)).findById(1L);
        verify(themeRepository, times(1)).save(theme1);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if theme not found during patch")
    void patchTheme_shouldThrowNotFoundException() {
        ThemePatchRequest request = new ThemePatchRequest();
        request.setThemeName("NonExistentTheme");
        when(themeRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> themeService.patchTheme(99L, request));
        verify(themeRepository, times(1)).findById(99L);
        verify(themeRepository, never()).save(any(Theme.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if patched theme name already exists")
    void patchTheme_shouldThrowConflictExceptionIfNameExists() {
        ThemePatchRequest request = new ThemePatchRequest();
        request.setThemeName("classic");
        when(themeRepository.findById(1L)).thenReturn(Optional.of(theme1));
        when(themeRepository.findByThemeName("classic")).thenReturn(Optional.of(theme2));

        assertThrows(ResourceConflictException.class, () -> themeService.patchTheme(1L, request));
        verify(themeRepository, times(1)).findById(1L);
        verify(themeRepository, times(1)).findByThemeName("classic");
        verify(themeRepository, never()).save(any(Theme.class));
    }

    @Test
    @DisplayName("Should delete a theme successfully")
    void deleteTheme_shouldDeleteTheme() {
        when(themeRepository.existsById(1L)).thenReturn(true);
        doNothing().when(themeRepository).deleteById(1L);

        assertDoesNotThrow(() -> themeService.deleteTheme(1L));
        verify(themeRepository, times(1)).existsById(1L);
        verify(themeRepository, times(1)).deleteById(1L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if theme not found during delete")
    void deleteTheme_shouldThrowNotFoundException() {
        when(themeRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> themeService.deleteTheme(99L));
        verify(themeRepository, times(1)).existsById(99L);
        verify(themeRepository, never()).deleteById(anyLong());
    }
}
