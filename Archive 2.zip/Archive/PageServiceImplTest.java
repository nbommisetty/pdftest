package com.yourcompany.config.service;

import com.yourcompany.config.exception.BadRequestException;
import com.yourcompany.config.exception.ResourceConflictException;
import com.yourcompany.config.exception.ResourceNotFoundException;
import com.yourcompany.config.model.Feature;
import com.yourcompany.config.model.Page;
import com.yourcompany.config.model.Form;
import com.yourcompany.config.model.Field;
import com.yourcompany.config.repository.FeatureRepository;
import com.yourcompany.config.repository.PageRepository;
import com.yourcompany.config.repository.FormRepository;
import com.yourcompany.config.repository.FieldRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.HashSet;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("Page Service Unit Tests")
public class PageServiceImplTest {

    @Mock
    private PageRepository pageRepository;
    @Mock
    private FormRepository formRepository;
    @Mock
    private FieldRepository fieldRepository;
    @Mock
    private FeatureRepository featureRepository;

    @InjectMocks
    private PageServiceImpl pageService;

    private Feature feature;
    private Page page1;
    private Page page2;
    private Form form1;
    private Form form2;
    private Field field1;
    private Field field2;

    @BeforeEach
    void setUp() {
        LocalDateTime now = LocalDateTime.now();
        String user = "test_user";

        feature = new Feature();
        feature.setFeatureId(100L);
        feature.setFeatureName("TestFeature");
        feature.setCreatedAt(now);
        feature.setUpdatedAt(now);
        feature.setCreatedBy(user);
        feature.setUpdatedBy(user);

        page1 = new Page();
        page1.setPageId(1L);
        page1.setFeatureId(feature.getFeatureId());
        page1.setPageName("HomePage");
        page1.setPageOrder(1);
        page1.setCreatedAt(now);
        page1.setUpdatedAt(now);
        page1.setCreatedBy(user);
        page1.setUpdatedBy(user);

        page2 = new Page();
        page2.setPageId(2L);
        page2.setFeatureId(feature.getFeatureId());
        page2.setPageName("AboutPage");
        page2.setPageOrder(2);
        page2.setCreatedAt(now);
        page2.setUpdatedAt(now);
        page2.setCreatedBy(user);
        page2.setUpdatedBy(user);

        form1 = new Form();
        form1.setFormId(10L);
        form1.setPageId(page1.getPageId());
        form1.setFormName("LoginForm");
        form1.setFormOrder(1);
        form1.setCreatedAt(now);
        form1.setUpdatedAt(now);
        form1.setCreatedBy(user);
        form1.setUpdatedBy(user);

        form2 = new Form();
        form2.setFormId(11L);
        form2.setPageId(page1.getPageId());
        form2.setFormName("RegisterForm");
        form2.setFormOrder(2);
        form2.setCreatedAt(now);
        form2.setUpdatedAt(now);
        form2.setCreatedBy(user);
        form2.setUpdatedBy(user);

        field1 = new Field();
        field1.setFieldId(100L);
        field1.setFormId(form1.getFormId());
        field1.setFieldName("username");
        field1.setFieldType("TEXT");
        field1.setInputType("TEXT");
        field1.setDefaultLabel("Username");
        field1.setCreatedAt(now);
        field1.setUpdatedAt(now);
        field1.setCreatedBy(user);
        field1.setUpdatedBy(user);

        field2 = new Field();
        field2.setFieldId(101L);
        field2.setFormId(form1.getFormId());
        field2.setFieldName("password");
        field2.setFieldType("TEXT");
        field2.setInputType("PASSWORD");
        field2.setDefaultLabel("Password");
        field2.setCreatedAt(now);
        field2.setUpdatedAt(now);
        field2.setCreatedBy(user);
        field2.setUpdatedBy(user);
    }

    @Test
    @DisplayName("Should return page by ID")
    void getPageById_shouldReturnPage() {
        when(pageRepository.findById(1L)).thenReturn(Optional.of(page1));

        Page foundPage = pageService.getPageById(1L);

        assertNotNull(foundPage);
        assertEquals("HomePage", foundPage.getPageName());
        verify(pageRepository, times(1)).findById(1L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if page not found by ID")
    void getPageById_shouldThrowNotFoundException() {
        when(pageRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> pageService.getPageById(99L));
        verify(pageRepository, times(1)).findById(99L);
    }

    @Test
    @DisplayName("Should create a new page successfully")
    void createPage_shouldCreatePage() {
        PageCreateRequest request = new PageCreateRequest("NewPage", 3);
        when(featureRepository.existsById(feature.getFeatureId())).thenReturn(true);
        when(pageRepository.findByFeatureIdAndPageName(feature.getFeatureId(), request.getPageName())).thenReturn(Optional.empty());
        when(pageRepository.save(any(Page.class))).thenReturn(page1);

        Page createdPage = pageService.createPage(feature.getFeatureId(), request);

        assertNotNull(createdPage);
        assertEquals("HomePage", createdPage.getPageName()); // Assuming page1 is returned after save
        verify(featureRepository, times(1)).existsById(feature.getFeatureId());
        verify(pageRepository, times(1)).findByFeatureIdAndPageName(feature.getFeatureId(), "NewPage");
        verify(pageRepository, times(1)).save(any(Page.class));
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if feature not found during page creation")
    void createPage_shouldThrowFeatureNotFoundException() {
        PageCreateRequest request = new PageCreateRequest("NewPage", 3);
        when(featureRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> pageService.createPage(999L, request));
        verify(featureRepository, times(1)).existsById(999L);
        verify(pageRepository, never()).save(any(Page.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if page name already exists for feature during creation")
    void createPage_shouldThrowConflictExceptionIfNameExists() {
        PageCreateRequest request = new PageCreateRequest("HomePage", 3);
        when(featureRepository.existsById(feature.getFeatureId())).thenReturn(true);
        when(pageRepository.findByFeatureIdAndPageName(feature.getFeatureId(), request.getPageName())).thenReturn(Optional.of(page1));

        assertThrows(ResourceConflictException.class, () -> pageService.createPage(feature.getFeatureId(), request));
        verify(featureRepository, times(1)).existsById(feature.getFeatureId());
        verify(pageRepository, times(1)).findByFeatureIdAndPageName(feature.getFeatureId(), "HomePage");
        verify(pageRepository, never()).save(any(Page.class));
    }

    @Test
    @DisplayName("Should update an existing page successfully with nested forms and fields")
    void updatePage_shouldUpdatePageWithNestedFormsAndFields() {
        Long featureId = feature.getFeatureId();
        Long pageId = page1.getPageId();

        PageUpdateRequest request = new PageUpdateRequest();
        request.setPageName("UpdatedHomePage");
        request.setPageOrder(1);

        // Nested form update request
        FormNestedUpdateRequest formUpdateReq = new FormNestedUpdateRequest();
        formUpdateReq.setFormId(form1.getFormId());
        formUpdateReq.setFormName("UpdatedLoginForm");
        formUpdateReq.setFormOrder(1);
        formUpdateReq.set_delete(false);

        // Nested field update request
        FieldNestedUpdateRequest fieldUpdateReq = new FieldNestedUpdateRequest();
        fieldUpdateReq.setFieldId(field1.getFieldId());
        fieldUpdateReq.setFieldName("updatedUsername");
        fieldUpdateReq.setFieldType("TEXT");
        fieldUpdateReq.setInputType("TEXT");
        fieldUpdateReq.setDefaultLabel("Updated Username");
        fieldUpdateReq.set_delete(false);

        FieldNestedUpdateRequest fieldCreateReq = new FieldNestedUpdateRequest();
        fieldCreateReq.setFieldName("email");
        fieldCreateReq.setFieldType("TEXT");
        fieldCreateReq.setInputType("EMAIL");
        fieldCreateReq.setDefaultLabel("Email Address");
        fieldCreateReq.set_delete(false);

        formUpdateReq.setFields(Arrays.asList(fieldUpdateReq, fieldCreateReq));
        request.setForms(Collections.singletonList(formUpdateReq));

        // Mocking behavior
        when(pageRepository.findById(pageId)).thenReturn(Optional.of(page1));
        when(pageRepository.findByFeatureIdAndPageName(featureId, request.getPageName())).thenReturn(Optional.empty());
        when(pageRepository.save(any(Page.class))).thenReturn(page1);

        when(formRepository.findByPageId(pageId)).thenReturn(Arrays.asList(form1, form2)); // Existing forms on page
        when(formRepository.findById(form1.getFormId())).thenReturn(Optional.of(form1));
        when(formRepository.save(any(Form.class))).thenAnswer(i -> i.getArguments()[0]); // Return saved form
        when(formRepository.findByPageIdAndFormName(pageId, "NewFormName")).thenReturn(Optional.empty()); // For new form name check

        when(fieldRepository.findByFormId(form1.getFormId())).thenReturn(Arrays.asList(field1, field2)); // Existing fields in form
        when(fieldRepository.findById(field1.getFieldId())).thenReturn(Optional.of(field1));
        when(fieldRepository.save(any(Field.class))).thenAnswer(i -> i.getArguments()[0]); // Return saved field
        when(fieldRepository.findByFormIdAndFieldName(form1.getFormId(), "email")).thenReturn(Optional.empty()); // For new field name check
        when(formRepository.findById(form1.getFormId())).thenReturn(Optional.of(form1)); // For deriving pageId in FieldServiceImpl

        // Act
        Page updatedPage = pageService.updatePage(featureId, pageId, request);

        // Assert
        assertNotNull(updatedPage);
        assertEquals("UpdatedHomePage", updatedPage.getPageName());
        verify(pageRepository, times(1)).save(any(Page.class));
        verify(formRepository, times(1)).save(argThat(f -> f.getFormId().equals(form1.getFormId()) && f.getFormName().equals("UpdatedLoginForm"))); // Verify form update
        verify(fieldRepository, times(1)).save(argThat(f -> f.getFieldId().equals(field1.getFieldId()) && f.getFieldName().equals("updatedUsername"))); // Verify field update
        verify(fieldRepository, times(1)).save(argThat(f -> f.getFieldName().equals("email"))); // Verify field creation
        verify(formRepository, times(1)).deleteAll(Collections.singletonList(form2)); // Verify deletion of form2
        verify(fieldRepository, times(1)).deleteAll(Collections.singletonList(field2)); // Verify deletion of field2
    }


    @Test
    @DisplayName("Should throw BadRequestException if page does not belong to feature during update")
    void updatePage_shouldThrowBadRequestExceptionIfFeatureMismatch() {
        PageUpdateRequest request = new PageUpdateRequest();
        request.setPageName("UpdatedPage");
        request.setPageOrder(1);
        when(pageRepository.findById(page1.getPageId())).thenReturn(Optional.of(page1));

        assertThrows(BadRequestException.class, () -> pageService.updatePage(999L, page1.getPageId(), request));
        verify(pageRepository, times(1)).findById(page1.getPageId());
        verify(pageRepository, never()).save(any(Page.class));
    }

    @Test
    @DisplayName("Should delete a page successfully")
    void deletePage_shouldDeletePage() {
        when(pageRepository.findById(page1.getPageId())).thenReturn(Optional.of(page1));
        doNothing().when(pageRepository).delete(page1);

        assertDoesNotThrow(() -> pageService.deletePage(feature.getFeatureId(), page1.getPageId()));
        verify(pageRepository, times(1)).findById(page1.getPageId());
        verify(pageRepository, times(1)).delete(page1);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if page not found during delete")
    void deletePage_shouldThrowNotFoundException_onDelete() {
        when(pageRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> pageService.deletePage(feature.getFeatureId(), 99L));
        verify(pageRepository, times(1)).findById(99L);
        verify(pageRepository, never()).delete(any(Page.class));
    }

    @Test
    @DisplayName("Should throw BadRequestException if feature mismatch during delete")
    void deletePage_shouldThrowBadRequestException_onDelete() {
        Page anotherPage = new Page();
        anotherPage.setPageId(99L);
        anotherPage.setFeatureId(999L); // Belongs to a different feature
        when(pageRepository.findById(99L)).thenReturn(Optional.of(anotherPage));

        assertThrows(BadRequestException.class, () -> pageService.deletePage(feature.getFeatureId(), 99L));
        verify(pageRepository, times(1)).findById(99L);
        verify(pageRepository, never()).delete(any(Page.class));
    }

    @Test
    @DisplayName("Should return forms by page ID")
    void getFormsByPage_shouldReturnForms() {
        when(formRepository.findByPageId(page1.getPageId())).thenReturn(Arrays.asList(form1, form2));

        List<Form> forms = pageService.getFormsByPage(page1.getPageId());

        assertNotNull(forms);
        assertEquals(2, forms.size());
        assertEquals("LoginForm", forms.get(0).getFormName());
        verify(formRepository, times(1)).findByPageId(page1.getPageId());
    }

    @Test
    @DisplayName("Should return empty list if no forms for page")
    void getFormsByPage_shouldReturnEmptyList() {
        when(formRepository.findByPageId(anyLong())).thenReturn(Collections.emptyList());

        List<Form> forms = pageService.getFormsByPage(99L);

        assertNotNull(forms);
        assertTrue(forms.isEmpty());
        verify(formRepository, times(1)).findByPageId(99L);
    }
}
