package com.yourcompany.config.service;

import com.yourcompany.config.exception.ResourceConflictException;
import com.yourcompany.config.exception.ResourceNotFoundException;
import com.yourcompany.config.model.Field;
import com.yourcompany.config.model.Form;
import com.yourcompany.config.repository.FieldRepository;
import com.yourcompany.config.repository.FormRepository;
import com.yourcompany.config.repository.TenantRepository; // For orchestration method validation
import com.yourcompany.config.repository.ApplicationRepository; // For orchestration method validation
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.fasterxml.jackson.databind.ObjectMapper; // For JSONB mocking
import com.fasterxml.jackson.databind.node.ObjectNode; // For JSONB mocking

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("Field Service Unit Tests")
public class FieldServiceImplTest {

    @Mock
    private FieldRepository fieldRepository;
    @Mock
    private FormRepository formRepository;
    @Mock
    private TenantApplicationFieldConfigService tenantApplicationFieldConfigService; // For orchestration method
    @Mock
    private TenantRepository tenantRepository; // For orchestration method validation
    @Mock
    private ApplicationRepository applicationRepository; // For orchestration method validation

    @InjectMocks
    private FieldServiceImpl fieldService;

    private Form form;
    private Field field1;
    private Field field2;
    private ObjectMapper objectMapper; // For creating JsonNode mocks

    @BeforeEach
    void setUp() {
        LocalDateTime now = LocalDateTime.now();
        String user = "test_user";
        objectMapper = new ObjectMapper();

        form = new Form();
        form.setFormId(10L);
        form.setPageId(1L); // Derived pageId
        form.setFormName("TestForm");
        form.setFormOrder(1);
        form.setCreatedAt(now);
        form.setUpdatedAt(now);
        form.setCreatedBy(user);
        form.setUpdatedBy(user);

        field1 = new Field();
        field1.setFieldId(100L);
        field1.setFormId(form.getFormId());
        // Removed: field1.setPageId(form.getPageId()); // Derived - No longer directly on Field
        field1.setFieldName("username");
        field1.setFieldType("TEXT");
        field1.setInputType("TEXT");
        field1.setDefaultLabel("Username");
        field1.setDefaultValidationRules(objectMapper.createObjectNode().put("minLength", 5));
        field1.setCreatedAt(now);
        field1.setUpdatedAt(now);
        field1.setCreatedBy(user);
        field1.setUpdatedBy(user);

        field2 = new Field();
        field2.setFieldId(101L);
        field2.setFormId(form.getFormId());
        // Removed: field2.setPageId(form.getPageId()); // Derived - No longer directly on Field
        field2.setFieldName("password");
        field2.setFieldType("TEXT");
        field2.setInputType("PASSWORD");
        field2.setDefaultLabel("Password");
        field2.setDefaultValidationRules(objectMapper.createObjectNode().put("required", true));
        field2.setCreatedAt(now);
        field2.setUpdatedAt(now);
        field2.setCreatedBy(user);
        field2.setUpdatedBy(user);
    }

    @Test
    @DisplayName("Should return field by ID")
    void getFieldById_shouldReturnField() {
        when(fieldRepository.findById(100L)).thenReturn(Optional.of(field1));

        Field foundField = fieldService.getFieldById(100L);

        assertNotNull(foundField);
        assertEquals("username", foundField.getFieldName());
        verify(fieldRepository, times(1)).findById(100L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if field not found by ID")
    void getFieldById_shouldThrowNotFoundException() {
        when(fieldRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> fieldService.getFieldById(999L));
        verify(fieldRepository, times(1)).findById(999L);
    }

    @Test
    @DisplayName("Should create a new field successfully")
    void createField_shouldCreateField() {
        FieldCreateRequest request = new FieldCreateRequest(form.getFormId(), "NewField", "NUMBER", "NUMBER", "New Field Label", null);
        when(formRepository.existsById(form.getFormId())).thenReturn(true);
        when(fieldRepository.findByFormIdAndFieldName(form.getFormId(), request.getFieldName())).thenReturn(Optional.empty());
        when(fieldRepository.save(any(Field.class))).thenReturn(field1);

        Field createdField = fieldService.createField(request);

        assertNotNull(createdField);
        assertEquals("username", createdField.getFieldName()); // Assuming field1 is returned after save
        verify(formRepository, times(1)).existsById(form.getFormId());
        verify(fieldRepository, times(1)).findByFormIdAndFieldName(form.getFormId(), "NewField");
        verify(fieldRepository, times(1)).save(any(Field.class));
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if form not found during field creation")
    void createField_shouldThrowFormNotFoundException() {
        FieldCreateRequest request = new FieldCreateRequest(99L, "NewField", "TEXT", "TEXT", "Label", null);
        when(formRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> fieldService.createField(request));
        verify(formRepository, times(1)).existsById(99L);
        verify(fieldRepository, never()).save(any(Field.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if field name already exists for form during creation")
    void createField_shouldThrowConflictExceptionIfNameExists() {
        FieldCreateRequest request = new FieldCreateRequest(form.getFormId(), "username", "TEXT", "TEXT", "Label", null);
        when(formRepository.existsById(form.getFormId())).thenReturn(true);
        when(fieldRepository.findByFormIdAndFieldName(form.getFormId(), request.getFieldName())).thenReturn(Optional.of(field1));

        assertThrows(ResourceConflictException.class, () -> fieldService.createField(request));
        verify(formRepository, times(1)).existsById(form.getFormId());
        verify(fieldRepository, times(1)).findByFormIdAndFieldName(form.getFormId(), "username");
        verify(fieldRepository, never()).save(any(Field.class));
    }

    @Test
    @DisplayName("Should delete a field successfully")
    void deleteField_shouldDeleteField() {
        when(fieldRepository.existsById(100L)).thenReturn(true);
        doNothing().when(fieldRepository).deleteById(100L);

        assertDoesNotThrow(() -> fieldService.deleteField(100L));
        verify(fieldRepository, times(1)).existsById(100L);
        verify(fieldRepository, times(1)).deleteById(100L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if field not found during delete")
    void deleteField_shouldThrowNotFoundException() {
        when(fieldRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> fieldService.deleteField(999L));
        verify(fieldRepository, times(1)).existsById(999L);
        verify(fieldRepository, never()).deleteById(anyLong());
    }
}
