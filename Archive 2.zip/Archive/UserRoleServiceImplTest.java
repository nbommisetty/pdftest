package com.yourcompany.config.service;

import com.yourcompany.config.exception.ResourceConflictException;
import com.yourcompany.config.exception.ResourceNotFoundException;
import com.yourcompany.config.model.UserRole;
import com.yourcompany.config.repository.UserRoleRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("UserRole Service Unit Tests")
public class UserRoleServiceImplTest {

    @Mock
    private UserRoleRepository userRoleRepository;

    @InjectMocks
    private UserRoleServiceImpl userRoleService;

    private UserRole role1;
    private UserRole role2;

    @BeforeEach
    void setUp() {
        LocalDateTime now = LocalDateTime.now();
        String user = "test_user";

        role1 = new UserRole();
        role1.setRoleId(1L);
        role1.setRoleName("business-admin");
        role1.setRoleDescription("Business Administrator");
        role1.setCreatedAt(now);
        role1.setUpdatedAt(now);
        role1.setCreatedBy(user);
        role1.setUpdatedBy(user);

        role2 = new UserRole();
        role2.setRoleId(2L);
        role2.setRoleName("business-subuser");
        role2.setRoleDescription("Business Subuser");
        role2.setCreatedAt(now);
        role2.setUpdatedAt(now);
        role2.setCreatedBy(user);
        role2.setUpdatedBy(user);
    }

    @Test
    @DisplayName("Should return all user roles")
    void getAllUserRoles_shouldReturnAllRoles() {
        when(userRoleRepository.findAll()).thenReturn(Arrays.asList(role1, role2));

        List<UserRole> roles = userRoleService.getAllUserRoles();

        assertNotNull(roles);
        assertEquals(2, roles.size());
        assertEquals("business-admin", roles.get(0).getRoleName());
        verify(userRoleRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Should return user role by ID")
    void getUserRoleById_shouldReturnRole() {
        when(userRoleRepository.findById(1L)).thenReturn(Optional.of(role1));

        UserRole foundRole = userRoleService.getUserRoleById(1L);

        assertNotNull(foundRole);
        assertEquals("business-admin", foundRole.getRoleName());
        verify(userRoleRepository, times(1)).findById(1L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if user role not found by ID")
    void getUserRoleById_shouldThrowNotFoundException() {
        when(userRoleRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> userRoleService.getUserRoleById(99L));
        verify(userRoleRepository, times(1)).findById(99L);
    }

    @Test
    @DisplayName("Should create a new user role successfully")
    void createUserRole_shouldCreateRole() {
        UserRoleCreateRequest request = new UserRoleCreateRequest("new-role", "New Role Description");
        when(userRoleRepository.findByRoleName(request.getRoleName())).thenReturn(Optional.empty());
        when(userRoleRepository.save(any(UserRole.class))).thenReturn(role1);

        UserRole createdRole = userRoleService.createUserRole(request);

        assertNotNull(createdRole);
        assertEquals("business-admin", createdRole.getRoleName()); // Assuming role1 is returned after save
        verify(userRoleRepository, times(1)).findByRoleName("new-role");
        verify(userRoleRepository, times(1)).save(any(UserRole.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if role name already exists during creation")
    void createUserRole_shouldThrowConflictExceptionIfNameExists() {
        UserRoleCreateRequest request = new UserRoleCreateRequest("business-admin", "Existing Role Description");
        when(userRoleRepository.findByRoleName(request.getRoleName())).thenReturn(Optional.of(role1));

        assertThrows(ResourceConflictException.class, () -> userRoleService.createUserRole(request));
        verify(userRoleRepository, times(1)).findByRoleName("business-admin");
        verify(userRoleRepository, never()).save(any(UserRole.class));
    }

    @Test
    @DisplayName("Should update an existing user role successfully (full replacement)")
    void updateUserRole_shouldUpdateRole() {
        UserRoleUpdateRequest request = new UserRoleUpdateRequest("updated-admin", "Updated Description");
        when(userRoleRepository.findById(1L)).thenReturn(Optional.of(role1));
        when(userRoleRepository.findByRoleName(request.getRoleName())).thenReturn(Optional.empty());
        when(userRoleRepository.save(any(UserRole.class))).thenReturn(role1);

        UserRole updatedRole = userRoleService.updateUserRole(1L, request);

        assertNotNull(updatedRole);
        assertEquals("updated-admin", updatedRole.getRoleName());
        assertEquals("Updated Description", updatedRole.getRoleDescription());
        verify(userRoleRepository, times(1)).findById(1L);
        verify(userRoleRepository, times(1)).findByRoleName("updated-admin");
        verify(userRoleRepository, times(1)).save(role1);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if user role not found during update")
    void updateUserRole_shouldThrowNotFoundException() {
        UserRoleUpdateRequest request = new UserRoleUpdateRequest("UpdatedRole", null);
        when(userRoleRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> userRoleService.updateUserRole(99L, request));
        verify(userRoleRepository, times(1)).findById(99L);
        verify(userRoleRepository, never()).save(any(UserRole.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if updated user role name already exists")
    void updateUserRole_shouldThrowConflictExceptionIfNameExists() {
        UserRoleUpdateRequest request = new UserRoleUpdateRequest("business-subuser", null);
        when(userRoleRepository.findById(1L)).thenReturn(Optional.of(role1));
        when(userRoleRepository.findByRoleName("business-subuser")).thenReturn(Optional.of(role2));

        assertThrows(ResourceConflictException.class, () -> userRoleService.updateUserRole(1L, request));
        verify(userRoleRepository, times(1)).findById(1L);
        verify(userRoleRepository, times(1)).findByRoleName("business-subuser");
        verify(userRoleRepository, never()).save(any(UserRole.class));
    }

    @Test
    @DisplayName("Should partially update an existing user role successfully")
    void patchUserRole_shouldPatchRole() {
        UserRolePatchRequest request = new UserRolePatchRequest();
        request.setRoleDescription("Patched Description");
        when(userRoleRepository.findById(1L)).thenReturn(Optional.of(role1));
        when(userRoleRepository.save(any(UserRole.class))).thenReturn(role1);

        UserRole patchedRole = userRoleService.patchUserRole(1L, request);

        assertNotNull(patchedRole);
        assertEquals("business-admin", patchedRole.getRoleName());
        assertEquals("Patched Description", patchedRole.getRoleDescription());
        verify(userRoleRepository, times(1)).findById(1L);
        verify(userRoleRepository, times(1)).save(role1);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if user role not found during patch")
    void patchUserRole_shouldThrowNotFoundException() {
        UserRolePatchRequest request = new UserRolePatchRequest();
        request.setRoleName("NonExistentRole");
        when(userRoleRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> userRoleService.patchUserRole(99L, request));
        verify(userRoleRepository, times(1)).findById(99L);
        verify(userRoleRepository, never()).save(any(UserRole.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if patched user role name already exists")
    void patchUserRole_shouldThrowConflictExceptionIfNameExists() {
        UserRolePatchRequest request = new UserRolePatchRequest();
        request.setRoleName("business-subuser");
        when(userRoleRepository.findById(1L)).thenReturn(Optional.of(role1));
        when(userRoleRepository.findByRoleName("business-subuser")).thenReturn(Optional.of(role2));

        assertThrows(ResourceConflictException.class, () -> userRoleService.patchUserRole(1L, request));
        verify(userRoleRepository, times(1)).findById(1L);
        verify(userRoleRepository, times(1)).findByRoleName("business-subuser");
        verify(userRoleRepository, never()).save(any(UserRole.class));
    }

    @Test
    @DisplayName("Should delete a user role successfully")
    void deleteUserRole_shouldDeleteRole() {
        when(userRoleRepository.existsById(1L)).thenReturn(true);
        doNothing().when(userRoleRepository).deleteById(1L);

        assertDoesNotThrow(() -> userRoleService.deleteUserRole(1L));
        verify(userRoleRepository, times(1)).existsById(1L);
        verify(userRoleRepository, times(1)).deleteById(1L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if user role not found during delete")
    void deleteUserRole_shouldThrowNotFoundException() {
        when(userRoleRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> userRoleService.deleteUserRole(99L));
        verify(userRoleRepository, times(1)).existsById(99L);
        verify(userRoleRepository, never()).deleteById(anyLong());
    }
}
