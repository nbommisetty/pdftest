package com.yourcompany.config.service;

import com.yourcompany.config.exception.BadRequestException;
import com.yourcompany.config.exception.ResourceConflictException;
import com.yourcompany.config.exception.ResourceNotFoundException;
import com.yourcompany.config.model.Form;
import com.yourcompany.config.model.Page;
import com.yourcompany.config.model.Field;
import com.yourcompany.config.repository.FormRepository;
import com.yourcompany.config.repository.PageRepository;
import com.yourcompany.config.repository.FieldRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("Form Service Unit Tests")
public class FormServiceImplTest {

    @Mock
    private FormRepository formRepository;
    @Mock
    private PageRepository pageRepository;
    @Mock
    private FieldRepository fieldRepository;

    @InjectMocks
    private FormServiceImpl formService;

    private Page page;
    private Form form1;
    private Form form2;
    private Field field1, field2;

    @BeforeEach
    void setUp() {
        LocalDateTime now = LocalDateTime.now();
        String user = "test_user";

        page = new Page();
        page.setPageId(1L);
        page.setFeatureId(100L);
        page.setPageName("TestPage");
        page.setPageOrder(1);
        page.setCreatedAt(now);
        page.setUpdatedAt(now);
        page.setCreatedBy(user);
        page.setUpdatedBy(user);

        form1 = new Form();
        form1.setFormId(10L);
        form1.setPageId(page.getPageId());
        form1.setFormName("LoginForm");
        form1.setFormOrder(1);
        form1.setCreatedAt(now);
        form1.setUpdatedAt(now);
        form1.setCreatedBy(user);
        form1.setUpdatedBy(user);

        form2 = new Form();
        form2.setFormId(11L);
        form2.setPageId(page.getPageId());
        form2.setFormName("RegisterForm");
        form2.setFormOrder(2);
        form2.setCreatedAt(now);
        form2.setUpdatedAt(now);
        form2.setCreatedBy(user);
        form2.setUpdatedBy(user);

        field1 = new Field();
        field1.setFieldId(100L);
        field1.setFormId(form1.getFormId());
        field1.setFieldName("username");
        field1.setFieldType("TEXT");
        field1.setInputType("TEXT");
        field1.setDefaultLabel("Username");
        field1.setCreatedAt(now);
        field1.setUpdatedAt(now);
        field1.setCreatedBy(user);
        field1.setUpdatedBy(user);

        field2 = new Field(); // Initialize field2
        field2.setFieldId(101L);
        field2.setFormId(form1.getFormId());
        // Removed: field2.setPageId(page.getPageId()); // Derived - No longer directly on Field
        field2.setFieldName("password");
        field2.setFieldType("TEXT");
        field2.setInputType("PASSWORD");
        field2.setDefaultLabel("Password");
        field2.setCreatedAt(now);
        field2.setUpdatedAt(now);
        field2.setCreatedBy(user);
        field2.setUpdatedBy(user);
    }

    @Test
    @DisplayName("Should return form by ID")
    void getFormById_shouldReturnForm() {
        when(formRepository.findById(10L)).thenReturn(Optional.of(form1));

        Form foundForm = formService.getFormById(10L);

        assertNotNull(foundForm);
        assertEquals("LoginForm", foundForm.getFormName());
        verify(formRepository, times(1)).findById(10L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if form not found by ID")
    void getFormById_shouldThrowNotFoundException() {
        when(formRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> formService.getFormById(99L));
        verify(formRepository, times(1)).findById(99L);
    }

    @Test
    @DisplayName("Should create a new form successfully")
    void createForm_shouldCreateForm() {
        FormCreateRequest request = new FormCreateRequest("NewForm", 3);
        when(pageRepository.existsById(page.getPageId())).thenReturn(true);
        when(formRepository.findByPageIdAndFormName(page.getPageId(), request.getFormName())).thenReturn(Optional.empty());
        when(formRepository.save(any(Form.class))).thenReturn(form1);

        Form createdForm = formService.createForm(page.getPageId(), request);

        assertNotNull(createdForm);
        assertEquals("LoginForm", createdForm.getFormName()); // Assuming form1 is returned after save
        verify(pageRepository, times(1)).existsById(page.getPageId());
        verify(formRepository, times(1)).findByPageIdAndFormName(page.getPageId(), "NewForm");
        verify(formRepository, times(1)).save(any(Form.class));
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if page not found during form creation")
    void createForm_shouldThrowPageNotFoundException() {
        FormCreateRequest request = new FormCreateRequest("NewForm", 3);
        when(pageRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> formService.createForm(99L, request));
        verify(pageRepository, times(1)).existsById(99L);
        verify(formRepository, never()).save(any(Form.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if form name already exists for page during creation")
    void createForm_shouldThrowConflictExceptionIfNameExists() {
        FormCreateRequest request = new FormCreateRequest("LoginForm", 3);
        when(pageRepository.existsById(page.getPageId())).thenReturn(true);
        when(formRepository.findByPageIdAndFormName(page.getPageId(), request.getFormName())).thenReturn(Optional.of(form1));

        assertThrows(ResourceConflictException.class, () -> formService.createForm(page.getPageId(), request));
        verify(pageRepository, times(1)).existsById(page.getPageId());
        verify(formRepository, times(1)).findByPageIdAndFormName(page.getPageId(), "LoginForm");
        verify(formRepository, never()).save(any(Form.class));
    }

    @Test
    @DisplayName("Should delete a form successfully")
    void deleteForm_shouldDeleteForm() {
        when(formRepository.findById(form1.getFormId())).thenReturn(Optional.of(form1));
        doNothing().when(formRepository).delete(form1);

        assertDoesNotThrow(() -> formService.deleteForm(page.getPageId(), form1.getFormId()));
        verify(formRepository, times(1)).findById(form1.getFormId());
        verify(formRepository, times(1)).delete(form1);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if form not found during delete")
    void deleteForm_shouldThrowNotFoundException_onDelete() {
        when(formRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> formService.deleteForm(page.getPageId(), 99L));
        verify(formRepository, times(1)).findById(99L);
        verify(formRepository, never()).delete(any(Form.class));
    }

    @Test
    @DisplayName("Should throw BadRequestException if page mismatch during delete")
    void deleteForm_shouldThrowBadRequestException_onDelete() {
        Form anotherForm = new Form();
        anotherForm.setFormId(99L);
        anotherForm.setPageId(999L); // Belongs to a different page
        when(formRepository.findById(99L)).thenReturn(Optional.of(anotherForm));

        assertThrows(BadRequestException.class, () -> formService.deleteForm(page.getPageId(), 99L));
        verify(formRepository, times(1)).findById(99L);
        verify(formRepository, never()).delete(any(Form.class));
    }

    @Test
    @DisplayName("Should return fields by form ID")
    void getFieldsByForm_shouldReturnFields() {
        when(fieldRepository.findByFormId(form1.getFormId())).thenReturn(Arrays.asList(field1, field2));

        List<Field> fields = formService.getFieldsByForm(form1.getFormId());

        assertNotNull(fields);
        assertEquals(2, fields.size());
        assertEquals("username", fields.get(0).getFieldName());
        verify(fieldRepository, times(1)).findByFormId(form1.getFormId());
    }

    @Test
    @DisplayName("Should return empty list if no fields for form")
    void getFieldsByForm_shouldReturnEmptyList() {
        when(fieldRepository.findByFormId(anyLong())).thenReturn(Collections.emptyList());

        List<Field> fields = formService.getFieldsByForm(99L);

        assertNotNull(fields);
        assertTrue(fields.isEmpty());
        verify(fieldRepository, times(1)).findByFormId(99L);
    }
}
