package com.yourcompany.config.service;

import com.yourcompany.config.exception.BadRequestException;
import com.yourcompany.config.exception.ResourceConflictException;
import com.yourcompany.config.exception.ResourceNotFoundException;
import com.yourcompany.config.model.Application;
import com.yourcompany.config.model.Feature;
import com.yourcompany.config.model.FeatureApplication;
import com.yourcompany.config.model.Page;
import com.yourcompany.config.model.Form;
import com.yourcompany.config.model.Field;
import com.yourcompany.config.model.Tenant;
import com.yourcompany.config.model.UserRole;
import com.yourcompany.config.model.TenantApplicationFeatureConfig;
import com.yourcompany.config.model.Theme;
import com.yourcompany.config.repository.FeatureRepository;
import com.yourcompany.config.repository.PageRepository;
import com.yourcompany.config.repository.FormRepository;
import com.yourcompany.config.repository.FieldRepository;
import com.yourcompany.config.repository.TenantRepository;
import com.yourcompany.config.repository.ApplicationRepository;
import com.yourcompany.config.repository.UserRoleRepository;
import com.yourcompany.config.repository.ThemeRepository;
import com.yourcompany.config.repository.TenantApplicationFeatureConfigRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("Feature Service Unit Tests")
public class FeatureServiceImplTest {

    @Mock
    private FeatureRepository featureRepository;
    @Mock
    private PageRepository pageRepository;
    @Mock
    private FormRepository formRepository;
    @Mock
    private FieldRepository fieldRepository;
    @Mock
    private TenantApplicationFeatureConfigRepository tenantApplicationFeatureConfigRepository;
    @Mock
    private TenantApplicationFieldConfigService tenantApplicationFieldConfigService;
    @Mock
    private TenantRepository tenantRepository;
    @Mock
    private ApplicationRepository applicationRepository;
    @Mock
    private UserRoleRepository userRoleRepository;
    @Mock
    private ThemeRepository themeRepository;

    @InjectMocks
    private FeatureServiceImpl featureService;

    private Feature feature1;
    private Feature feature2;
    private Page page1;
    private Page page2;

    @BeforeEach
    void setUp() {
        LocalDateTime now = LocalDateTime.now();
        String user = "test_user";

        feature1 = new Feature();
        feature1.setFeatureId(201L);
        feature1.setFeatureName("WireTransfer");
        feature1.setFeatureDescription("Allows users to initiate wire transfers.");
        feature1.setCreatedAt(now);
        feature1.setUpdatedAt(now);
        feature1.setCreatedBy(user);
        feature1.setUpdatedBy(user);

        feature2 = new Feature();
        feature2.setFeatureId(202L);
        feature2.setFeatureName("DirectDeposit");
        feature2.setFeatureDescription("Manages direct deposits.");
        feature2.setCreatedAt(now);
        feature2.setUpdatedAt(now);
        feature2.setCreatedBy(user);
        feature2.setUpdatedBy(user);

        page1 = new Page();
        page1.setPageId(301L);
        page1.setFeatureId(feature1.getFeatureId());
        page1.setPageName("InitiateTransferPage");
        page1.setPageOrder(1);
        page1.setCreatedAt(now);
        page1.setUpdatedAt(now);
        page1.setCreatedBy(user);
        page1.setUpdatedBy(user);

        page2 = new Page();
        page2.setPageId(302L);
        page2.setFeatureId(feature1.getFeatureId());
        page2.setPageName("ReviewTransferPage");
        page2.setPageOrder(2);
        page2.setCreatedAt(now);
        page2.setUpdatedAt(now);
        page2.setCreatedBy(user);
        page2.setUpdatedBy(user);
    }

    @Test
    @DisplayName("Should return all features")
    void getAllFeatures_shouldReturnAllFeatures() {
        when(featureRepository.findAll()).thenReturn(Arrays.asList(feature1, feature2));

        List<Feature> features = featureService.getAllFeatures();

        assertNotNull(features);
        assertEquals(2, features.size());
        assertEquals("WireTransfer", features.get(0).getFeatureName());
        verify(featureRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Should return feature by ID")
    void getFeatureById_shouldReturnFeature() {
        when(featureRepository.findById(201L)).thenReturn(Optional.of(feature1));

        Feature foundFeature = featureService.getFeatureById(201L);

        assertNotNull(foundFeature);
        assertEquals("WireTransfer", foundFeature.getFeatureName());
        verify(featureRepository, times(1)).findById(201L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if feature not found by ID")
    void getFeatureById_shouldThrowNotFoundException() {
        when(featureRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> featureService.getFeatureById(999L));
        verify(featureRepository, times(1)).findById(999L);
    }

    @Test
    @DisplayName("Should create a new feature successfully")
    void createFeature_shouldCreateFeature() {
        FeatureCreateRequest request = new FeatureCreateRequest("NewFeature", "New Feature Description");
        when(featureRepository.findByFeatureName(request.getFeatureName())).thenReturn(Optional.empty());
        when(featureRepository.save(any(Feature.class))).thenReturn(feature1);

        Feature createdFeature = featureService.createFeature(request);

        assertNotNull(createdFeature);
        assertEquals("WireTransfer", createdFeature.getFeatureName());
        verify(featureRepository, times(1)).findByFeatureName("NewFeature");
        verify(featureRepository, times(1)).save(any(Feature.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if feature name already exists during creation")
    void createFeature_shouldThrowConflictExceptionIfNameExists() {
        FeatureCreateRequest request = new FeatureCreateRequest("WireTransfer", "Existing Feature Description");
        when(featureRepository.findByFeatureName(request.getFeatureName())).thenReturn(Optional.of(feature1));

        assertThrows(ResourceConflictException.class, () -> featureService.createFeature(request));
        verify(featureRepository, times(1)).findByFeatureName("WireTransfer");
        verify(featureRepository, never()).save(any(Feature.class));
    }

    @Test
    @DisplayName("Should update an existing feature successfully (full replacement)")
    void updateFeature_shouldUpdateFeature() {
        FeatureUpdateRequest request = new FeatureUpdateRequest("UpdatedWireTransfer", "Updated Description");
        when(featureRepository.findById(201L)).thenReturn(Optional.of(feature1));
        when(featureRepository.findByFeatureName(request.getFeatureName())).thenReturn(Optional.empty());
        when(featureRepository.save(any(Feature.class))).thenReturn(feature1);

        Feature updatedFeature = featureService.updateFeature(201L, request);

        assertNotNull(updatedFeature);
        assertEquals("UpdatedWireTransfer", updatedFeature.getFeatureName());
        assertEquals("Updated Description", updatedFeature.getFeatureDescription());
        verify(featureRepository, times(1)).findById(201L);
        verify(featureRepository, times(1)).findByFeatureName("UpdatedWireTransfer");
        verify(featureRepository, times(1)).save(feature1);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if feature not found during update")
    void updateFeature_shouldThrowNotFoundException() {
        FeatureUpdateRequest request = new FeatureUpdateRequest("UpdatedFeature", null);
        when(featureRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> featureService.updateFeature(999L, request));
        verify(featureRepository, times(1)).findById(999L);
        verify(featureRepository, never()).save(any(Feature.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if updated feature name already exists")
    void updateFeature_shouldThrowConflictExceptionIfNameExists() {
        FeatureUpdateRequest request = new FeatureUpdateRequest("DirectDeposit", null);
        when(featureRepository.findById(201L)).thenReturn(Optional.of(feature1));
        when(featureRepository.findByFeatureName("DirectDeposit")).thenReturn(Optional.of(feature2));

        assertThrows(ResourceConflictException.class, () -> featureService.updateFeature(201L, request));
        verify(featureRepository, times(1)).findById(201L);
        verify(featureRepository, times(1)).findByFeatureName("DirectDeposit");
        verify(featureRepository, never()).save(any(Feature.class));
    }

    @Test
    @DisplayName("Should partially update an existing feature successfully")
    void patchFeature_shouldPatchFeature() {
        FeaturePatchRequest request = new FeaturePatchRequest();
        request.setFeatureDescription("Patched Description");
        when(featureRepository.findById(201L)).thenReturn(Optional.of(feature1));
        when(featureRepository.save(any(Feature.class))).thenReturn(feature1);

        Feature patchedFeature = featureService.patchFeature(201L, request);

        assertNotNull(patchedFeature);
        assertEquals("WireTransfer", patchedFeature.getFeatureName());
        assertEquals("Patched Description", patchedFeature.getFeatureDescription());
        verify(featureRepository, times(1)).findById(201L);
        verify(featureRepository, times(1)).save(feature1);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if feature not found during patch")
    void patchFeature_shouldThrowNotFoundException() {
        FeaturePatchRequest request = new FeaturePatchRequest();
        request.setFeatureName("NonExistentFeature");
        when(featureRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> featureService.patchFeature(999L, request));
        verify(featureRepository, times(1)).findById(999L);
        verify(featureRepository, never()).save(any(Feature.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if patched feature name already exists")
    void patchFeature_shouldThrowConflictExceptionIfNameExists() {
        FeaturePatchRequest request = new FeaturePatchRequest();
        request.setFeatureName("DirectDeposit");
        when(featureRepository.findById(201L)).thenReturn(Optional.of(feature1));
        when(featureRepository.findByFeatureName("DirectDeposit")).thenReturn(Optional.of(feature2));

        assertThrows(ResourceConflictException.class, () -> featureService.patchFeature(201L, request));
        verify(featureRepository, times(1)).findById(201L);
        verify(featureRepository, times(1)).findByFeatureName("DirectDeposit");
        verify(featureRepository, never()).save(any(Feature.class));
    }

    @Test
    @DisplayName("Should delete a feature successfully")
    void deleteFeature_shouldDeleteFeature() {
        when(featureRepository.existsById(201L)).thenReturn(true);
        doNothing().when(featureRepository).deleteById(201L);

        assertDoesNotThrow(() -> featureService.deleteFeature(201L));
        verify(featureRepository, times(1)).existsById(201L);
        verify(featureRepository, times(1)).deleteById(201L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if feature not found during delete")
    void deleteFeature_shouldThrowNotFoundException() {
        when(featureRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> featureService.deleteFeature(999L));
        verify(featureRepository, times(1)).existsById(999L);
        verify(featureRepository, never()).deleteById(anyLong());
    }

    @Test
    @DisplayName("Should return pages by feature ID")
    void getPagesByFeature_shouldReturnPages() {
        when(pageRepository.findByFeatureId(feature1.getFeatureId())).thenReturn(Arrays.asList(page1, page2));

        List<Page> pages = featureService.getPagesByFeature(feature1.getFeatureId());

        assertNotNull(pages);
        assertEquals(2, pages.size());
        assertEquals("InitiateTransferPage", pages.get(0).getPageName());
        verify(pageRepository, times(1)).findByFeatureId(feature1.getFeatureId());
    }

    @Test
    @DisplayName("Should return empty list if no pages for feature")
    void getPagesByFeature_shouldReturnEmptyList() {
        when(pageRepository.findByFeatureId(anyLong())).thenReturn(Collections.emptyList());

        List<Page> pages = featureService.getPagesByFeature(999L);

        assertNotNull(pages);
        assertTrue(pages.isEmpty());
        verify(pageRepository, times(1)).findByFeatureId(999L);
    }
}
