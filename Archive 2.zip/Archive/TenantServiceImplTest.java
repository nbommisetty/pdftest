package com.yourcompany.config.service;

import com.yourcompany.config.exception.BadRequestException;
import com.yourcompany.config.exception.ResourceConflictException;
import com.yourcompany.config.exception.ResourceNotFoundException;
import com.yourcompany.config.model.Tenant;
import com.yourcompany.config.model.Theme;
import com.yourcompany.config.repository.TenantRepository;
import com.yourcompany.config.repository.ThemeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("Tenant Service Unit Tests")
public class TenantServiceImplTest {

    @Mock // Mock the dependencies of TenantServiceImpl
    private TenantRepository tenantRepository;
    @Mock
    private ThemeRepository themeRepository;

    @InjectMocks // Inject the mocked dependencies into TenantServiceImpl
    private TenantServiceImpl tenantService;

    // Sample data for tests
    private Tenant tenant1;
    private Tenant tenant2;
    private Theme theme1;
    private Theme theme2;

    @BeforeEach
    void setUp() {
        // Initialize sample data before each test
        tenant1 = new Tenant();
        tenant1.setTenantId(1L);
        tenant1.setTenantName("TenantA");
        tenant1.setCreatedAt(LocalDateTime.now());
        tenant1.setUpdatedAt(LocalDateTime.now());
        tenant1.setCreatedBy("test_user");
        tenant1.setUpdatedBy("test_user");

        tenant2 = new Tenant();
        tenant2.setTenantId(2L);
        tenant2.setTenantName("TenantB");
        tenant2.setCreatedAt(LocalDateTime.now());
        tenant2.setUpdatedAt(LocalDateTime.now());
        tenant2.setCreatedBy("test_user");
        tenant2.setUpdatedBy("test_user");

        theme1 = new Theme();
        theme1.setThemeId(101L);
        theme1.setThemeName("dark");

        theme2 = new Theme();
        theme2.setThemeId(102L);
        theme2.setThemeName("classic");
    }

    @Test
    @DisplayName("Should return all tenants")
    void getAllTenants_shouldReturnAllTenants() {
        when(tenantRepository.findAll()).thenReturn(Arrays.asList(tenant1, tenant2));

        List<Tenant> tenants = tenantService.getAllTenants(null, 0, 10); // Pass null for filter, 0 for page, 10 for size
        
        assertNotNull(tenants);
        assertEquals(2, tenants.size());
        assertEquals("TenantA", tenants.get(0).getTenantName());
        assertEquals("TenantB", tenants.get(1).getTenantName());
        verify(tenantRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Should return tenant by ID")
    void getTenantById_shouldReturnTenant() {
        when(tenantRepository.findById(1L)).thenReturn(Optional.of(tenant1));

        Tenant foundTenant = tenantService.getTenantById(1L);

        assertNotNull(foundTenant);
        assertEquals("TenantA", foundTenant.getTenantName());
        verify(tenantRepository, times(1)).findById(1L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if tenant not found by ID")
    void getTenantById_shouldThrowNotFoundException() {
        when(tenantRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> tenantService.getTenantById(99L));
        verify(tenantRepository, times(1)).findById(99L);
    }

    @Test
    @DisplayName("Should create a new tenant successfully")
    void createTenant_shouldCreateTenant() {
        TenantCreateRequest request = new TenantCreateRequest("NewTenant", null);
        when(tenantRepository.findByTenantName(request.getTenantName())).thenReturn(Optional.empty());
        when(tenantRepository.save(any(Tenant.class))).thenReturn(tenant1); // Mock save behavior

        Tenant createdTenant = tenantService.createTenant(request);

        assertNotNull(createdTenant);
        assertEquals("TenantA", createdTenant.getTenantName()); // Assuming tenant1 is returned after save
        verify(tenantRepository, times(1)).findByTenantName("NewTenant");
        verify(tenantRepository, times(1)).save(any(Tenant.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if tenant name already exists during creation")
    void createTenant_shouldThrowConflictExceptionIfNameExists() {
        TenantCreateRequest request = new TenantCreateRequest("ExistingTenant", null);
        when(tenantRepository.findByTenantName(request.getTenantName())).thenReturn(Optional.of(tenant1));

        assertThrows(ResourceConflictException.class, () -> tenantService.createTenant(request));
        verify(tenantRepository, times(1)).findByTenantName("ExistingTenant");
        verify(tenantRepository, never()).save(any(Tenant.class));
    }

    @Test
    @DisplayName("Should throw BadRequestException if invalid themeId during creation")
    void createTenant_shouldThrowBadRequestExceptionIfInvalidThemeId() {
        TenantCreateRequest request = new TenantCreateRequest("NewTenant", 999L);
        when(tenantRepository.findByTenantName(request.getTenantName())).thenReturn(Optional.empty());
        when(themeRepository.existsById(999L)).thenReturn(false);

        assertThrows(BadRequestException.class, () -> tenantService.createTenant(request));
        verify(tenantRepository, times(1)).findByTenantName("NewTenant");
        verify(themeRepository, times(1)).existsById(999L);
        verify(tenantRepository, never()).save(any(Tenant.class));
    }

    @Test
    @DisplayName("Should update an existing tenant successfully")
    void updateTenant_shouldUpdateTenant() {
        TenantUpdateRequest request = new TenantUpdateRequest("UpdatedTenantA", theme2.getThemeId());
        when(tenantRepository.findById(1L)).thenReturn(Optional.of(tenant1));
        when(tenantRepository.findByTenantName(request.getTenantName())).thenReturn(Optional.empty()); // No conflict
        when(themeRepository.existsById(theme2.getThemeId())).thenReturn(true);
        when(tenantRepository.save(any(Tenant.class))).thenReturn(tenant1); // Mock save behavior

        Tenant updatedTenant = tenantService.updateTenant(1L, request);

        assertNotNull(updatedTenant);
        assertEquals("UpdatedTenantA", updatedTenant.getTenantName());
        assertEquals(theme2.getThemeId(), updatedTenant.getThemeId());
        verify(tenantRepository, times(1)).findById(1L);
        verify(tenantRepository, times(1)).findByTenantName("UpdatedTenantA");
        verify(themeRepository, times(1)).existsById(theme2.getThemeId());
        verify(tenantRepository, times(1)).save(tenant1);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if tenant not found during update")
    void updateTenant_shouldThrowNotFoundException() {
        TenantUpdateRequest request = new TenantUpdateRequest("UpdatedTenant", null);
        when(tenantRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> tenantService.updateTenant(99L, request));
        verify(tenantRepository, times(1)).findById(99L);
        verify(tenantRepository, never()).findByTenantName(anyString());
        verify(tenantRepository, never()).save(any(Tenant.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if updated tenant name already exists")
    void updateTenant_shouldThrowConflictExceptionIfNameExists() {
        TenantUpdateRequest request = new TenantUpdateRequest("TenantB", null); // Try to rename TenantA to TenantB
        when(tenantRepository.findById(1L)).thenReturn(Optional.of(tenant1));
        when(tenantRepository.findByTenantName("TenantB")).thenReturn(Optional.of(tenant2)); // TenantB already exists

        assertThrows(ResourceConflictException.class, () -> tenantService.updateTenant(1L, request));
        verify(tenantRepository, times(1)).findById(1L);
        verify(tenantRepository, times(1)).findByTenantName("TenantB");
        verify(tenantRepository, never()).save(any(Tenant.class));
    }

    @Test
    @DisplayName("Should throw BadRequestException if invalid themeId during update")
    void updateTenant_shouldThrowBadRequestExceptionIfInvalidThemeId() {
        TenantUpdateRequest request = new TenantUpdateRequest("TenantA", 999L);
        when(tenantRepository.findById(1L)).thenReturn(Optional.of(tenant1));
        when(themeRepository.existsById(999L)).thenReturn(false);

        assertThrows(BadRequestException.class, () -> tenantService.updateTenant(1L, request));
        verify(tenantRepository, times(1)).findById(1L);
        verify(themeRepository, times(1)).existsById(999L);
        verify(tenantRepository, never()).save(any(Tenant.class));
    }

    @Test
    @DisplayName("Should delete a tenant successfully")
    void deleteTenant_shouldDeleteTenant() {
        when(tenantRepository.existsById(1L)).thenReturn(true);
        doNothing().when(tenantRepository).deleteById(1L); // Mock void method

        assertDoesNotThrow(() -> tenantService.deleteTenant(1L));
        verify(tenantRepository, times(1)).existsById(1L);
        verify(tenantRepository, times(1)).deleteById(1L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if tenant not found during delete")
    void deleteTenant_shouldThrowNotFoundException() {
        when(tenantRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> tenantService.deleteTenant(99L));
        verify(tenantRepository, times(1)).existsById(99L);
        verify(tenantRepository, never()).deleteById(anyLong());
    }

    @Test
    @DisplayName("Should return default theme for tenant")
    void getTenantDefaultTheme_shouldReturnTheme() {
        tenant1.setThemeId(theme1.getThemeId());
        when(tenantRepository.findById(1L)).thenReturn(Optional.of(tenant1));
        when(themeRepository.findById(theme1.getThemeId())).thenReturn(Optional.of(theme1));

        Theme foundTheme = tenantService.getTenantDefaultTheme(1L);

        assertNotNull(foundTheme);
        assertEquals("dark", foundTheme.getThemeName());
        verify(tenantRepository, times(1)).findById(1L);
        verify(themeRepository, times(1)).findById(theme1.getThemeId());
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if no default theme configured for tenant")
    void getTenantDefaultTheme_shouldThrowNotFoundIfNoThemeConfigured() {
        tenant1.setThemeId(null); // No theme configured
        when(tenantRepository.findById(1L)).thenReturn(Optional.of(tenant1));

        assertThrows(ResourceNotFoundException.class, () -> tenantService.getTenantDefaultTheme(1L));
        verify(tenantRepository, times(1)).findById(1L);
        verify(themeRepository, never()).findById(anyLong()); // Should not try to find theme
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if configured theme does not exist")
    void getTenantDefaultTheme_shouldThrowNotFoundIfThemeDoesNotExist() {
        tenant1.setThemeId(999L); // Theme ID that doesn't exist
        when(tenantRepository.findById(1L)).thenReturn(Optional.of(tenant1));
        when(themeRepository.findById(999L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> tenantService.getTenantDefaultTheme(1L));
        verify(tenantRepository, times(1)).findById(1L);
        verify(themeRepository, times(1)).findById(999L);
    }

    @Test
    @DisplayName("Should set default theme for tenant successfully")
    void setTenantDefaultTheme_shouldSetTheme() {
        when(tenantRepository.findById(1L)).thenReturn(Optional.of(tenant1));
        when(themeRepository.existsById(theme1.getThemeId())).thenReturn(true);
        when(tenantRepository.save(any(Tenant.class))).thenReturn(tenant1); // Mock save behavior

        Tenant updatedTenant = tenantService.setTenantDefaultTheme(1L, theme1.getThemeId());

        assertNotNull(updatedTenant);
        assertEquals(theme1.getThemeId(), updatedTenant.getThemeId());
        verify(tenantRepository, times(1)).findById(1L);
        verify(themeRepository, times(1)).existsById(theme1.getThemeId());
        verify(tenantRepository, times(1)).save(tenant1);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if tenant not found when setting theme")
    void setTenantDefaultTheme_shouldThrowNotFoundIfTenantNotFound() {
        when(tenantRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> tenantService.setTenantDefaultTheme(99L, theme1.getThemeId()));
        verify(tenantRepository, times(1)).findById(99L);
        verify(themeRepository, never()).existsById(anyLong());
        verify(tenantRepository, never()).save(any(Tenant.class));
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if theme not found when setting theme")
    void setTenantDefaultTheme_shouldThrowNotFoundIfThemeNotFound() {
        when(tenantRepository.findById(1L)).thenReturn(Optional.of(tenant1));
        when(themeRepository.existsById(999L)).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> tenantService.setTenantDefaultTheme(1L, 999L));
        verify(tenantRepository, times(1)).findById(1L);
        verify(themeRepository, times(1)).existsById(999L);
        verify(tenantRepository, never()).save(any(Tenant.class));
    }
}
