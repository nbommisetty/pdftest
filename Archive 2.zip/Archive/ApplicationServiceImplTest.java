package com.yourcompany.config.service;

import com.yourcompany.config.exception.BadRequestException;
import com.yourcompany.config.exception.ResourceConflictException;
import com.yourcompany.config.exception.ResourceNotFoundException;
import com.yourcompany.config.model.Application;
import com.yourcompany.config.model.Feature;
import com.yourcompany.config.model.FeatureApplication;
import com.yourcompany.config.repository.ApplicationRepository;
import com.yourcompany.config.repository.FeatureApplicationRepository;
import com.yourcompany.config.repository.FeatureRepository; // Correctly imported for mocking
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("Application Service Unit Tests")
public class ApplicationServiceImplTest {

    @Mock
    private ApplicationRepository applicationRepository;
    @Mock
    private FeatureApplicationRepository featureApplicationRepository;
    @Mock
    private FeatureRepository featureRepository; // Injected into ApplicationServiceImpl

    @InjectMocks
    private ApplicationServiceImpl applicationService;

    private Application app1;
    private Application app2;
    private Feature feature1;
    private Feature feature2;
    private FeatureApplication featureApp1;

    @BeforeEach
    void setUp() {
        // Initialize sample data before each test
        LocalDateTime now = LocalDateTime.now();
        String user = "test_user";

        app1 = new Application();
        app1.setApplicationId(101L);
        app1.setApplicationName("OnlineBanking");
        app1.setApplicationDescription("Web application for online banking.");
        app1.setCreatedAt(now); // Set inherited fields
        app1.setUpdatedAt(now); // Set inherited fields
        app1.setCreatedBy(user); // Set inherited fields
        app1.setUpdatedBy(user); // Set inherited fields

        app2 = new Application();
        app2.setApplicationId(102L);
        app2.setApplicationName("MobileBanking");
        app2.setApplicationDescription("Mobile application for banking.");
        app2.setCreatedAt(now); // Set inherited fields
        app2.setUpdatedAt(now); // Set inherited fields
        app2.setCreatedBy(user); // Set inherited fields
        app2.setUpdatedBy(user); // Set inherited fields

        feature1 = new Feature();
        feature1.setFeatureId(201L);
        feature1.setFeatureName("WireTransfer");
        feature1.setFeatureDescription("Allows wire transfers.");
        feature1.setCreatedAt(now); // Set inherited fields
        feature1.setUpdatedAt(now); // Set inherited fields
        feature1.setCreatedBy(user); // Set inherited fields
        feature1.setUpdatedBy(user); // Set inherited fields

        feature2 = new Feature();
        feature2.setFeatureId(202L);
        feature2.setFeatureName("DirectDeposit");
        feature2.setFeatureDescription("Manages direct deposits.");
        feature2.setCreatedAt(now); // Set inherited fields
        feature2.setUpdatedAt(now); // Set inherited fields
        feature2.setCreatedBy(user); // Set inherited fields
        feature2.setUpdatedBy(user); // Set inherited fields

        featureApp1 = new FeatureApplication();
        featureApp1.setFeatureApplicationId(1L);
        featureApp1.setApplicationId(app1.getApplicationId());
        featureApp1.setFeatureId(feature1.getFeatureId());
        featureApp1.setCreatedAt(now); // Set inherited fields
        featureApp1.setUpdatedAt(now); // Set inherited fields
        featureApp1.setCreatedBy(user); // Set inherited fields
        featureApp1.setUpdatedBy(user); // Set inherited fields
    }

    @Test
    @DisplayName("Should return all applications")
    void getAllApplications_shouldReturnAllApplications() {
        when(applicationRepository.findAll()).thenReturn(Arrays.asList(app1, app2));

        List<Application> applications = applicationService.getAllApplications();

        assertNotNull(applications);
        assertEquals(2, applications.size());
        assertEquals("OnlineBanking", applications.get(0).getApplicationName());
        verify(applicationRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Should return application by ID")
    void getApplicationById_shouldReturnApplication() {
        when(applicationRepository.findById(101L)).thenReturn(Optional.of(app1));

        Application foundApp = applicationService.getApplicationById(101L);

        assertNotNull(foundApp);
        assertEquals("OnlineBanking", foundApp.getApplicationName());
        verify(applicationRepository, times(1)).findById(101L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if application not found by ID")
    void getApplicationById_shouldThrowNotFoundException() {
        when(applicationRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> applicationService.getApplicationById(999L));
        verify(applicationRepository, times(1)).findById(999L);
    }

    @Test
    @DisplayName("Should create a new application successfully")
    void createApplication_shouldCreateApplication() {
        ApplicationCreateRequest request = new ApplicationCreateRequest("NewApp", "New App Description");
        when(applicationRepository.findByApplicationName(request.getApplicationName())).thenReturn(Optional.empty());
        when(applicationRepository.save(any(Application.class))).thenReturn(app1); // Mock save behavior

        Application createdApp = applicationService.createApplication(request);

        assertNotNull(createdApp);
        assertEquals("OnlineBanking", createdApp.getApplicationName()); // Assuming app1 is returned after save
        verify(applicationRepository, times(1)).findByApplicationName("NewApp");
        verify(applicationRepository, times(1)).save(any(Application.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if application name already exists during creation")
    void createApplication_shouldThrowConflictExceptionIfNameExists() {
        ApplicationCreateRequest request = new ApplicationCreateRequest("OnlineBanking", "Existing App Description");
        when(applicationRepository.findByApplicationName(request.getApplicationName())).thenReturn(Optional.of(app1));

        assertThrows(ResourceConflictException.class, () -> applicationService.createApplication(request));
        verify(applicationRepository, times(1)).findByApplicationName("OnlineBanking");
        verify(applicationRepository, never()).save(any(Application.class));
    }

    @Test
    @DisplayName("Should update an existing application successfully (full replacement)")
    void updateApplication_shouldUpdateApplication() {
        ApplicationUpdateRequest request = new ApplicationUpdateRequest("UpdatedOnlineBanking", "Updated Description");
        when(applicationRepository.findById(101L)).thenReturn(Optional.of(app1));
        when(applicationRepository.findByApplicationName(request.getApplicationName())).thenReturn(Optional.empty());
        when(applicationRepository.save(any(Application.class))).thenReturn(app1);

        Application updatedApp = applicationService.updateApplication(101L, request);

        assertNotNull(updatedApp);
        assertEquals("UpdatedOnlineBanking", updatedApp.getApplicationName());
        assertEquals("Updated Description", updatedApp.getApplicationDescription());
        verify(applicationRepository, times(1)).findById(101L);
        verify(applicationRepository, times(1)).findByApplicationName("UpdatedOnlineBanking");
        verify(applicationRepository, times(1)).save(app1);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if application not found during update")
    void updateApplication_shouldThrowNotFoundException() {
        ApplicationUpdateRequest request = new ApplicationUpdateRequest("UpdatedApp", null);
        when(applicationRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> applicationService.updateApplication(999L, request));
        verify(applicationRepository, times(1)).findById(999L);
        verify(applicationRepository, never()).save(any(Application.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if updated application name already exists")
    void updateApplication_shouldThrowConflictExceptionIfNameExists() {
        ApplicationUpdateRequest request = new ApplicationUpdateRequest("MobileBanking", null);
        when(applicationRepository.findById(101L)).thenReturn(Optional.of(app1));
        when(applicationRepository.findByApplicationName("MobileBanking")).thenReturn(Optional.of(app2));

        assertThrows(ResourceConflictException.class, () -> applicationService.updateApplication(101L, request));
        verify(applicationRepository, times(1)).findById(101L);
        verify(applicationRepository, times(1)).findByApplicationName("MobileBanking");
        verify(applicationRepository, never()).save(any(Application.class));
    }

    @Test
    @DisplayName("Should partially update an existing application successfully")
    void patchApplication_shouldPatchApplication() {
        ApplicationPatchRequest request = new ApplicationPatchRequest();
        request.setApplicationDescription("Patched Description");
        when(applicationRepository.findById(101L)).thenReturn(Optional.of(app1));
        when(applicationRepository.save(any(Application.class))).thenReturn(app1);

        Application patchedApp = applicationService.patchApplication(101L, request);

        assertNotNull(patchedApp);
        assertEquals("OnlineBanking", patchedApp.getApplicationName()); // Name should not change
        assertEquals("Patched Description", patchedApp.getApplicationDescription());
        verify(applicationRepository, times(1)).findById(101L);
        verify(applicationRepository, times(1)).save(app1);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if application not found during patch")
    void patchApplication_shouldThrowNotFoundException() {
        ApplicationPatchRequest request = new ApplicationPatchRequest();
        request.setApplicationName("NonExistentApp");
        when(applicationRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> applicationService.patchApplication(999L, request));
        verify(applicationRepository, times(1)).findById(999L);
        verify(applicationRepository, never()).save(any(Application.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if patched application name already exists")
    void patchApplication_shouldThrowConflictExceptionIfNameExists() {
        ApplicationPatchRequest request = new ApplicationPatchRequest();
        request.setApplicationName("MobileBanking");
        when(applicationRepository.findById(101L)).thenReturn(Optional.of(app1));
        when(applicationRepository.findByApplicationName("MobileBanking")).thenReturn(Optional.of(app2));

        assertThrows(ResourceConflictException.class, () -> applicationService.patchApplication(101L, request));
        verify(applicationRepository, times(1)).findById(101L);
        verify(applicationRepository, times(1)).findByApplicationName("MobileBanking");
        verify(applicationRepository, never()).save(any(Application.class));
    }

    @Test
    @DisplayName("Should delete an application successfully")
    void deleteApplication_shouldDeleteApplication() {
        when(applicationRepository.existsById(101L)).thenReturn(true);
        doNothing().when(applicationRepository).deleteById(101L);

        assertDoesNotThrow(() -> applicationService.deleteApplication(101L));
        verify(applicationRepository, times(1)).existsById(101L);
        verify(applicationRepository, times(1)).deleteById(101L);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if application not found during delete")
    void deleteApplication_shouldThrowNotFoundException() {
        when(applicationRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> applicationService.deleteApplication(999L));
        verify(applicationRepository, times(1)).existsById(999L);
        verify(applicationRepository, never()).deleteById(anyLong());
    }

    @Test
    @DisplayName("Should return features associated with an application")
    void getFeaturesByApplication_shouldReturnFeatures() {
        FeatureApplication fa = new FeatureApplication();
        fa.setApplicationId(app1.getApplicationId());
        fa.setFeatureId(feature1.getFeatureId());
        // Set audit fields for featureApp1 as well, for consistency
        fa.setCreatedAt(LocalDateTime.now());
        fa.setUpdatedAt(LocalDateTime.now());
        fa.setCreatedBy("test_user");
        fa.setUpdatedBy("test_user");


        when(featureApplicationRepository.findByApplicationId(app1.getApplicationId())).thenReturn(Collections.singletonList(fa));
        when(featureRepository.findById(feature1.getFeatureId())).thenReturn(Optional.of(feature1));

        List<Feature> features = applicationService.getFeaturesByApplication(app1.getApplicationId());

        assertNotNull(features);
        assertEquals(1, features.size());
        assertEquals("WireTransfer", features.get(0).getFeatureName()); // This is line 264
        verify(featureApplicationRepository, times(1)).findByApplicationId(app1.getApplicationId());
        verify(featureRepository, times(1)).findById(feature1.getFeatureId());
    }

    @Test
    @DisplayName("Should return empty list if no features associated with application")
    void getFeaturesByApplication_shouldReturnEmptyList() {
        when(featureApplicationRepository.findByApplicationId(app1.getApplicationId())).thenReturn(Collections.emptyList());

        List<Feature> features = applicationService.getFeaturesByApplication(app1.getApplicationId());

        assertNotNull(features);
        assertTrue(features.isEmpty());
        verify(featureApplicationRepository, times(1)).findByApplicationId(app1.getApplicationId());
        verify(featureRepository, never()).findById(anyLong());
    }

    @Test
    @DisplayName("Should add feature to application successfully")
    void addFeatureToApplication_shouldAddAssociation() {
        when(applicationRepository.existsById(app1.getApplicationId())).thenReturn(true);
        when(featureRepository.existsById(feature1.getFeatureId())).thenReturn(true);
        when(featureApplicationRepository.findByFeatureIdAndApplicationId(feature1.getFeatureId(), app1.getApplicationId())).thenReturn(Optional.empty());
        when(featureApplicationRepository.save(any(FeatureApplication.class))).thenReturn(featureApp1);

        FeatureApplication result = applicationService.addFeatureToApplication(app1.getApplicationId(), feature1.getFeatureId());

        assertNotNull(result);
        assertEquals(app1.getApplicationId(), result.getApplicationId());
        assertEquals(feature1.getFeatureId(), result.getFeatureId());
        verify(applicationRepository, times(1)).existsById(app1.getApplicationId());
        verify(featureRepository, times(1)).existsById(feature1.getFeatureId());
        verify(featureApplicationRepository, times(1)).findByFeatureIdAndApplicationId(feature1.getFeatureId(), app1.getApplicationId());
        verify(featureApplicationRepository, times(1)).save(any(FeatureApplication.class));
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if application not found when adding feature")
    void addFeatureToApplication_shouldThrowAppNotFound() {
        when(applicationRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> applicationService.addFeatureToApplication(999L, feature1.getFeatureId()));
        verify(applicationRepository, times(1)).existsById(999L);
        verify(featureRepository, never()).existsById(anyLong());
        verify(featureApplicationRepository, never()).save(any(FeatureApplication.class));
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if feature not found when adding feature")
    void addFeatureToApplication_shouldThrowFeatureNotFound() {
        when(applicationRepository.existsById(app1.getApplicationId())).thenReturn(true);
        when(featureRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> applicationService.addFeatureToApplication(app1.getApplicationId(), 999L));
        verify(applicationRepository, times(1)).existsById(app1.getApplicationId());
        verify(featureRepository, times(1)).existsById(999L);
        verify(featureApplicationRepository, never()).save(any(FeatureApplication.class));
    }

    @Test
    @DisplayName("Should throw ResourceConflictException if association already exists when adding feature")
    void addFeatureToApplication_shouldThrowConflictIfAssociationExists() {
        when(applicationRepository.existsById(app1.getApplicationId())).thenReturn(true);
        when(featureRepository.existsById(feature1.getFeatureId())).thenReturn(true);
        when(featureApplicationRepository.findByFeatureIdAndApplicationId(feature1.getFeatureId(), app1.getApplicationId())).thenReturn(Optional.of(featureApp1));

        assertThrows(ResourceConflictException.class, () -> applicationService.addFeatureToApplication(app1.getApplicationId(), feature1.getFeatureId()));
        verify(applicationRepository, times(1)).existsById(app1.getApplicationId());
        verify(featureRepository, times(1)).existsById(feature1.getFeatureId());
        verify(featureApplicationRepository, times(1)).findByFeatureIdAndApplicationId(feature1.getFeatureId(), app1.getApplicationId());
        verify(featureApplicationRepository, never()).save(any(FeatureApplication.class));
    }

    @Test
    @DisplayName("Should remove feature from application successfully")
    void removeFeatureFromApplication_shouldRemoveAssociation() {
        when(featureApplicationRepository.findByFeatureIdAndApplicationId(feature1.getFeatureId(), app1.getApplicationId())).thenReturn(Optional.of(featureApp1));
        doNothing().when(featureApplicationRepository).delete(featureApp1);

        assertDoesNotThrow(() -> applicationService.removeFeatureFromApplication(app1.getApplicationId(), feature1.getFeatureId()));
        verify(featureApplicationRepository, times(1)).findByFeatureIdAndApplicationId(feature1.getFeatureId(), app1.getApplicationId());
        verify(featureApplicationRepository, times(1)).delete(featureApp1);
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException if association not found when removing feature")
    void removeFeatureFromApplication_shouldThrowNotFound() {
        when(featureApplicationRepository.findByFeatureIdAndApplicationId(anyLong(), anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> applicationService.removeFeatureFromApplication(999L, 888L));
        verify(featureApplicationRepository, times(1)).findByFeatureIdAndApplicationId(888L, 999L);
        verify(featureApplicationRepository, never()).delete(any(FeatureApplication.class));
    }
}
