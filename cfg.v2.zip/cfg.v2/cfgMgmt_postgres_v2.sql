CREATE TABLE "Tenant" (
  "TenantId" "BIGINT" PRIMARY KEY,
  "TenantName" "VARCHAR(100)" UNIQUE NOT NULL,
  "ThemeId" "BIGINT",
  "CreatedAt" "DATETIME" NOT NULL,
  "UpdatedAt" "DATETIME" NOT NULL,
  "CreatedBy" "VARCHAR(100)",
  "UpdatedBy" "VARCHAR(100)"
);

CREATE TABLE "Application" (
  "ApplicationId" "BIGINT" PRIMARY KEY,
  "ApplicationName" "VARCHAR(100)" UNIQUE NOT NULL,
  "ApplicationDescription" "TEXT",
  "CreatedAt" "DATETIME" NOT NULL,
  "UpdatedAt" "DATETIME" NOT NULL,
  "CreatedBy" "VARCHAR(100)",
  "UpdatedBy" "VARCHAR(100)"
);

CREATE TABLE "Feature" (
  "FeatureId" "BIGINT" PRIMARY KEY,
  "FeatureName" "VARCHAR(100)" UNIQUE NOT NULL,
  "FeatureDescription" "TEXT",
  "CreatedAt" "DATETIME" NOT NULL,
  "UpdatedAt" "DATETIME" NOT NULL,
  "CreatedBy" "VARCHAR(100)",
  "UpdatedBy" "VARCHAR(100)"
);

CREATE TABLE "UserRole" (
  "RoleId" "BIGINT" PRIMARY KEY,
  "RoleName" "VARCHAR(50)" UNIQUE NOT NULL,
  "RoleDescription" "TEXT",
  "CreatedAt" "DATETIME" NOT NULL,
  "UpdatedAt" "DATETIME" NOT NULL,
  "CreatedBy" "VARCHAR(100)",
  "UpdatedBy" "VARCHAR(100)"
);

CREATE TABLE "Page" (
  "PageId" "BIGINT" PRIMARY KEY,
  "FeatureId" "BIGINT" NOT NULL,
  "PageName" "VARCHAR(100)" NOT NULL,
  "PageOrder" "INT" NOT NULL DEFAULT 0,
  "CreatedAt" "DATETIME" NOT NULL,
  "UpdatedAt" "DATETIME" NOT NULL,
  "CreatedBy" "VARCHAR(100)",
  "UpdatedBy" "VARCHAR(100)"
);

CREATE TABLE "Form" (
  "FormId" "BIGINT" PRIMARY KEY,
  "PageId" "BIGINT" NOT NULL,
  "FormName" "VARCHAR(100)" NOT NULL,
  "FormOrder" "INT" NOT NULL DEFAULT 0,
  "CreatedAt" "DATETIME" NOT NULL,
  "UpdatedAt" "DATETIME" NOT NULL,
  "CreatedBy" "VARCHAR(100)",
  "UpdatedBy" "VARCHAR(100)"
);

CREATE TABLE "Field" (
  "FieldId" "BIGINT" PRIMARY KEY,
  "FormId" "BIGINT" NOT NULL,
  "FieldName" "VARCHAR(100)" NOT NULL,
  "FieldType" "VARCHAR(50)" NOT NULL,
  "InputType" "VARCHAR(50)" NOT NULL,
  "DefaultLabel" "VARCHAR(255)" NOT NULL,
  "DefaultValidationRules" "JSONB",
  "CreatedAt" "DATETIME" NOT NULL,
  "UpdatedAt" "DATETIME" NOT NULL,
  "CreatedBy" "VARCHAR(100)",
  "UpdatedBy" "VARCHAR(100)"
);

CREATE TABLE "Theme" (
  "ThemeId" "BIGINT" PRIMARY KEY,
  "ThemeName" "VARCHAR(100)" UNIQUE NOT NULL,
  "ThemeDescription" "TEXT",
  "ThemeData" "JSONB",
  "CreatedAt" "DATETIME" NOT NULL,
  "UpdatedAt" "DATETIME" NOT NULL,
  "CreatedBy" "VARCHAR(100)",
  "UpdatedBy" "VARCHAR(100)"
);

CREATE TABLE "FeatureApplication" (
  "FeatureApplicationId" "BIGINT" PRIMARY KEY,
  "FeatureId" "BIGINT" NOT NULL,
  "ApplicationId" "BIGINT" NOT NULL,
  "CreatedAt" "DATETIME" NOT NULL,
  "UpdatedAt" "DATETIME" NOT NULL,
  "CreatedBy" "VARCHAR(100)",
  "UpdatedBy" "VARCHAR(100)"
);

CREATE TABLE "TenantApplicationFeatureConfig" (
  "ConfigId" "BIGINT" PRIMARY KEY,
  "TenantId" "BIGINT" NOT NULL,
  "ApplicationId" "BIGINT" NOT NULL,
  "RoleId" "BIGINT",
  "FeatureId" "BIGINT" NOT NULL,
  "IsEnabled" "BOOLEAN" NOT NULL DEFAULT true,
  "ThemeId" "BIGINT",
  "CreatedAt" "DATETIME" NOT NULL,
  "UpdatedAt" "DATETIME" NOT NULL,
  "CreatedBy" "VARCHAR(100)",
  "UpdatedBy" "VARCHAR(100)"
);

CREATE TABLE "TenantApplicationFieldConfig" (
  "ConfigId" "BIGINT" PRIMARY KEY,
  "TenantId" "BIGINT" NOT NULL,
  "ApplicationId" "BIGINT" NOT NULL,
  "FieldId" "BIGINT" NOT NULL,
  "IsEnabled" "BOOLEAN" NOT NULL DEFAULT true,
  "CustomLabel" "VARCHAR(255)",
  "CustomValidationRules" "JSONB",
  "CreatedAt" "DATETIME" NOT NULL,
  "UpdatedAt" "DATETIME" NOT NULL,
  "CreatedBy" "VARCHAR(100)",
  "UpdatedBy" "VARCHAR(100)"
);

CREATE TABLE "TenantApplicationConfig" (
  "ConfigId" "BIGINT" PRIMARY KEY,
  "TenantId" "BIGINT" NOT NULL,
  "ApplicationId" "BIGINT" NOT NULL,
  "ThemeId" "BIGINT" NOT NULL,
  "CreatedAt" "DATETIME" NOT NULL,
  "UpdatedAt" "DATETIME" NOT NULL,
  "CreatedBy" "VARCHAR(100)",
  "UpdatedBy" "VARCHAR(100)"
);

CREATE UNIQUE INDEX ON "Page" ("FeatureId", "PageName");

CREATE UNIQUE INDEX ON "Form" ("PageId", "FormName");

CREATE UNIQUE INDEX ON "Field" ("FormId", "FieldName");

CREATE UNIQUE INDEX ON "FeatureApplication" ("FeatureId", "ApplicationId");

CREATE UNIQUE INDEX ON "TenantApplicationFeatureConfig" ("TenantId", "ApplicationId", "RoleId", "FeatureId");

CREATE UNIQUE INDEX ON "TenantApplicationFieldConfig" ("TenantId", "ApplicationId", "FieldId");

CREATE UNIQUE INDEX ON "TenantApplicationConfig" ("TenantId", "ApplicationId");

COMMENT ON COLUMN "Tenant"."TenantId" IS 'Primary key for tenants. Auto-incrementing mechanism handled by specific DB DDL (e.g., IDENTITY in SQL Server).';

COMMENT ON COLUMN "Tenant"."TenantName" IS 'Unique name for each tenant.';

COMMENT ON COLUMN "Tenant"."ThemeId" IS 'Foreign key to Theme. The default UI theme for this tenant.';

COMMENT ON COLUMN "Tenant"."CreatedBy" IS 'Username of the user who created this tenant.';

COMMENT ON COLUMN "Tenant"."UpdatedBy" IS 'Username of the user who last updated this tenant.';

COMMENT ON COLUMN "Application"."ApplicationId" IS 'Primary key for applications. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "Application"."ApplicationName" IS 'e.g., OnlineBanking(Web), MobileBanking, OnlineAccountOpening.';

COMMENT ON COLUMN "Application"."CreatedBy" IS 'Username of the user who created this application.';

COMMENT ON COLUMN "Application"."UpdatedBy" IS 'Username of the user who last updated this application.';

COMMENT ON COLUMN "Feature"."FeatureId" IS 'Primary key for features. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "Feature"."FeatureName" IS 'e.g., Wire Transfers, Direct Deposits.';

COMMENT ON COLUMN "Feature"."CreatedBy" IS 'Username of the user who created this feature.';

COMMENT ON COLUMN "Feature"."UpdatedBy" IS 'Username of the user who last updated this feature.';

COMMENT ON COLUMN "UserRole"."RoleId" IS 'Primary key for user roles. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "UserRole"."RoleName" IS 'e.g., business-admin, business-subuser, readonly.';

COMMENT ON COLUMN "UserRole"."CreatedBy" IS 'Username of the user who created this role.';

COMMENT ON COLUMN "UserRole"."UpdatedBy" IS 'Username of the user who last updated this role.';

COMMENT ON COLUMN "Page"."PageId" IS 'Primary key for pages. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "Page"."PageName" IS 'e.g., Initiate Transfer, Review Transfer.';

COMMENT ON COLUMN "Page"."PageOrder" IS 'Display order of pages within a feature.';

COMMENT ON COLUMN "Page"."CreatedBy" IS 'Username of the user who created this page.';

COMMENT ON COLUMN "Page"."UpdatedBy" IS 'Username of the user who last updated this page.';

COMMENT ON COLUMN "Form"."FormId" IS 'Primary key for forms. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "Form"."FormName" IS 'e.g., Recipient Details, Amount Input.';

COMMENT ON COLUMN "Form"."FormOrder" IS 'Display order of forms within a page.';

COMMENT ON COLUMN "Form"."CreatedBy" IS 'Username of the user who created this form.';

COMMENT ON COLUMN "Form"."UpdatedBy" IS 'Username of the user who last updated this form.';

COMMENT ON COLUMN "Field"."FieldId" IS 'Primary key for fields. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "Field"."FormId" IS 'Foreign key to Form. Every field must belong to a form.';

COMMENT ON COLUMN "Field"."FieldName" IS 'System name for the field (e.g., recipient_account_number).';

COMMENT ON COLUMN "Field"."FieldType" IS 'e.g., TEXT_INPUT, NUMBER_INPUT, DATE_PICKER, DROPDOWN.';

COMMENT ON COLUMN "Field"."InputType" IS 'Defines the HTML input type or logical input control for the field.';

COMMENT ON COLUMN "Field"."DefaultLabel" IS 'Default display label for the field.';

COMMENT ON COLUMN "Field"."DefaultValidationRules" IS 'Default validation rules in JSON format.';

COMMENT ON COLUMN "Field"."CreatedBy" IS 'Username of the user who created this field.';

COMMENT ON COLUMN "Field"."UpdatedBy" IS 'Username of the user who last updated this field.';

COMMENT ON COLUMN "Theme"."ThemeId" IS 'Primary key for themes. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "Theme"."ThemeName" IS 'e.g., dark, classic, modern.';

COMMENT ON COLUMN "Theme"."ThemeData" IS 'JSON object containing theme variables (e.g., colors, fonts, CSS properties).';

COMMENT ON COLUMN "Theme"."CreatedBy" IS 'Username of the user who created this theme.';

COMMENT ON COLUMN "Theme"."UpdatedBy" IS 'Username of the user who last updated this theme.';

COMMENT ON COLUMN "FeatureApplication"."FeatureApplicationId" IS 'Primary key. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "FeatureApplication"."CreatedBy" IS 'Username of the user who created this association.';

COMMENT ON COLUMN "FeatureApplication"."UpdatedBy" IS 'Username of the user who last updated this association.';

COMMENT ON COLUMN "TenantApplicationFeatureConfig"."ConfigId" IS 'Primary key. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "TenantApplicationFeatureConfig"."ApplicationId" IS 'Foreign key to Application. Allows tenant-specific feature configurations to vary by Application.';

COMMENT ON COLUMN "TenantApplicationFeatureConfig"."RoleId" IS 'Foreign key to UserRole. Nullable to support applications without explicit user roles.';

COMMENT ON COLUMN "TenantApplicationFeatureConfig"."IsEnabled" IS 'True if feature is enabled for the tenant within this specific application and for this role.';

COMMENT ON COLUMN "TenantApplicationFeatureConfig"."ThemeId" IS 'Foreign key to Theme. The theme for this tenant in this specific application for this feature. Nullable if no specific theme override.';

COMMENT ON COLUMN "TenantApplicationFeatureConfig"."CreatedBy" IS 'Username of the user who created this config.';

COMMENT ON COLUMN "TenantApplicationFeatureConfig"."UpdatedBy" IS 'Username of the user who last updated this config.';

COMMENT ON COLUMN "TenantApplicationFieldConfig"."ConfigId" IS 'Primary key. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "TenantApplicationFieldConfig"."ApplicationId" IS 'Foreign key to Application. Allows tenant-specific field configurations to vary by Application.';

COMMENT ON COLUMN "TenantApplicationFieldConfig"."IsEnabled" IS 'True if field is enabled for the tenant within its feature/application context.';

COMMENT ON COLUMN "TenantApplicationFieldConfig"."CustomLabel" IS 'Tenant-specific override for field label.';

COMMENT ON COLUMN "TenantApplicationFieldConfig"."CustomValidationRules" IS 'Tenant-specific override for field validation rules.';

COMMENT ON COLUMN "TenantApplicationFieldConfig"."CreatedBy" IS 'Username of the user who created this config.';

COMMENT ON COLUMN "TenantApplicationFieldConfig"."UpdatedBy" IS 'Username of the user who last updated this config.';

COMMENT ON COLUMN "TenantApplicationConfig"."ConfigId" IS 'Primary key. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "TenantApplicationConfig"."ThemeId" IS 'Foreign key to Theme. The theme for this tenant in this specific application.';

COMMENT ON COLUMN "TenantApplicationConfig"."CreatedBy" IS 'Username of the user who created this config.';

COMMENT ON COLUMN "TenantApplicationConfig"."UpdatedBy" IS 'Username of the user who last updated this config.';

ALTER TABLE "FeatureApplication" ADD FOREIGN KEY ("ApplicationId") REFERENCES "Application" ("ApplicationId");

ALTER TABLE "FeatureApplication" ADD FOREIGN KEY ("FeatureId") REFERENCES "Feature" ("FeatureId");

ALTER TABLE "Page" ADD FOREIGN KEY ("FeatureId") REFERENCES "Feature" ("FeatureId");

ALTER TABLE "Form" ADD FOREIGN KEY ("PageId") REFERENCES "Page" ("PageId");

ALTER TABLE "Field" ADD FOREIGN KEY ("FormId") REFERENCES "Form" ("FormId");

ALTER TABLE "TenantApplicationFeatureConfig" ADD FOREIGN KEY ("TenantId") REFERENCES "Tenant" ("TenantId");

ALTER TABLE "TenantApplicationFeatureConfig" ADD FOREIGN KEY ("ApplicationId") REFERENCES "Application" ("ApplicationId");

ALTER TABLE "TenantApplicationFeatureConfig" ADD FOREIGN KEY ("RoleId") REFERENCES "UserRole" ("RoleId");

ALTER TABLE "TenantApplicationFeatureConfig" ADD FOREIGN KEY ("FeatureId") REFERENCES "Feature" ("FeatureId");

ALTER TABLE "TenantApplicationFeatureConfig" ADD FOREIGN KEY ("ThemeId") REFERENCES "Theme" ("ThemeId");

ALTER TABLE "TenantApplicationFieldConfig" ADD FOREIGN KEY ("TenantId") REFERENCES "Tenant" ("TenantId");

ALTER TABLE "TenantApplicationFieldConfig" ADD FOREIGN KEY ("ApplicationId") REFERENCES "Application" ("ApplicationId");

ALTER TABLE "TenantApplicationFieldConfig" ADD FOREIGN KEY ("FieldId") REFERENCES "Field" ("FieldId");

ALTER TABLE "Tenant" ADD FOREIGN KEY ("ThemeId") REFERENCES "Theme" ("ThemeId");

ALTER TABLE "TenantApplicationConfig" ADD FOREIGN KEY ("TenantId") REFERENCES "Tenant" ("TenantId");

ALTER TABLE "TenantApplicationConfig" ADD FOREIGN KEY ("ApplicationId") REFERENCES "Application" ("ApplicationId");

ALTER TABLE "TenantApplicationConfig" ADD FOREIGN KEY ("ThemeId") REFERENCES "Theme" ("ThemeId");
