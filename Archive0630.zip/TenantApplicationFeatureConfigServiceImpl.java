package com.yourcompany.config.service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yourcompany.config.model.Application;
import com.yourcompany.config.model.Feature;
import com.yourcompany.config.model.Field;
import com.yourcompany.config.model.Form;
import com.yourcompany.config.model.Page;
import com.yourcompany.config.model.Tenant;
import com.yourcompany.config.model.TenantApplicationFeatureConfig;
import com.yourcompany.config.repository.ApplicationRepository;
import com.yourcompany.config.repository.FeatureApplicationRepository;
import com.yourcompany.config.repository.FeatureRepository;
import com.yourcompany.config.repository.FieldRepository;
import com.yourcompany.config.repository.FormRepository;
import com.yourcompany.config.repository.PageRepository;
import com.yourcompany.config.repository.TenantApplicationFeatureConfigRepository;
import com.yourcompany.config.repository.TenantRepository;
import com.yourcompany.config.repository.ThemeRepository;
import com.yourcompany.config.repository.UserRoleRepository;
import com.yourcompany.config.exception.*;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TenantApplicationFeatureConfigServiceImpl implements TenantApplicationFeatureConfigService {
    private final TenantApplicationFeatureConfigRepository configRepository;
    private final TenantRepository tenantRepository;
    private final ApplicationRepository applicationRepository;
    private final UserRoleRepository userRoleRepository;
    private final FeatureRepository featureRepository;
    private final ThemeRepository themeRepository;
    private final FeatureApplicationRepository featureApplicationRepository;
    private final PageRepository pageRepository; // NEW: Injected for getFeatureWithNestedConfig
    private final FormRepository formRepository; // NEW: Injected for getFeatureWithNestedConfig
    private final FieldRepository fieldRepository; // NEW: Injected for getFeatureWithNestedConfig
    private final TenantApplicationFieldConfigService tenantApplicationFieldConfigService;

    @Override
    public TenantApplicationFeatureConfig getConfig(Long tenantId, Long applicationId, Long roleId, Long featureId) {
        if (roleId != null) {
            return configRepository.findByTenantIdAndApplicationIdAndRoleIdAndFeatureId(tenantId, applicationId, roleId, featureId)
                    .orElseThrow(() -> new ResourceNotFoundException("Config not found for Tenant: " + tenantId + ", App: " + applicationId + ", Role: " + roleId + ", Feature: " + featureId));
        } else {
            // Handle null roleId for unique config (requires partial index in DB)
            return configRepository.findByTenantIdAndApplicationIdAndFeatureIdAndRoleIdIsNull(tenantId, applicationId, featureId)
                    .orElseThrow(() -> new ResourceNotFoundException("Config not found for Tenant: " + tenantId + ", App: " + applicationId + ", Feature: " + featureId + " (no role)"));
        }
    }

    @Override
    @Transactional
    public TenantApplicationFeatureConfig createOrUpdateConfig(Long tenantId, Long applicationId, Long roleId, Long featureId, TenantApplicationFeatureConfigUpdateRequest request) {
        validateConfigDependencies(tenantId, applicationId, roleId, featureId, request.getThemeId());

        Optional<TenantApplicationFeatureConfig> existingConfig;
        if (roleId != null) {
            existingConfig = configRepository.findByTenantIdAndApplicationIdAndRoleIdAndFeatureId(tenantId, applicationId, roleId, featureId);
        } else {
            existingConfig = configRepository.findByTenantIdAndApplicationIdAndFeatureIdAndRoleIdIsNull(tenantId, applicationId, featureId);
        }

        TenantApplicationFeatureConfig config = existingConfig.orElseGet(TenantApplicationFeatureConfig::new);

        boolean isNew = config.getConfigId() == null;

        config.setTenantId(tenantId);
        config.setApplicationId(applicationId);
        config.setRoleId(roleId);
        config.setFeatureId(featureId);
        config.setIsEnabled(request.getIsEnabled());
        config.setThemeId(request.getThemeId());

        if (isNew) {
            config.setCreatedBy("system_config_create");
        }
        config.setUpdatedBy("system_config_update");

        return configRepository.save(config);
    }

    @Override
    @Transactional
    public TenantApplicationFeatureConfig patchConfig(Long tenantId, Long applicationId, Long roleId, Long featureId, TenantApplicationFeatureConfigPatchRequest request) {
        TenantApplicationFeatureConfig existingConfig = getConfig(tenantId, applicationId, roleId, featureId);

        if (request.getIsEnabled() != null) {
            existingConfig.setIsEnabled(request.getIsEnabled());
        }
        if (request.getThemeId() != null) {
            if (!themeRepository.existsById(request.getThemeId())) {
                throw new BadRequestException("Invalid ThemeId: " + request.getThemeId());
            }
            existingConfig.setThemeId(request.getThemeId());
        }

        existingConfig.setUpdatedBy("system_config_patch");
        return configRepository.save(existingConfig);
    }

    @Override
    @Transactional
    public void deleteConfig(Long tenantId, Long applicationId, Long roleId, Long featureId) {
        TenantApplicationFeatureConfig config = getConfig(tenantId, applicationId, roleId, featureId);
        configRepository.delete(config);
    }

    @Override
    public List<TenantApplicationFeatureConfig> getConfigsByTenantApp(Long tenantId, Long applicationId, Long roleId) {
        if (roleId != null) {
            return configRepository.findByTenantIdAndApplicationIdAndRoleId(tenantId, applicationId, roleId);
        } else {
            return configRepository.findByTenantIdAndApplicationIdAndRoleIdIsNull(tenantId, applicationId);
        }
    }

    @Override
    public EffectiveFeatureConfig getNestedFeatureConfig(Long tenantId, Long applicationId, Long roleId, Long featureId) {
        // 1. Validate existence of core entities
        Tenant tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant not found with ID: " + tenantId));
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found with ID: " + applicationId));
        Feature feature = featureRepository.findById(featureId)
                .orElseThrow(() -> new ResourceNotFoundException("Feature not found with ID: " + featureId));
        if (roleId != null) {
            userRoleRepository.findById(roleId)
                    .orElseThrow(() -> new ResourceNotFoundException("UserRole not found with ID: " + roleId));
        }

        // 2. Get the feature's specific config (isEnabled, themeId)
        Optional<TenantApplicationFeatureConfig> featureConfigOptional;
        if (roleId != null) {
            featureConfigOptional = configRepository.findByTenantIdAndApplicationIdAndRoleIdAndFeatureId(tenantId, applicationId, roleId, featureId);
        } else {
            featureConfigOptional = configRepository.findByTenantIdAndApplicationIdAndFeatureIdAndRoleIdIsNull(tenantId, applicationId, featureId);
        }

        Boolean isFeatureEnabled = featureConfigOptional.map(TenantApplicationFeatureConfig::getIsEnabled).orElse(true); // Default to true
        Long featureThemeId = featureConfigOptional.map(TenantApplicationFeatureConfig::getThemeId).orElse(null);

        // 3. Build the EffectiveFeatureConfig DTO
        EffectiveFeatureConfig effectiveFeatureConfig = new EffectiveFeatureConfig();
        effectiveFeatureConfig.setFeatureId(feature.getFeatureId());
        effectiveFeatureConfig.setFeatureName(feature.getFeatureName());
        effectiveFeatureConfig.setFeatureDescription(feature.getFeatureDescription());
        effectiveFeatureConfig.setIsEnabled(isFeatureEnabled);
        effectiveFeatureConfig.setThemeId(featureThemeId);
        effectiveFeatureConfig.setCreatedAt(feature.getCreatedAt());
        effectiveFeatureConfig.setUpdatedAt(feature.getUpdatedAt());
        effectiveFeatureConfig.setCreatedBy(feature.getCreatedBy());
        effectiveFeatureConfig.setUpdatedBy(feature.getUpdatedBy());

        // 4. Fetch all pages for this feature
        List<Page> pages = pageRepository.findByFeatureId(featureId);

        // 5. Build nested EffectivePages
        List<EffectivePage> effectivePages = pages.stream().map(page -> {
            EffectivePage effectivePage = new EffectivePage();
            effectivePage.setPageId(page.getPageId());
            effectivePage.setPageName(page.getPageName());
            effectivePage.setPageOrder(page.getPageOrder());
            effectivePage.setFeatureId(page.getFeatureId()); // Redundant but useful for DTO context
            effectivePage.setCreatedAt(page.getCreatedAt());
            effectivePage.setUpdatedAt(page.getUpdatedAt());
            effectivePage.setCreatedBy(page.getCreatedBy());
            effectivePage.setUpdatedBy(page.getUpdatedBy());

            // 5a. Fetch all forms for this page
            List<Form> forms = formRepository.findByPageId(page.getPageId());

            // 5b. Build nested EffectiveForms
            List<EffectiveForm> effectiveForms = forms.stream().map(form -> {
                EffectiveForm effectiveForm = new EffectiveForm();
                effectiveForm.setFormId(form.getFormId());
                effectiveForm.setFormName(form.getFormName());
                effectiveForm.setFormOrder(form.getFormOrder());
                effectiveForm.setPageId(form.getPageId()); // Redundant but useful for DTO context
                effectiveForm.setCreatedAt(form.getCreatedAt());
                effectiveForm.setUpdatedAt(form.getUpdatedAt());
                effectiveForm.setCreatedBy(form.getCreatedBy());
                effectiveForm.setUpdatedBy(form.getUpdatedBy());

                // 5c. Fetch and merge EffectiveFields for this form (using existing orchestration service)
                List<EffectiveField> effectiveFields = tenantApplicationFieldConfigService.getFieldsWithConfigForForm(tenantId, applicationId, form.getFormId());
                effectiveForm.setFields(effectiveFields);

                // As per current DBML, directFields is not applicable (Field.FormId is NOT NULL)
                effectivePage.setDirectFields(List.of()); // Empty list as no direct fields are allowed

                return effectiveForm;
            }).collect(Collectors.toList());
            effectivePage.setForms(effectiveForms);
            return effectivePage;
        }).collect(Collectors.toList());
        effectiveFeatureConfig.setPages(effectivePages);

        return effectiveFeatureConfig;
    }

    @Override
    @Transactional
    public EffectiveFeatureConfig updateNestedFeatureConfig(Long tenantId, Long applicationId, Long roleId, Long featureId, EffectiveFeatureConfigUpdateRequest request) {
        // 1. Validate existence of core entities
        tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant not found with ID: " + tenantId));
        applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found with ID: " + applicationId));
        featureRepository.findById(featureId)
                .orElseThrow(() -> new ResourceNotFoundException("Feature not found with ID: " + featureId));
        if (roleId != null) {
            userRoleRepository.findById(roleId)
                    .orElseThrow(() -> new ResourceNotFoundException("UserRole not found with ID: " + roleId));
        }

        // 2. Update the TenantApplicationFeatureConfig itself (isEnabled, themeId)
        TenantApplicationFeatureConfigUpdateRequest featureConfigUpdate = new TenantApplicationFeatureConfigUpdateRequest();
        featureConfigUpdate.setIsEnabled(request.getIsEnabled());
        featureConfigUpdate.setThemeId(request.getThemeId());
        createOrUpdateConfig(tenantId, applicationId, roleId, featureId, featureConfigUpdate); // Use existing method

        // 3. Handle nested pages
        if (request.getPages() != null) {
            List<Page> existingPages = pageRepository.findByFeatureId(featureId);
            Set<Long> processedPageIds = new HashSet<>();

            for (EffectivePageNestedUpdateRequest pageRequest : request.getPages()) {
                if (Boolean.TRUE.equals(pageRequest.get_delete())) {
                    if (pageRequest.getPageId() != null) {
                        pageRepository.deleteById(pageRequest.getPageId()); // Cascades to forms/fields
                    }
                } else if (pageRequest.getPageId() != null) {
                    // Update existing page
                    Page existingPage = pageRepository.findById(pageRequest.getPageId())
                            .orElseThrow(() -> new ResourceNotFoundException("Page not found with ID: " + pageRequest.getPageId()));
                    if (!existingPage.getFeatureId().equals(featureId)) {
                        throw new BadRequestException("Page ID " + pageRequest.getPageId() + " does not belong to Feature ID " + featureId);
                    }
                    existingPage.setPageName(pageRequest.getPageName());
                    existingPage.setPageOrder(pageRequest.getPageOrder());
                    existingPage.setUpdatedBy("system_update_nested_feature");
                    pageRepository.save(existingPage);
                    processedPageIds.add(existingPage.getPageId());
                    // Handle nested forms and fields
                    if (pageRequest.getForms() != null) {
                        handleNestedFormsForFeatureConfig(tenantId, applicationId, pageRequest.getPageId(), pageRequest.getForms());
                    }
                } else {
                    // Create new page
                    if (pageRepository.findByFeatureIdAndPageName(featureId, pageRequest.getPageName()).isPresent()) {
                        throw new ResourceConflictException("Page with name '" + pageRequest.getPageName() + "' already exists for feature ID: " + featureId);
                    }
                    Page newPage = new Page();
                    newPage.setFeatureId(featureId);
                    newPage.setPageName(pageRequest.getPageName());
                    newPage.setPageOrder(pageRequest.getPageOrder());
                    newPage.setCreatedBy("system_create_nested_feature");
                    newPage.setUpdatedBy("system_create_nested_feature");
                    Page createdPage = pageRepository.save(newPage);
                    processedPageIds.add(createdPage.getPageId());
                    // Handle nested forms and fields for newly created page
                    if (pageRequest.getForms() != null) {
                        handleNestedFormsForFeatureConfig(tenantId, applicationId, createdPage.getPageId(), pageRequest.getForms());
                    }
                }
            }
            // Delete pages that existed but were not in the request and not explicitly marked for delete
            List<Page> pagesToDelete = existingPages.stream()
                    .filter(p -> !processedPageIds.contains(p.getPageId()))
                    .collect(Collectors.toList());
            pageRepository.deleteAll(pagesToDelete);
        }

        // 4. Return the fully resolved EffectiveFeatureConfig after updates
        return getNestedFeatureConfig(tenantId, applicationId, roleId, featureId);
    }

    // Helper method for nested forms within updateNestedFeatureConfig
    private void handleNestedFormsForFeatureConfig(Long tenantId, Long applicationId, Long pageId, List<EffectiveFormNestedUpdateRequest> formRequests) {
        List<Form> existingForms = formRepository.findByPageId(pageId);
        Set<Long> processedFormIds = new HashSet<>();

        for (EffectiveFormNestedUpdateRequest formRequest : formRequests) {
            if (Boolean.TRUE.equals(formRequest.get_delete())) {
                if (formRequest.getFormId() != null) {
                    formRepository.deleteById(formRequest.getFormId()); // Cascades to fields
                }
            } else if (formRequest.getFormId() != null) {
                // Update existing form
                Form existingForm = formRepository.findById(formRequest.getFormId())
                        .orElseThrow(() -> new ResourceNotFoundException("Form not found with ID: " + formRequest.getFormId()));
                if (!existingForm.getPageId().equals(pageId)) {
                    throw new BadRequestException("Form ID " + formRequest.getFormId() + " does not belong to Page ID " + pageId);
                }
                existingForm.setFormName(formRequest.getFormName());
                existingForm.setFormOrder(formRequest.getFormOrder());
                existingForm.setUpdatedBy("system_update_nested_feature");
                formRepository.save(existingForm);
                processedFormIds.add(existingForm.getFormId());
                // Handle nested fields
                if (formRequest.getFields() != null) {
                    handleNestedFieldsForFeatureConfig(tenantId, applicationId, formRequest.getFormId(), formRequest.getFields());
                }
            } else {
                // Create new form
                if (formRepository.findByPageIdAndFormName(pageId, formRequest.getFormName()).isPresent()) {
                    throw new ResourceConflictException("Form with name '" + formRequest.getFormName() + "' already exists for page ID: " + pageId);
                }
                Form newForm = new Form();
                newForm.setPageId(pageId);
                newForm.setFormName(formRequest.getFormName());
                newForm.setFormOrder(formRequest.getFormOrder());
                newForm.setCreatedBy("system_create_nested_feature");
                newForm.setUpdatedBy("system_create_nested_feature");
                Form createdForm = formRepository.save(newForm);
                processedFormIds.add(createdForm.getFormId());
                // Handle nested fields for newly created form
                if (formRequest.getFields() != null) {
                    handleNestedFieldsForFeatureConfig(tenantId, applicationId, createdForm.getFormId(), formRequest.getFields());
                }
            }
        }
        // Delete forms that existed but were not in the request
        List<Form> formsToDelete = existingForms.stream()
                .filter(f -> !processedFormIds.contains(f.getFormId()))
                .collect(Collectors.toList());
        formRepository.deleteAll(formsToDelete);
    }

    // Helper method for nested fields within updateNestedFeatureConfig
    private void handleNestedFieldsForFeatureConfig(Long tenantId, Long applicationId, Long formId, List<EffectiveFieldNestedUpdateRequest> fieldRequests) {
        List<Field> existingFields = fieldRepository.findByFormId(formId);
        Set<Long> processedFieldIds = new HashSet<>();

        for (EffectiveFieldNestedUpdateRequest fieldRequest : fieldRequests) {
            if (Boolean.TRUE.equals(fieldRequest.get_delete())) {
                if (fieldRequest.getFieldId() != null) {
                    fieldRepository.deleteById(fieldRequest.getFieldId()); // Cascades to config
                }
            } else if (fieldRequest.getFieldId() != null) {
                // Update existing field
                Field existingField = fieldRepository.findById(fieldRequest.getFieldId())
                        .orElseThrow(() -> new ResourceNotFoundException("Field not found with ID: " + fieldRequest.getFieldId()));
                if (!existingField.getFormId().equals(formId)) {
                    throw new BadRequestException("Field ID " + fieldRequest.getFieldId() + " does not belong to Form ID " + formId);
                }
                updateFieldEntityFromRequest(existingField, fieldRequest);
                existingField.setUpdatedBy("system_update_nested_feature");
                fieldRepository.save(existingField);
                processedFieldIds.add(existingField.getFieldId());

                // Handle associated TenantApplicationFieldConfig (update only, creation/deletion is separate)
                // This assumes the EffectiveFieldNestedUpdateRequest does NOT carry config overrides directly.
                // If it does, you'd extract them and call tenantApplicationFieldConfigService.createOrUpdateConfig/patchConfig
            } else {
                // Create new field
                if (fieldRepository.findByFormIdAndFieldName(formId, fieldRequest.getFieldName()).isPresent()) {
                    throw new ResourceConflictException("Field with name '" + fieldRequest.getFieldName() + "' already exists for form ID: " + formId);
                }
                Field newField = new Field();
                newField.setFormId(formId);
                updateFieldEntityFromRequest(newField, fieldRequest);
                newField.setCreatedBy("system_create_nested_feature");
                newField.setUpdatedBy("system_create_nested_feature");
                Field createdField = fieldRepository.save(newField);
                processedFieldIds.add(createdField.getFieldId());

                // For newly created fields, you might also want to create a default TenantApplicationFieldConfig
                // or handle it if the request implies a specific initial config.
            }
        }
        // Delete fields that existed but were not in the request
        List<Field> fieldsToDelete = existingFields.stream()
                .filter(f -> !processedFieldIds.contains(f.getFieldId()))
                .collect(Collectors.toList());
        fieldRepository.deleteAll(fieldsToDelete);
    }

    private void updateFieldEntityFromRequest(Field field, EffectiveFieldNestedUpdateRequest request) {
        field.setFieldName(request.getFieldName());
        field.setFieldType(request.getFieldType());
        field.setInputType(request.getInputType());
        field.setDefaultLabel(request.getDefaultLabel());
        field.setDefaultValidationRules(request.getDefaultValidationRules());
    }

    private void validateConfigDependencies(Long tenantId, Long applicationId, Long roleId, Long featureId, Long themeId) {
        tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant not found with ID: " + tenantId));
        applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found with ID: " + applicationId));
        featureRepository.findById(featureId)
                .orElseThrow(() -> new ResourceNotFoundException("Feature not found with ID: " + featureId));
        if (roleId != null) {
            userRoleRepository.findById(roleId)
                    .orElseThrow(() -> new ResourceNotFoundException("UserRole not found with ID: " + roleId));
        }
        if (themeId != null) {
            themeRepository.findById(themeId)
                    .orElseThrow(() -> new ResourceNotFoundException("Theme not found with ID: " + themeId));
        }
        // Additional validation: Ensure feature is actually associated with the application (feature_application table)
        if (featureApplicationRepository.findByFeatureIdAndApplicationId(featureId, applicationId).isEmpty()) {
             throw new BadRequestException("Feature ID " + featureId + " is not available for Application ID " + applicationId + ". Add it via /applications/{applicationId}/features first.");
        }
    }
}