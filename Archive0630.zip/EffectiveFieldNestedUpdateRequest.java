package com.yourcompany.config.service;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EffectiveFieldNestedUpdateRequest {
    private Long fieldId; // Null if new field
    private String fieldName;
    private String fieldType;
    private String inputType;
    private String defaultLabel;
    private JsonNode defaultValidationRules;
    private Boolean _delete; // Flag for deletion
    // No isEnabled, customLabel, customValidationRules here directly.
    // These would be part of TenantApplicationFieldConfigUpdateRequest
    // which would be handled by a separate list of updates, or a more complex DTO.
    // For simplicity, this DTO focuses on the structural updates of the Field entity itself.
    // The configuration overrides (isEnabled, customLabel, validation) for fields
    // are handled by the TenantApplicationFieldConfigService's updateFieldConfigsForForm method.
}
