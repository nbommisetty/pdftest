package com.yourcompany.config.service;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EffectivePageNestedUpdateRequest {
    private Long pageId; // Null if new page
    private String pageName;
    private Integer pageOrder;
    private Boolean _delete; // Flag for deletion
    private List<EffectiveFormNestedUpdateRequest> forms; // Nested forms to update/create/delete
}
