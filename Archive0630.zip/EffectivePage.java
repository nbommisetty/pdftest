package com.yourcompany.config.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EffectivePage {
    private Long pageId;
    private String pageName;
    private Integer pageOrder;
    private Long featureId; // Derived from Page
    private List<EffectiveForm> forms; // Nested effective forms
    private List<EffectiveField> directFields; // Fields directly on page (if any were allowed, currently not)
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String createdBy;
    private String updatedBy;
}