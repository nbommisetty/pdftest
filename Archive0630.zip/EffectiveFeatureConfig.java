package com.yourcompany.config.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EffectiveFeatureConfig { // Represents the entire nested config for a feature
    private Long featureId;
    private String featureName;
    private String featureDescription;
    private Boolean isEnabled; // From TenantApplicationFeatureConfig
    private Long themeId; // From TenantApplicationFeatureConfig
    private List<EffectivePage> pages; // Nested effective pages
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String createdBy;
    private String updatedBy;
}