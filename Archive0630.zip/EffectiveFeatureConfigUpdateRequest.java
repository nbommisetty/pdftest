package com.yourcompany.config.service;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EffectiveFeatureConfigUpdateRequest {
    private Boolean isEnabled; // For feature itself
    private Long themeId; // For feature itself
    private List<EffectivePageNestedUpdateRequest> pages; // Nested pages to update/create/delete
}
