package com.yourcompany.config.service;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EffectiveField {
    private Long fieldId;
    private String fieldName;
    private String fieldType;
    private String inputType;
    private String label; // Merged: customLabel if present, else defaultLabel
    private JsonNode validationRules; // Merged: customValidationRules if present, else defaultValidationRules
    private Boolean isEnabled; // Merged: isEnabled from config if present, else true
    private Long formId;
    private Long pageId; // PageId is derived from Form
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String createdBy;
    private String updatedBy;
}