package com.yourcompany.config.service;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EffectiveFormNestedUpdateRequest {
    private Long formId; // Null if new form
    private String formName;
    private Integer formOrder;
    private Boolean _delete; // Flag for deletion
    private List<EffectiveFieldNestedUpdateRequest> fields; // Nested fields to update/create/delete
}
