# Angular PDF Viewer with PDF.js

This project is a complete Angular 16 application that demonstrates how to build a feature-rich PDF viewer using Mozilla's PDF.js library. It provides a clean, component-based implementation for rendering PDF documents fetched from a URL and includes essential user controls like zoom, download, and direct-to-preview printing.

## Features

* **Dynamic PDF Rendering**: Loads and displays PDF documents from a remote URL.
* **Custom UI Controls**: A clean toolbar provides controls for:
    * Zooming in and out.
    * Downloading the original PDF file.
    * Printing the PDF directly without opening a new tab.
* **Page Navigation Info**: Displays the current page number and the total page count.
* **Loading Indicator**: Shows a spinner while the PDF is being fetched and processed.

---

## Project Setup

To get this project running on your local machine, follow these steps.

### Prerequisites

* **Node.js**: Version `18.10.0` or higher within the v18 series.
* **Angular CLI**: Version `16.x.x`.

### 1. Clone or Copy the Project

Create a new directory for the project and copy the application files into it.

### 2. Install Dependencies

Open your terminal in the project's root directory and run the following command to install the necessary packages, including Angular and `pdfjs-dist`.

```bash
npm install

### 3. Configure `angular.json`

For PDF.js to function correctly, you must configure your `angular.json` file to include its assets in the build.

Find the `assets` and `styles` arrays under `projects.<your-app-name>.architect.build.options` and add the paths for the PDF.js worker, images, and stylesheet:

```json
"styles": [
  "src/styles.sass",
  "node_modules/pdfjs-dist/web/pdf_viewer.css"
],
"assets": [
  "src/favicon.ico",
  "src/assets",
  {
    "glob": "pdf.worker.js",
    "input": "node_modules/pdfjs-dist/build/",
    "output": "/"
  },
  {
    "glob": "**/*",
    "input": "node_modules/pdfjs-dist/web/images/",
    "output": "/images/"
  }
]

### 4. Configure `tsconfig.json`

To avoid TypeScript errors from the `pdfjs-dist` type definitions, add `"skipLibCheck": true` to the `compilerOptions` in your `tsconfig.json` file.

```json
"compilerOptions": {
  // ... other options
  "skipLibCheck": true,
  // ... other options
}
### 5. Run the Application

Start the development server using the Angular CLI:

```bash
ng serve

## Explanation of the Print Functionality

The `printPdf()` method is designed to provide a seamless user experience by opening the browser's print preview directly, without navigating away from the page or opening a new tab. It solves two common challenges: cross-origin security restrictions and timing issues with the print dialog.

Here is a step-by-step breakdown of its logic:

1.  **Fetch PDF as a Blob**: The function begins by fetching the raw binary data of the PDF from its source URL (`pdfSrc`). It then converts this data into a `Blob`, which is a file-like object that can be easily handled in the browser.

2.  **Create a Blob URL**: A local, temporary URL is generated from the `Blob` (e.g., `blob:http://localhost:4200/<unique-id>`). This is the key to bypassing browser security. Because this URL originates from `localhost`, the browser considers it "same-origin," allowing our application's code to interact with it freely.

3.  **Create a Hidden `iframe`**: An `<iframe>` element is created in the background. This acts as an invisible, sandboxed browser window within our application.

4.  **Load and Print**: The `Blob URL` is set as the `src` for this hidden `iframe`. Once the `iframe` finishes loading the PDF content (`iframe.onload`), the code calls `iframe.contentWindow.print()`, which triggers the browser's native print dialog.

5.  **Reliable Cleanup**: To solve the "flashing preview" problem, the code doesn't immediately remove the `iframe`. Instead, it uses `matchMedia('print')` to listen for the moment the user closes the print dialog. Only after the print process is complete does it perform the cleanup, which involves removing the `iframe` from the page and revoking the `Blob URL` to free up memory.