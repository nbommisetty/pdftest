import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
// Import the necessary modules from the installed pdfjs-dist package
import { getDocument, GlobalWorkerOptions, PDFDocumentProxy } from 'pdfjs-dist';
import { PDFViewer, EventBus, PDFLinkService } from 'pdfjs-dist/web/pdf_viewer';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass'] // Corrected to .sass
})
export class AppComponent implements OnInit, AfterViewInit {
  // Get a reference to the div that will contain the PDF viewer
  @ViewChild('viewerContainer') viewerContainer!: ElementRef;

  // Declare properties for the viewer and its state
  pdfViewer: PDFViewer | undefined;
  isLoading = true;
  pageNum = 0;
  pageCount = 0;

  // A sample PDF URL. Make sure the server allows CORS requests.
  pdfSrc = 'https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf';

  constructor() {
    // Set the worker source for PDF.js. This is crucial for performance.
    // The path points to the file we configured in angular.json.
    GlobalWorkerOptions.workerSrc = 'pdf.worker.js';
  }

  ngOnInit(): void {
    // We will load the PDF when the component initializes
    this.loadPdf();
  }

  ngAfterViewInit(): void {
    // The viewer must be initialized after the view (and #viewerContainer) is ready
    this.initializePdfViewer();
  }

  /**
   * Initializes the PDFViewer and its required components like EventBus and PDFLinkService.
   */
  initializePdfViewer(): void {
    if (this.viewerContainer) {
      const container = this.viewerContainer.nativeElement;
      const eventBus = new EventBus();
      const linkService = new PDFLinkService({ eventBus });

      // Corrected: Removed the 'useOnlyCssZoom' property
      this.pdfViewer = new PDFViewer({
        container,
        eventBus,
        linkService,
      });

      linkService.setViewer(this.pdfViewer);

      // Listen for page changes to update the UI
      eventBus.on('pagechanging', (evt: any) => {
        if (typeof evt.pageNumber === 'number') {
            this.pageNum = evt.pageNumber;
        }
      });

      // Fired when the pages are initialized
      eventBus.on('pagesinit', () => {
        if (this.pdfViewer) {
            this.pageNum = this.pdfViewer.currentPageNumber;
            this.pageCount = this.pdfViewer.pagesCount;
        }
      });
    }
  }

  /**
   * Fetches the PDF from the URL as binary data (ArrayBuffer) and loads it into the viewer.
   */
  async loadPdf(): Promise<void> {
    this.isLoading = true;
    try {
      // Fetch the PDF file
      const response = await fetch(this.pdfSrc);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const pdfData = await response.arrayBuffer();

      // Use getDocument from pdfjs-dist to parse the document
      const loadingTask = getDocument({ data: pdfData });
      const pdfDocument: PDFDocumentProxy = await loadingTask.promise;

      // Set the parsed document in our viewer instance
      if (this.pdfViewer) {
        this.pdfViewer.setDocument(pdfDocument);
      }

    } catch (error) {
      console.error('Failed to load PDF:', error);
      // Handle the error appropriately in a real application
    } finally {
      this.isLoading = false;
    }
  }

  /**
   * Handles the zoom-in button click.
   */
  zoomIn(): void {
    if (this.pdfViewer) {
      // Increase the current scale by 10%
      this.pdfViewer.currentScaleValue = (parseFloat(this.pdfViewer.currentScaleValue) * 1.1).toFixed(2);
    }
  }

  /**
   * Handles the zoom-out button click.
   */
  zoomOut(): void {
    if (this.pdfViewer) {
      // Decrease the current scale by 10%
      this.pdfViewer.currentScaleValue = (parseFloat(this.pdfViewer.currentScaleValue) / 1.1).toFixed(2);
    }
  }

  /**
   * Triggers the download of the PDF file.
   */
  async downloadPdf(): Promise<void> {
    try {
      const response = await fetch(this.pdfSrc);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = url;
      a.download = this.pdfSrc.split('/').pop() || 'download.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to download PDF:', error);
    }
  }

  /**
   * Opens the browser's print dialog for the PDF without opening a new tab.
   * This method avoids cross-origin security errors by fetching the PDF
   * and loading it into the iframe as a Blob URL.
   */
  async printPdf(): Promise<void> {
    try {
      // Fetch the PDF data and create a Blob from it.
      const response = await fetch(this.pdfSrc);
      const blob = await response.blob();
      
      // Create a Blob URL. This URL is treated as a same-origin URL by the browser.
      const blobUrl = window.URL.createObjectURL(blob);

      // Create a hidden iframe to load the PDF.
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      document.body.appendChild(iframe);

      // Set the iframe's source to our same-origin Blob URL.
      iframe.src = blobUrl;

      // Wait for the PDF to load completely in the iframe.
      iframe.onload = () => {
        const iframeWindow = iframe.contentWindow;
        if (iframeWindow) {
          iframeWindow.focus(); // Focus on the iframe
          
          // Define a listener for when the print media query no longer matches.
          const mediaQueryList = iframeWindow.matchMedia('print');
          const printListener = (mql: MediaQueryListEvent) => {
            if (!mql.matches) {
              // This block runs after the print dialog is closed.
              document.body.removeChild(iframe);
              window.URL.revokeObjectURL(blobUrl);
              mediaQueryList.removeEventListener('change', printListener); // Clean up the listener
            }
          };
          mediaQueryList.addEventListener('change', printListener);

          iframeWindow.print(); // Trigger the print dialog
        }
      };
    } catch (error) {
      console.error('Failed to print PDF:', error);
    }
  }
}
