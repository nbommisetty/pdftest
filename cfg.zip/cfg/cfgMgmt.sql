CREATE TABLE "tenant" (
  "tenant_id" BIGINT PRIMARY KEY,
  "tenant_name" VARCHAR(100) UNIQUE NOT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT (now()),
  "updated_at" TIMESTAMP NOT NULL DEFAULT (now())
);

CREATE TABLE "application" (
  "application_id" BIGINT PRIMARY KEY,
  "application_name" VARCHAR(100) UNIQUE NOT NULL,
  "application_description" TEXT,
  "created_at" TIMESTAMP NOT NULL DEFAULT (now()),
  "updated_at" TIMESTAMP NOT NULL DEFAULT (now())
);

CREATE TABLE "feature" (
  "feature_id" BIGINT PRIMARY KEY,
  "feature_name" VARCHAR(100) UNIQUE NOT NULL,
  "feature_description" TEXT,
  "created_at" TIMESTAMP NOT NULL DEFAULT (now()),
  "updated_at" TIMESTAMP NOT NULL DEFAULT (now())
);

CREATE TABLE "user_role" (
  "role_id" BIGINT PRIMARY KEY,
  "role_name" VARCHAR(50) UNIQUE NOT NULL,
  "role_description" TEXT,
  "created_at" TIMESTAMP NOT NULL DEFAULT (now()),
  "updated_at" TIMESTAMP NOT NULL DEFAULT (now())
);

CREATE TABLE "feature_application" (
  "feature_application_id" BIGINT PRIMARY KEY,
  "feature_id" BIGINT NOT NULL,
  "application_id" BIGINT NOT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT (now()),
  "updated_at" TIMESTAMP NOT NULL DEFAULT (now())
);

CREATE TABLE "page" (
  "page_id" BIGINT PRIMARY KEY,
  "feature_id" BIGINT NOT NULL,
  "page_name" VARCHAR(100) NOT NULL,
  "page_order" INT NOT NULL DEFAULT 0,
  "created_at" TIMESTAMP NOT NULL DEFAULT (now()),
  "updated_at" TIMESTAMP NOT NULL DEFAULT (now())
);

CREATE TABLE "form" (
  "form_id" BIGINT PRIMARY KEY,
  "page_id" BIGINT NOT NULL,
  "form_name" VARCHAR(100) NOT NULL,
  "form_order" INT NOT NULL DEFAULT 0,
  "created_at" TIMESTAMP NOT NULL DEFAULT (now()),
  "updated_at" TIMESTAMP NOT NULL DEFAULT (now())
);

CREATE TABLE "field" (
  "field_id" BIGINT PRIMARY KEY,
  "page_id" BIGINT NOT NULL,
  "form_id" BIGINT,
  "field_name" VARCHAR(100) NOT NULL,
  "field_type" VARCHAR(50) NOT NULL,
  "default_label" VARCHAR(255) NOT NULL,
  "default_validation_rules" JSONB,
  "created_at" TIMESTAMP NOT NULL DEFAULT (now()),
  "updated_at" TIMESTAMP NOT NULL DEFAULT (now())
);

CREATE TABLE "tenant_application_feature_config" (
  "config_id" BIGINT PRIMARY KEY,
  "tenant_id" BIGINT NOT NULL,
  "application_id" BIGINT NOT NULL,
  "role_id" BIGINT,
  "feature_id" BIGINT NOT NULL,
  "is_enabled" BOOLEAN NOT NULL DEFAULT true,
  "created_at" TIMESTAMP NOT NULL DEFAULT (now()),
  "updated_at" TIMESTAMP NOT NULL DEFAULT (now())
);

CREATE TABLE "tenant_application_field_config" (
  "config_id" BIGINT PRIMARY KEY,
  "tenant_id" BIGINT NOT NULL,
  "application_id" BIGINT NOT NULL,
  "field_id" BIGINT NOT NULL,
  "is_enabled" BOOLEAN NOT NULL DEFAULT true,
  "custom_label" VARCHAR(255),
  "custom_validation_rules" JSONB,
  "created_at" TIMESTAMP NOT NULL DEFAULT (now()),
  "updated_at" TIMESTAMP NOT NULL DEFAULT (now())
);

CREATE UNIQUE INDEX ON "feature_application" ("feature_id", "application_id");

CREATE UNIQUE INDEX ON "page" ("feature_id", "page_name");

CREATE UNIQUE INDEX ON "form" ("page_id", "form_name");

CREATE UNIQUE INDEX ON "field" ("page_id", "field_name");

CREATE UNIQUE INDEX ON "tenant_application_feature_config" ("tenant_id", "application_id", "role_id", "feature_id");

CREATE UNIQUE INDEX ON "tenant_application_field_config" ("tenant_id", "application_id", "field_id");

COMMENT ON COLUMN "tenant"."tenant_id" IS 'Primary key for tenants. Auto-incrementing mechanism handled by specific DB DDL (e.g., IDENTITY in Postgres).';

COMMENT ON COLUMN "tenant"."tenant_name" IS 'Unique name for each tenant';

COMMENT ON COLUMN "application"."application_id" IS 'Primary key for applications. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "application"."application_name" IS 'e.g., OnlineBanking(Web), MobileBanking, OnlineAccountOpening';

COMMENT ON COLUMN "feature"."feature_id" IS 'Primary key for features. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "feature"."feature_name" IS 'e.g., Wire Transfers, Direct Deposits';

COMMENT ON COLUMN "user_role"."role_id" IS 'Primary key for user roles. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "user_role"."role_name" IS 'e.g., business-admin, business-subuser, readonly';

COMMENT ON COLUMN "feature_application"."feature_application_id" IS 'Primary key for feature_application. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "page"."page_id" IS 'Primary key for pages. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "page"."page_name" IS 'e.g., Initiate Transfer, Review Transfer';

COMMENT ON COLUMN "page"."page_order" IS 'Display order of pages within a feature';

COMMENT ON COLUMN "form"."form_id" IS 'Primary key for forms. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "form"."form_name" IS 'e.g., Recipient Details, Amount Input';

COMMENT ON COLUMN "form"."form_order" IS 'Display order of forms within a page';

COMMENT ON COLUMN "field"."field_id" IS 'Primary key for fields. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "field"."page_id" IS 'Foreign key to page. Every field belongs to a page.';

COMMENT ON COLUMN "field"."form_id" IS 'Foreign key to form. Nullable if the field is a read-only field directly on a page, not part of a form.';

COMMENT ON COLUMN "field"."field_name" IS 'System name for the field (e.g., recipient_account_number)';

COMMENT ON COLUMN "field"."field_type" IS 'e.g., TEXT_INPUT, NUMBER_INPUT, DATE_PICKER, DROPDOWN';

COMMENT ON COLUMN "field"."default_label" IS 'Default display label for the field';

COMMENT ON COLUMN "field"."default_validation_rules" IS 'Default validation rules in JSON format';

COMMENT ON COLUMN "tenant_application_feature_config"."config_id" IS 'Primary key for tenant application feature configs. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "tenant_application_feature_config"."application_id" IS 'Foreign key to application. Allows tenant-specific feature configurations to vary by application.';

COMMENT ON COLUMN "tenant_application_feature_config"."role_id" IS 'Foreign key to user_role. Nullable to support applications without explicit user roles.';

COMMENT ON COLUMN "tenant_application_feature_config"."is_enabled" IS 'True if feature is enabled for the tenant within this specific application and for this role.';

COMMENT ON COLUMN "tenant_application_field_config"."config_id" IS 'Primary key for tenant application field configs. Auto-incrementing mechanism handled by specific DB DDL.';

COMMENT ON COLUMN "tenant_application_field_config"."application_id" IS 'Foreign key to application. Allows tenant-specific field configurations to vary by application.';

COMMENT ON COLUMN "tenant_application_field_config"."is_enabled" IS 'True if field is enabled for the tenant within its feature/application context';

COMMENT ON COLUMN "tenant_application_field_config"."custom_label" IS 'Tenant-specific override for field label';

COMMENT ON COLUMN "tenant_application_field_config"."custom_validation_rules" IS 'Tenant-specific override for field validation rules';

ALTER TABLE "feature_application" ADD FOREIGN KEY ("application_id") REFERENCES "application" ("application_id");

ALTER TABLE "feature_application" ADD FOREIGN KEY ("feature_id") REFERENCES "feature" ("feature_id");

ALTER TABLE "page" ADD FOREIGN KEY ("feature_id") REFERENCES "feature" ("feature_id");

ALTER TABLE "form" ADD FOREIGN KEY ("page_id") REFERENCES "page" ("page_id");

ALTER TABLE "field" ADD FOREIGN KEY ("page_id") REFERENCES "page" ("page_id");

ALTER TABLE "field" ADD FOREIGN KEY ("form_id") REFERENCES "form" ("form_id");

ALTER TABLE "tenant_application_feature_config" ADD FOREIGN KEY ("tenant_id") REFERENCES "tenant" ("tenant_id");

ALTER TABLE "tenant_application_feature_config" ADD FOREIGN KEY ("application_id") REFERENCES "application" ("application_id");

ALTER TABLE "tenant_application_feature_config" ADD FOREIGN KEY ("role_id") REFERENCES "user_role" ("role_id");

ALTER TABLE "tenant_application_feature_config" ADD FOREIGN KEY ("feature_id") REFERENCES "feature" ("feature_id");

ALTER TABLE "tenant_application_field_config" ADD FOREIGN KEY ("tenant_id") REFERENCES "tenant" ("tenant_id");

ALTER TABLE "tenant_application_field_config" ADD FOREIGN KEY ("application_id") REFERENCES "application" ("application_id");

ALTER TABLE "tenant_application_field_config" ADD FOREIGN KEY ("field_id") REFERENCES "field" ("field_id");
