CREATE TABLE [tenant] (
  [tenant_id] BIGINT PRIMARY KEY,
  [tenant_name] VARCHAR(100) UNIQUE NOT NULL,
  [created_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [updated_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [created_by] VARCHAR(100),
  [updated_by] VARCHAR(100)
)
GO

CREATE TABLE [application] (
  [application_id] BIGINT PRIMARY KEY,
  [application_name] VARCHAR(100) UNIQUE NOT NULL,
  [application_description] TEXT,
  [created_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [updated_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [created_by] VARCHAR(100),
  [updated_by] VARCHAR(100)
)
GO

CREATE TABLE [feature] (
  [feature_id] BIGINT PRIMARY KEY,
  [feature_name] VARCHAR(100) UNIQUE NOT NULL,
  [feature_description] TEXT,
  [created_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [updated_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [created_by] VARCHAR(100),
  [updated_by] VARCHAR(100)
)
GO

CREATE TABLE [user_role] (
  [role_id] BIGINT PRIMARY KEY,
  [role_name] VARCHAR(50) UNIQUE NOT NULL,
  [role_description] TEXT,
  [created_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [updated_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [created_by] VARCHAR(100),
  [updated_by] VARCHAR(100)
)
GO

CREATE TABLE [page] (
  [page_id] BIGINT PRIMARY KEY,
  [feature_id] BIGINT NOT NULL,
  [page_name] VARCHAR(100) NOT NULL,
  [page_order] INT NOT NULL DEFAULT (0),
  [created_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [updated_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [created_by] VARCHAR(100),
  [updated_by] VARCHAR(100)
)
GO

CREATE TABLE [form] (
  [form_id] BIGINT PRIMARY KEY,
  [page_id] BIGINT NOT NULL,
  [form_name] VARCHAR(100) NOT NULL,
  [form_order] INT NOT NULL DEFAULT (0),
  [created_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [updated_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [created_by] VARCHAR(100),
  [updated_by] VARCHAR(100)
)
GO

CREATE TABLE [field] (
  [field_id] BIGINT PRIMARY KEY,
  [page_id] BIGINT NOT NULL,
  [form_id] BIGINT,
  [field_name] VARCHAR(100) NOT NULL,
  [field_type] VARCHAR(50) NOT NULL,
  [inputType] VARCHAR(50) NOT NULL,
  [default_label] VARCHAR(255) NOT NULL,
  [default_validation_rules] NVARCHAR(MAX),
  [created_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [updated_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [created_by] VARCHAR(100),
  [updated_by] VARCHAR(100)
)
GO

CREATE TABLE [feature_application] (
  [feature_application_id] BIGINT PRIMARY KEY,
  [feature_id] BIGINT NOT NULL,
  [application_id] BIGINT NOT NULL,
  [created_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [updated_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [created_by] VARCHAR(100),
  [updated_by] VARCHAR(100)
)
GO

CREATE TABLE [tenant_application_feature_config] (
  [config_id] BIGINT PRIMARY KEY,
  [tenant_id] BIGINT NOT NULL,
  [application_id] BIGINT NOT NULL,
  [role_id] BIGINT,
  [feature_id] BIGINT NOT NULL,
  [is_enabled] BOOLEAN NOT NULL DEFAULT (true),
  [created_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [updated_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [created_by] VARCHAR(100),
  [updated_by] VARCHAR(100)
)
GO

CREATE TABLE [tenant_application_field_config] (
  [config_id] BIGINT PRIMARY KEY,
  [tenant_id] BIGINT NOT NULL,
  [application_id] BIGINT NOT NULL,
  [field_id] BIGINT NOT NULL,
  [is_enabled] BOOLEAN NOT NULL DEFAULT (true),
  [custom_label] VARCHAR(255),
  [custom_validation_rules] NVARCHAR(MAX),
  [created_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [updated_at] TIMESTAMP NOT NULL DEFAULT (now()),
  [created_by] VARCHAR(100),
  [updated_by] VARCHAR(100)
)
GO

CREATE UNIQUE INDEX [page_index_0] ON [page] ("feature_id", "page_name")
GO

CREATE UNIQUE INDEX [form_index_1] ON [form] ("page_id", "form_name")
GO

CREATE UNIQUE INDEX [field_index_2] ON [field] ("page_id", "field_name")
GO

CREATE UNIQUE INDEX [feature_application_index_3] ON [feature_application] ("feature_id", "application_id")
GO

CREATE UNIQUE INDEX [tenant_application_feature_config_index_4] ON [tenant_application_feature_config] ("tenant_id", "application_id", "role_id", "feature_id")
GO

CREATE UNIQUE INDEX [tenant_application_field_config_index_5] ON [tenant_application_field_config] ("tenant_id", "application_id", "field_id")
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Primary key for tenants. Auto-incrementing mechanism handled by specific DB DDL (e.g., IDENTITY in Postgres).',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant',
@level2type = N'Column', @level2name = 'tenant_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Unique name for each tenant.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant',
@level2type = N'Column', @level2name = 'tenant_name';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who created this tenant.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant',
@level2type = N'Column', @level2name = 'created_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who last updated this tenant.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant',
@level2type = N'Column', @level2name = 'updated_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Primary key for applications. Auto-incrementing mechanism handled by specific DB DDL.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'application',
@level2type = N'Column', @level2name = 'application_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'e.g., OnlineBanking(Web), MobileBanking, OnlineAccountOpening.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'application',
@level2type = N'Column', @level2name = 'application_name';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who created this application.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'application',
@level2type = N'Column', @level2name = 'created_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who last updated this application.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'application',
@level2type = N'Column', @level2name = 'updated_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Primary key for features. Auto-incrementing mechanism handled by specific DB DDL.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'feature',
@level2type = N'Column', @level2name = 'feature_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'e.g., Wire Transfers, Direct Deposits.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'feature',
@level2type = N'Column', @level2name = 'feature_name';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who created this feature.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'feature',
@level2type = N'Column', @level2name = 'created_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who last updated this feature.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'feature',
@level2type = N'Column', @level2name = 'updated_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Primary key for user roles. Auto-incrementing mechanism handled by specific DB DDL.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'user_role',
@level2type = N'Column', @level2name = 'role_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'e.g., business-admin, business-subuser, readonly.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'user_role',
@level2type = N'Column', @level2name = 'role_name';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who created this role.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'user_role',
@level2type = N'Column', @level2name = 'created_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who last updated this role.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'user_role',
@level2type = N'Column', @level2name = 'updated_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Primary key for pages. Auto-incrementing mechanism handled by specific DB DDL.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'page',
@level2type = N'Column', @level2name = 'page_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'e.g., Initiate Transfer, Review Transfer.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'page',
@level2type = N'Column', @level2name = 'page_name';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Display order of pages within a feature.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'page',
@level2type = N'Column', @level2name = 'page_order';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who created this page.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'page',
@level2type = N'Column', @level2name = 'created_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who last updated this page.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'page',
@level2type = N'Column', @level2name = 'updated_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Primary key for forms. Auto-incrementing mechanism handled by specific DB DDL.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'form',
@level2type = N'Column', @level2name = 'form_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'e.g., Recipient Details, Amount Input.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'form',
@level2type = N'Column', @level2name = 'form_name';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Display order of forms within a page.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'form',
@level2type = N'Column', @level2name = 'form_order';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who created this form.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'form',
@level2type = N'Column', @level2name = 'created_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who last updated this form.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'form',
@level2type = N'Column', @level2name = 'updated_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Primary key for fields. Auto-incrementing mechanism handled by specific DB DDL.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'field',
@level2type = N'Column', @level2name = 'field_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Foreign key to page. Every field belongs to a page.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'field',
@level2type = N'Column', @level2name = 'page_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Foreign key to form. Nullable if the field is a read-only field directly on a page, not part of a form.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'field',
@level2type = N'Column', @level2name = 'form_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'System name for the field (e.g., recipient_account_number).',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'field',
@level2type = N'Column', @level2name = 'field_name';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'e.g., TEXT_INPUT, NUMBER_INPUT, DATE_PICKER, DROPDOWN.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'field',
@level2type = N'Column', @level2name = 'field_type';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Defines the HTML input type or logical input control for the field.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'field',
@level2type = N'Column', @level2name = 'inputType';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Default display label for the field.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'field',
@level2type = N'Column', @level2name = 'default_label';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Default validation rules in JSON format.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'field',
@level2type = N'Column', @level2name = 'default_validation_rules';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who created this field.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'field',
@level2type = N'Column', @level2name = 'created_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who last updated this field.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'field',
@level2type = N'Column', @level2name = 'updated_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Primary key. Auto-incrementing mechanism handled by specific DB DDL.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'feature_application',
@level2type = N'Column', @level2name = 'feature_application_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who created this association.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'feature_application',
@level2type = N'Column', @level2name = 'created_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who last updated this association.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'feature_application',
@level2type = N'Column', @level2name = 'updated_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Primary key. Auto-incrementing mechanism handled by specific DB DDL.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant_application_feature_config',
@level2type = N'Column', @level2name = 'config_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Foreign key to application. Allows tenant-specific feature configurations to vary by application.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant_application_feature_config',
@level2type = N'Column', @level2name = 'application_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Foreign key to user_role. Nullable to support applications without explicit user roles.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant_application_feature_config',
@level2type = N'Column', @level2name = 'role_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'True if feature is enabled for the tenant within this specific application and for this role.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant_application_feature_config',
@level2type = N'Column', @level2name = 'is_enabled';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who created this config.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant_application_feature_config',
@level2type = N'Column', @level2name = 'created_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who last updated this config.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant_application_feature_config',
@level2type = N'Column', @level2name = 'updated_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Primary key. Auto-incrementing mechanism handled by specific DB DDL.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant_application_field_config',
@level2type = N'Column', @level2name = 'config_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Foreign key to application. Allows tenant-specific field configurations to vary by application.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant_application_field_config',
@level2type = N'Column', @level2name = 'application_id';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'True if field is enabled for the tenant within its feature/application context.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant_application_field_config',
@level2type = N'Column', @level2name = 'is_enabled';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Tenant-specific override for field label.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant_application_field_config',
@level2type = N'Column', @level2name = 'custom_label';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Tenant-specific override for field validation rules.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant_application_field_config',
@level2type = N'Column', @level2name = 'custom_validation_rules';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who created this config.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant_application_field_config',
@level2type = N'Column', @level2name = 'created_by';
GO

EXEC sp_addextendedproperty
@name = N'Column_Description',
@value = 'Username of the user who last updated this config.',
@level0type = N'Schema', @level0name = 'dbo',
@level1type = N'Table',  @level1name = 'tenant_application_field_config',
@level2type = N'Column', @level2name = 'updated_by';
GO

ALTER TABLE [feature_application] ADD FOREIGN KEY ([application_id]) REFERENCES [application] ([application_id])
GO

ALTER TABLE [feature_application] ADD FOREIGN KEY ([feature_id]) REFERENCES [feature] ([feature_id])
GO

ALTER TABLE [page] ADD FOREIGN KEY ([feature_id]) REFERENCES [feature] ([feature_id])
GO

ALTER TABLE [form] ADD FOREIGN KEY ([page_id]) REFERENCES [page] ([page_id])
GO

ALTER TABLE [field] ADD FOREIGN KEY ([page_id]) REFERENCES [page] ([page_id])
GO

ALTER TABLE [field] ADD FOREIGN KEY ([form_id]) REFERENCES [form] ([form_id])
GO

ALTER TABLE [tenant_application_feature_config] ADD FOREIGN KEY ([tenant_id]) REFERENCES [tenant] ([tenant_id])
GO

ALTER TABLE [tenant_application_feature_config] ADD FOREIGN KEY ([application_id]) REFERENCES [application] ([application_id])
GO

ALTER TABLE [tenant_application_feature_config] ADD FOREIGN KEY ([role_id]) REFERENCES [user_role] ([role_id])
GO

ALTER TABLE [tenant_application_feature_config] ADD FOREIGN KEY ([feature_id]) REFERENCES [feature] ([feature_id])
GO

ALTER TABLE [tenant_application_field_config] ADD FOREIGN KEY ([tenant_id]) REFERENCES [tenant] ([tenant_id])
GO

ALTER TABLE [tenant_application_field_config] ADD FOREIGN KEY ([application_id]) REFERENCES [application] ([application_id])
GO

ALTER TABLE [tenant_application_field_config] ADD FOREIGN KEY ([field_id]) REFERENCES [field] ([field_id])
GO
