import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

window.onerror = function (message, source, lineno, colno, error) {
  console.log("window.onerror caught:", {
    message: message, // The error message
    source: source,   // URL of the script where the error occurred
    lineno: lineno,   // Line number
    colno: colno,     // Column number
    // Log the error object itself and attempt to log the stack
    errorObject: error, // The actual error object (might be null/undefined)
    errorStack: error ? error.stack : 'Stack not available' // Access error.stack if error exists
  });

  // Consider logging to an external service here as well

  // Return true to prevent the default browser error handling (optional)
  return true;
};

// Also enhance the unhandledrejection listener if needed
window.addEventListener('unhandledrejection', function(event) {
  console.error('Unhandled Promise Rejection:', {
     reason: event.reason, // The reason for rejection (often an Error object)
     reasonStack: event.reason instanceof Error ? event.reason.stack : 'Stack not available in reason'
  });
  // Prevent default handling
  event.preventDefault();
});

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
