import React, { Component, ErrorInfo, ReactNode } from 'react';

// Define the props for the Error Boundary, primarily 'children'
interface Props {
  children: ReactNode; // The component(s) it wraps
  fallback?: ReactNode; // Optional custom fallback UI
}

// Define the state for the Error Boundary
interface State {
  hasError: boolean;
  error: Error | null;
}

class PdfErrorBoundary extends Component<Props, State> {
  // Initialize the state
  public state: State = {
    hasError: false,
    error: null,
  };

  /**
   * This lifecycle method is invoked after an error has been thrown by a descendant component.
   * It receives the error that was thrown as a parameter and should return a value to update state.
   * @param error The error that was thrown.
   * @returns An object to update state, indicating an error occurred.
   */
  public static getDerivedStateFromError(error: Error): State {
    // Update state so the next render will show the fallback UI.
    console.log("Error caught by getDerivedStateFromError:", error);
    return { hasError: true, error: error };
  }

  /**
   * This lifecycle method is invoked after an error has been thrown by a descendant component.
   * It receives two parameters:
   * 1. error - The error that was thrown.
   * 2. errorInfo - An object with a componentStack key containing information about which
   * component threw the error.
   * This is a good place for logging errors to a reporting service.
   * @param error The error that was thrown.
   * @param errorInfo Information about the component stack trace.
   */
  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
    // You can also log the error to an error reporting service here
    // Example: logErrorToMyService(error, errorInfo);
  }

  // Render method decides what to display
  public render() {
    // If an error occurred, render the fallback UI
    if (this.state.hasError) {
      // You can provide a custom fallback UI via props
      if (this.props.fallback) {
        return this.props.fallback;
      }
      // Default fallback UI
      return (
        <div style={{ padding: '20px', border: '1px solid red', margin: '10px', backgroundColor: '#ffeeee' }}>
          <h2>Something went wrong while loading the PDF viewer.</h2>
          <p>We've logged the error and will look into it.</p>
          {/* Optionally display error details during development */}
          {process.env.NODE_ENV === 'development' && this.state.error && (
            <details style={{ whiteSpace: 'pre-wrap' }}>
              <summary>Error Details</summary>
              {this.state.error.toString()}
              <br />
              {/* ErrorInfo usually contains componentStack */}
            </details>
          )}
        </div>
      );
    }

    // If no error, render the children components normally
    return this.props.children;
  }
}

export default PdfErrorBoundary;
