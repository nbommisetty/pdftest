import React, { useState, useCallback } from 'react';
// Import core components and pdfjs interaction from react-pdf
import { Document, Page, pdfjs } from 'react-pdf';
// Import type for LoadSuccessParams if using TypeScript and @types/react-pdf (optional but good practice)
// Note: @types/react-pdf might not exist or be up-to-date. Defining the type inline is often sufficient.
// import type { DocumentLoadSuccessParams } from 'react-pdf/dist/cjs/shared/types'; // Example path, might vary

// --- Import CSS for react-pdf layers ---
// These are essential for text selection, annotations (like links), etc. to render correctly.
// If you omit these, the PDF might display, but interactive elements won't work.
import 'react-pdf/dist/Page/AnnotationLayer.css';
import 'react-pdf/dist/Page/TextLayer.css';
// --- Worker Setup ---
// pdfjs is the library react-pdf uses under the hood.
// It uses web workers to process PDFs off the main thread for performance.
// You MUST point it to the worker file. Choose ONE of the options below:

// Option 1: Use a CDN (Easy for quick setup)
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

// Option 2: Copy 'pdf.worker.js' from 'node_modules/pdfjs-dist/build/' to your public folder
// This is often the most reliable method for frameworks like Create React App or Vite.
// Make sure the path '/pdf.worker.js' correctly points to the file in your public directory.
//pdfjs.GlobalWorkerOptions.workerSrc = '/pdf.worker.mjs';

// Option 3: If you installed pdfjs-dist as a dependency (npm install pdfjs-dist)
// import workerSrc from 'pdfjs-dist/build/pdf.worker.entry'; // Adjust path if needed
// pdfjs.GlobalWorkerOptions.workerSrc = workerSrc;

// Define an interface for the object passed to onDocumentLoadSuccess for clarity
interface PdfLoadSuccessParams {
  numPages: number;
}

/**
 * A React component to display a PDF document with pagination controls.
 */
function PdfViewer() {
  // State to store the total number of pages in the PDF
  const [numPages, setNumPages] = useState<number | null>(1); // Added type annotation
  // State for the currently displayed page number (1-based index)
  const [pageNumber, setPageNumber] = useState<number>(1); // Added type annotation
  // State to track if the PDF document is loading
  const [isLoading, setIsLoading] = useState<boolean>(true); // Added type annotation
  // State to store any error that occurs during loading
  const [pdfError, setPdfError] = useState<string | null>(null); // Added type annotation

  // --- PDF File Source ---
  // Replace this URL with the path to your PDF file.
  // It can be a public URL, a local path (if your bundler is configured),
  // a File object (from an input), or a base64 string.
  const pdfFileUrl: string = 'https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf'; // Added type annotation
  // Example using a local file (requires setup like webpack file-loader or Vite asset handling):
  // import myPdf from './assets/myDocument.pdf';
  // const pdfFileUrl = myPdf;

  /**
   * Callback function executed when the PDF document is successfully loaded.
   * @param {PdfLoadSuccessParams} pdf - The loaded PDF document proxy containing numPages.
   */
  // Added type annotation { numPages: number } to the destructured parameter
  const onDocumentLoadSuccess = useCallback(({ numPages: nextNumPages }: PdfLoadSuccessParams) => {
    setNumPages(nextNumPages);
    setIsLoading(false);
    setPdfError(null); // Clear any previous errors
    // Reset to page 1 or ensure current page number is valid if a new PDF is loaded
    setPageNumber(prevPageNumber => Math.min(prevPageNumber, nextNumPages) || 1);
    console.log(`PDF loaded successfully with ${nextNumPages} pages.`);
  }, []); // Empty dependency array means this callback is created once

  /**
   * Callback function executed if an error occurs while loading the document.
   * @param {Error} error - The error object.
   */
  // Added type annotation Error to the error parameter
  const onDocumentLoadError = useCallback((error: Error) => {
    console.error('Error while loading PDF:', error);
    setPdfError(`Failed to load PDF file. ${error.message}`);
    setIsLoading(false); // Stop loading indicator even if there's an error
    setNumPages(null); // Reset page count on error
  }, []); // Empty dependency array

  /**
   * Navigates to the previous page, ensuring it doesn't go below page 1.
   */
  const goToPrevPage = () => {
    // Ensure numPages is not null before calculating the next page
    if (numPages === null) return;
    setPageNumber(prevPageNumber => Math.max(prevPageNumber - 1, 1));
  };

  /**
   * Navigates to the next page, ensuring it doesn't exceed the total number of pages.
   */
  const goToNextPage = () => {
    // Ensure numPages is not null before calculating the next page
    if (numPages === null) return;
    setPageNumber(prevPageNumber => Math.min(prevPageNumber + 1, numPages));
  };

  // --- Component Rendering ---
  return (
    <div style={{ fontFamily: 'sans-serif', textAlign: 'center', padding: '20px' }}>
      {/* <h2>React PDF Viewer</h2> */}

      {/* Display Loading Message */}
      {isLoading && <p>Loading PDF document...</p>}
      <Document file={pdfFileUrl} onLoadSuccess={onDocumentLoadSuccess}>
        <Page pageNumber={pageNumber} />
      </Document>

      {/* Display Error Message */}
      {pdfError && <p style={{ color: 'red' }}>Error: {pdfError}</p>}

      {/* Render the PDF Document only if not loading and no error */}
      {!isLoading && !pdfError && pdfFileUrl && numPages !== null && ( // Check numPages is not null
        <>
          {/* Pagination Controls */}
          <div style={{ margin: '10px 0' }}>
            <button
              onClick={goToPrevPage}
              disabled={pageNumber <= 1}
              style={{ marginRight: '10px', padding: '5px 10px' }}
            >
              Previous
            </button>
            <span>
              Page {pageNumber} of {numPages}
            </span>
            <button
              onClick={goToNextPage}
              disabled={pageNumber >= numPages} // numPages is guaranteed non-null here
              style={{ marginLeft: '10px', padding: '5px 10px' }}
            >
              Next
            </button>
          </div>

          {/* PDF Document Container */}
          {/* We add a container div to control styling like border and max-width */}
          <div style={{ border: '1px solid #ccc', maxWidth: '800px', margin: '20px auto', overflow: 'hidden' }}>
            <Document
              file={pdfFileUrl} // The source of the PDF
              onLoadSuccess={onDocumentLoadSuccess}
              onLoadError={onDocumentLoadError}
              // You can provide options to PDF.js here if needed
              // options={{ cMapUrl: `//cdn.jsdelivr.net/npm/pdfjs-dist@${pdfjs.version}/cmaps/`, cMapPacked: true }}

              // Optional: Display a loading indicator specifically for the Document component
              loading={<p>Please wait, loading PDF...</p>}
              // Optional: Display an error message specifically for the Document component
              error={<p>Error loading document content.</p>}
              // Optional: Add a class name for styling
              // className="pdf-document-container"
            >
              {/* Render the specific page */}
              <Page
                pageNumber={pageNumber} // Which page to display
                // Optional: Control the rendered width of the page
                // width={600}
                // Optional: Control the scale
                // scale={1.5}

                // Optional: Display loading/error messages specific to the Page component
                loading={<p>Loading page {pageNumber}...</p>}
                error={<p>Error loading page {pageNumber}.</p>}

                // Optional: Disable text layer (improves performance but prevents text selection)
                // renderTextLayer={false}

                // Optional: Disable annotation layer (prevents interaction with links etc.)
                // renderAnnotationLayer={false}

                // Optional: Add a class name for styling
                // className="pdf-page"
              />
            </Document>
          </div>

          {/* Repeat Pagination Controls at the bottom for convenience */}
          <div style={{ margin: '10px 0' }}>
            <button
              onClick={goToPrevPage}
              disabled={pageNumber <= 1}
              style={{ marginRight: '10px', padding: '5px 10px' }}
            >
              Previous
            </button>
            <span>
              Page {pageNumber} of {numPages}
            </span>
            <button
              onClick={goToNextPage}
              disabled={pageNumber >= numPages} // numPages is guaranteed non-null here
              style={{ marginLeft: '10px', padding: '5px 10px' }}
            >
              Next
            </button>
          </div>
        </>
      )}
    </div>
  );
}

// Export the component for use in other parts of your application
export default PdfViewer;
