// MyPdfBlobViewerComponent.tsx
// This React component demonstrates fetching a PDF as a Blob, downloading it to device storage,
// and opening it using the Cordova InAppBrowser plugin.

import React, { useEffect, useState } from 'react';

// --- Type Definitions for Cordova Plugins ---

// InAppBrowser Types
interface InAppBrowserAPI { addEventListener: (eventname: 'loadstart' | 'loadstop' | 'loaderror' | 'exit', callback: (event: InAppBrowserEvent) => void) => void; removeEventListener: (eventname: 'loadstart' | 'loadstop' | 'loaderror' | 'exit', callback: (event: InAppBrowserEvent) => void) => void; close: () => void; show: () => void; executeScript: (script: { code: string } | { file: string }, callback?: (result: any[]) => void) => void; insertCSS: (css: { code: string } | { file: string }, callback?: () => void) => void; }
interface InAppBrowserEvent { type: string; url: string; code?: number; message?: string; }

// cordova-plugin-file Types
interface FileSystem { root: DirectoryEntry; name: string; }
interface Entry { isFile: boolean; isDirectory: boolean; name: string; fullPath: string; filesystem: FileSystem; nativeURL: string; getParent(successCallback: (entry: DirectoryEntry) => void, errorCallback?: (error: FileError) => void): void; }
interface FileEntry extends Entry { file(successCallback: (file: File) => void, errorCallback?: (error: FileError) => void): void; createWriter(successCallback: (writer: FileWriter) => void, errorCallback?: (error: FileError) => void): void; }
interface DirectoryEntry extends Entry { getFile(path: string, options?: { create?: boolean; exclusive?: boolean; }, successCallback?: (entry: FileEntry) => void, errorCallback?: (error: FileError) => void): void; getDirectory(path: string, options?: { create?: boolean; exclusive?: boolean; }, successCallback?: (entry: DirectoryEntry) => void, errorCallback?: (error: FileError) => void): void; createReader(): DirectoryReader; }
interface DirectoryReader { readEntries(successCallback: (entries: Entry[]) => void, errorCallback?: (error: FileError) => void): void; }
interface FileError { code: number; message?: string; }
declare var FileError: { NOT_FOUND_ERR: number; SECURITY_ERR: number; ABORT_ERR: number; NOT_READABLE_ERR: number; ENCODING_ERR: number; NO_MODIFICATION_ALLOWED_ERR: number; INVALID_STATE_ERR: number; SYNTAX_ERR: number; INVALID_MODIFICATION_ERR: number; QUOTA_EXCEEDED_ERR: number; TYPE_MISMATCH_ERR: number; PATH_EXISTS_ERR: number; };
interface FileWriter { readyState: number; fileName: string; length: number; position: number; error: FileError | null; onwritestart: ((event: ProgressEvent) => void) | null; onprogress: ((event: ProgressEvent) => void) | null; onwrite: ((event: ProgressEvent) => void) | null; onwriteend: ((event: ProgressEvent) => void) | null; onerror: ((event: ProgressEvent) => void) | null; onabort: ((event: ProgressEvent) => void) | null; write(data: Blob | string | ArrayBuffer): void; seek(offset: number): void; truncate(size: number): void; abort(): void; }

// Define interfaces for the shapes of specific cordova plugin properties
interface CordovaFilePlugin {
  applicationDirectory: string; applicationStorageDirectory: string; dataDirectory: string; cacheDirectory: string;
  externalApplicationStorageDirectory: string; externalDataDirectory: string; externalCacheDirectory: string; externalRootDirectory: string | null;
  tempDirectory: string; syncedDataDirectory: string; documentsDirectory: string; sharedDirectory: string;
}

interface CordovaPermissionsPlugin {
  checkPermission(permission: string, successCallback: (status: { hasPermission: boolean }) => void, errorCallback?: (err: any) => void): void;
  requestPermission(permission: string, successCallback: (status: { hasPermission: boolean }) => void, errorCallback?: (err: any) => void): void;
  requestPermissions(permissions: string[], successCallback: (status: { hasPermission: boolean }) => void, errorCallback?: (err: any) => void): void;
  WRITE_EXTERNAL_STORAGE: string;
}

interface CordovaPlugins {
    permissions?: CordovaPermissionsPlugin;
    // Other plugins could be nested here
}


// Extend the global Window interface
declare global {
  // This is the central 'Cordova' interface.
  // If other .d.ts files also declare 'interface Cordova', TypeScript will merge them.
  interface Cordova {
    InAppBrowser?: { open: (url: string, target: '_blank' | '_system' | '_self', options?: string) => InAppBrowserAPI | null; };
    platformId?: string;
    file?: CordovaFilePlugin;
    plugins?: CordovaPlugins;
  }

  interface Window {
    cordova?: Cordova; // Window.cordova is now typed using the mergeable 'Cordova' interface

    resolveLocalFileSystemURL(url: string, successCallback: (entry: Entry) => void, errorCallback?: (error: FileError) => void): void;
    requestFileSystem?(type: number, size: number, successCallback: (filesystem: FileSystem) => void, errorCallback?: (error: FileError) => void): void;
    LocalFileSystem?: { PERSISTENT: number; TEMPORARY: number; };
  }
}

const MyPdfBlobViewerComponent: React.FC = () => {
  const [message, setMessage] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    const onDeviceReady = (): void => {
      console.log('Cordova device is ready. Plugins can be used.');
      setMessage('Device is ready. You can interact with files and plugins.');
      if (!window.cordova || (!window.cordova.InAppBrowser && !window.cordova.file)) {
          console.warn("One or more Cordova plugins (InAppBrowser, File) might be missing.");
          setMessage('Warning: Some features might not work if plugins are missing.');
      }
      // Ensure permission constant is available if permissions plugin is used
      if (window.cordova && window.cordova.plugins && window.cordova.plugins.permissions && !window.cordova.plugins.permissions.WRITE_EXTERNAL_STORAGE) {
        // This assignment might be problematic if the interface is strictly defined.
        // It's better if the plugin itself makes this constant available on its defined type.
        // For now, we'll assume it's dynamically added or already part of a merged type.
        // (window.cordova.plugins.permissions as any).WRITE_EXTERNAL_STORAGE = 'android.permission.WRITE_EXTERNAL_STORAGE';
      }
    };

    document.addEventListener('deviceready', onDeviceReady, false);
    return () => {
      document.removeEventListener('deviceready', onDeviceReady, false);
    };
  }, []);

  const fetchPdfAsBlob = async (pdfUrl: string): Promise<Blob | null> => { setIsLoading(true);setMessage(`Fetching PDF from ${pdfUrl}...`);try {const response = await fetch(pdfUrl);if (!response.ok) {throw new Error(`HTTP error! status: ${response.status} for ${pdfUrl}`);}const blob = await response.blob();setMessage('PDF fetched successfully as Blob.');return blob;} catch (error) {console.error('Failed to fetch PDF as Blob:', error);setMessage(`Error fetching PDF: ${error instanceof Error ? error.message : String(error)}`);return null;} finally {setIsLoading(false);} };

  const openPdfInAppBrowser = async (pdfUrl: string): Promise<void> => {
    const blob = await fetchPdfAsBlob(pdfUrl);
    if (!blob) return;

    setMessage(`Opening PDF with InAppBrowser (using blob:URL)...`);
    if (window.cordova && window.cordova.InAppBrowser) {
      const objectURL = URL.createObjectURL(blob);
      console.log('Created blob:URL:', objectURL);

      const target: '_blank' | '_system' | '_self' = '_blank';
      const options: string = 'location=yes,hidden=no,toolbar=yes,closebuttoncaption=✕,clearcache=no,clearsessioncache=no';

      const InAppBrowser = window.cordova.InAppBrowser; // Safe due to check above
      const iabRef: InAppBrowserAPI | null = InAppBrowser.open(objectURL, target, options);

      if (iabRef) {
        setMessage(`InAppBrowser opening ${objectURL}...`);
        const onLoadStart = (event: InAppBrowserEvent): void => {
          console.log(`IAB event: loadstart - URL: ${event.url}`);
          setMessage(`IAB Loading: ${event.url}`);
        };
        const onLoadStop = (event: InAppBrowserEvent): void => {
          console.log(`IAB event: loadstop - URL: ${event.url}`);
          setMessage(`IAB Finished loading: ${event.url}`);
        };
        const onLoadError = (event: InAppBrowserEvent): void => {
          console.error(`IAB event: loaderror - URL: ${event.url}, Message: ${event.message}, Code: ${event.code}`);
          setMessage(`IAB Error loading ${event.url}: ${event.message || 'Unknown error'}`);
          iabRef.close();
        };
        const onExit = (): void => {
          console.log('IAB event: exit. Revoking blob:URL:', objectURL);
          setMessage('InAppBrowser closed.');
          URL.revokeObjectURL(objectURL);
          iabRef.removeEventListener('loadstart', onLoadStart);
          iabRef.removeEventListener('loadstop', onLoadStop);
          iabRef.removeEventListener('loaderror', onLoadError);
          iabRef.removeEventListener('exit', onExit);
        };
        iabRef.addEventListener('loadstart', onLoadStart);
        iabRef.addEventListener('loadstop', onLoadStop);
        iabRef.addEventListener('loaderror', onLoadError);
        iabRef.addEventListener('exit', onExit);
      } else {
        console.error('Failed to open InAppBrowser. The reference is null.');
        setMessage('Error: Could not open InAppBrowser.');
        URL.revokeObjectURL(objectURL);
      }
    } else {
      console.warn('Cordova InAppBrowser plugin not found.');
      setMessage('InAppBrowser plugin not available. Opening original URL as fallback.');
      window.open(pdfUrl, '_blank');
    }
  };


  const downloadAndSavePdf = async (pdfUrl: string): Promise<void> => {
    if (!window.cordova || !window.cordova.file || !window.resolveLocalFileSystemURL) {
      setMessage('File plugin not available. Download feature disabled.');
      console.error('Cordova File plugin is required for download.');
      return;
    }

    const blob = await fetchPdfAsBlob(pdfUrl);
    if (!blob) {
      setMessage('Failed to fetch PDF, download cancelled.');
      return;
    }

    const fileName = pdfUrl.substring(pdfUrl.lastIndexOf('/') + 1) || 'downloaded.pdf';
    setMessage(`Preparing to save ${fileName}...`);

    const saveFile = (dirPath: string) => {
      if (!dirPath) {
        setMessage('Target directory path is invalid. Cannot save file.');
        console.error('Target directory path is empty or undefined.');
        return;
      }
      window.resolveLocalFileSystemURL(dirPath,
        (dirEntry) => {
          const directoryEntry = dirEntry as DirectoryEntry;
          directoryEntry.getFile(fileName, { create: true, exclusive: false },
            (fileEntry) => {
              fileEntry.createWriter(
                (fileWriter) => {
                  fileWriter.onwriteend = () => {
                    setMessage(`PDF "${fileName}" saved successfully to ${fileEntry.nativeURL || fileEntry.fullPath}.`);
                    console.log('File saved:', fileEntry.nativeURL || fileEntry.fullPath);
                  };
                  fileWriter.onerror = (e) => {
                    setMessage(`Failed to write PDF: ${e.toString()}`);
                    console.error('FileWriter error:', e);
                  };
                  fileWriter.write(blob);
                },
                (err) => {
                  setMessage(`Failed to create FileWriter: ${err.code}`);
                  console.error('Create FileWriter error:', err);
                }
              );
            },
            (err) => {
              setMessage(`Failed to get FileEntry: ${err.code}`);
              console.error('Get FileEntry error:', err);
            }
          );
        },
        (err) => {
          setMessage(`Failed to resolve directory ${dirPath}: ${err.code}`);
          console.error('Resolve directory error:', err);
        }
      );
    };

    const cordovaInstance = window.cordova; // For easier access and type safety
    if (cordovaInstance.platformId === 'android') {
      const permissions = cordovaInstance.plugins?.permissions;
      const filePlugin = cordovaInstance.file;

      if (permissions && filePlugin?.externalRootDirectory) {
        // Ensure WRITE_EXTERNAL_STORAGE is defined on permissions object before use
        const permissionType = permissions.WRITE_EXTERNAL_STORAGE || 'android.permission.WRITE_EXTERNAL_STORAGE';

        permissions.checkPermission(permissionType, (status) => {
          if (status.hasPermission) {
            saveFile(filePlugin.externalRootDirectory + 'Download/');
          } else {
            permissions.requestPermission(permissionType, (requestStatus) => {
              if (requestStatus.hasPermission) {
                saveFile(filePlugin.externalRootDirectory + 'Download/');
              } else {
                setMessage('Write permission denied. Saving to app-specific directory.');
                console.warn('Write permission denied for external storage.');
                saveFile(filePlugin.externalDataDirectory || filePlugin.dataDirectory || '');
              }
            }, (err) => {
              setMessage('Error requesting permission. Saving to app-specific directory.');
              console.error('Permission request error:', err);
              saveFile(filePlugin.externalDataDirectory || filePlugin.dataDirectory || '');
            });
          }
        }, (err) => {
          setMessage('Error checking permission. Saving to app-specific directory.');
          console.error('Permission check error:', err);
          saveFile(filePlugin.externalDataDirectory || filePlugin.dataDirectory || '');
        });
      } else {
        setMessage('External storage/permissions plugin not fully available. Saving to app-specific directory.');
        saveFile(filePlugin?.externalDataDirectory || filePlugin?.dataDirectory || '');
      }
    } else if (cordovaInstance.platformId === 'ios') {
      const filePlugin = cordovaInstance.file;
      if (filePlugin?.documentsDirectory) {
        saveFile(filePlugin.documentsDirectory);
      } else {
         setMessage('iOS documents directory not found. Cannot save.');
         console.error('iOS documentsDirectory is not available.');
      }
    } else {
      setMessage('Unsupported platform for Downloads folder. Saving to app-specific data directory.');
      const filePlugin = cordovaInstance.file;
      saveFile(filePlugin?.dataDirectory || '');
    }
  };

  const samplePdfUrl: string = 'https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf';

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif', textAlign: 'center' }}>
      <h2 style={{ color: '#333' }}>Cordova PDF Viewer (TSX) - Blob & Download</h2>
      <p style={{ color: '#555', minHeight: '40px', border: '1px solid #eee', padding: '10px', background: '#f9f9f9', margin: '10px 0' }}>
        Status: {isLoading ? 'Loading...' : message || 'Waiting for action...'}
      </p>
      <button onClick={() => openPdfInAppBrowser(samplePdfUrl)} disabled={isLoading} style={{ backgroundColor: isLoading? '#ccc' : '#007bff', color: 'white', padding: '12px 20px', border: 'none', borderRadius: '5px', fontSize: '16px', cursor: isLoading? 'default' : 'pointer', margin: '5px' }}>
        Open PDF (InAppBrowser)
      </button>
      <button onClick={() => downloadAndSavePdf(samplePdfUrl)} disabled={isLoading} style={{ backgroundColor: isLoading? '#ccc' : '#ffc107', color: 'black', padding: '12px 20px', border: 'none', borderRadius: '5px', fontSize: '16px', cursor: isLoading? 'default' : 'pointer', margin: '5px' }}>
        Download PDF
      </button>
      <div style={{ marginTop: '20px', fontSize: '12px', color: '#777' }}>
        <p><strong>Instructions & Notes:</strong></p>
        <ul style={{ textAlign: 'left', display: 'inline-block', listStylePosition: 'inside' }}>
          <li>Ensure Cordova plugins are installed (`inappbrowser`, `file`, `android-permissions`).</li>
          <li>Download attempts to save to "Downloads" on Android (requires permission) or "Documents" on iOS.</li>
          <li>InAppBrowser attempts to use a `blob:URL`. Remember to revoke it!</li>
        </ul>
      </div>
    </div>
  );
};

export default MyPdfBlobViewerComponent;
