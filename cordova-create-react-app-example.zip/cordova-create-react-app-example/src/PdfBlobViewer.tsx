import React, { useState, useEffect, useCallback } from 'react';
// Import core components and pdfjs interaction from react-pdf
import { Document, Page, pdfjs } from 'react-pdf';
// --- Import CSS for react-pdf layers ---
import 'react-pdf/dist/Page/AnnotationLayer.css';
import 'react-pdf/dist/Page/TextLayer.css';
// Import type for LoadSuccessParams if using TypeScript and @types/react-pdf (optional but good practice)
// Note: @types/react-pdf might not exist or be up-to-date. Defining the type inline is often sufficient.
// import type { DocumentLoadSuccessParams } from 'react-pdf/dist/cjs/shared/types'; // Example path, might vary

// --- Worker Setup ---
// Ensure this points to the correct worker file location for your setup
// Using the local copy method which worked for Cordova:
pdfjs.GlobalWorkerOptions.workerSrc = '/pdf.worker.js'; // Ensure pdf.worker.js is in your public/www folder

// Define an interface for the object passed to onDocumentLoadSuccess for clarity
interface PdfLoadSuccessParams {
  numPages: number;
}

// --- Mock API Fetch Function ---
// Replace this with your actual API call logic.
// This function simulates fetching PDF data as a Blob.
const fetchPdfDataAsBlob = (): Promise<Blob> => {
  console.log('Simulating API call to fetch PDF data as Blob...');
  // In a real app, use fetch:
  // return fetch('/api/get-my-pdf') // Your API endpoint
  //   .then(response => {
  //     if (!response.ok) {
  //       throw new Error(`API Error: ${response.statusText}`);
  //     }
  //     return response.blob(); // Get response body as Blob
  //   });

  // --- Simulation Start ---
  // Using a known public PDF URL to fetch its data for simulation purposes.
  // Replace this entire simulation block with your actual fetch call above.
  const pdfUrl = 'https://pdfobject.com/pdf/sample.pdf';
  //'https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf';
  return new Promise((resolve, reject) => {
    fetch(pdfUrl)
      .then(response => {
        if (!response.ok) {
          throw new Error(`Simulation fetch Error: ${response.statusText}`);
        }
        return response.blob(); // <<< CHANGE: Fetch as Blob
      })
      .then(blobData => {
        console.log('Simulated API call successful, received Blob.');
        resolve(blobData);
      })
      .catch(error => {
        console.error('Simulated API call failed:', error);
        reject(error);
      });
  });
  // --- Simulation End ---
};


/**
 * A React component to display a PDF document loaded from binary data (e.g., API response as Blob).
 */
function PdfViewer() {
  // State for the binary PDF data (Blob)
  const [pdfData, setPdfData] = useState<Blob | null>(null); // <<< CHANGE: State holds Blob
  // State to track if the API data is being fetched
  const [isFetching, setIsFetching] = useState<boolean>(true);
  // State to store any error during the API fetch
  const [fetchError, setFetchError] = useState<string | null>(null);

  // State to store the total number of pages in the PDF
  const [numPages, setNumPages] = useState<number | null>(null);
  // State for the currently displayed page number (1-based index)
  const [pageNumber, setPageNumber] = useState<number>(1);
  // State to track if the PDF document itself is loading/rendering (after fetch)
  const [isRendering, setIsRendering] = useState<boolean>(false); // Initially false until data is fetched
  // State to store any error during PDF rendering
  const [renderError, setRenderError] = useState<string | null>(null);


  // Effect to fetch the PDF data when the component mounts
  useEffect(() => {
    setIsFetching(true);
    setFetchError(null);
    setPdfData(null); // Clear previous data
    setNumPages(null); // Reset pages
    setPageNumber(1); // Reset page number

    fetchPdfDataAsBlob() // <<< CHANGE: Call the Blob fetching function
      .then((data) => {
        setPdfData(data);
        setFetchError(null);
      })
      .catch((error) => {
        console.error("Error fetching PDF data:", error);
        setFetchError(error.message || "Failed to fetch PDF data from API.");
        setPdfData(null);
      })
      .finally(() => {
        setIsFetching(false);
      });
  }, []); // Empty dependency array ensures this runs only once on mount


  /**
   * Callback function executed when the PDF document is successfully loaded by react-pdf.
   * @param {PdfLoadSuccessParams} pdf - The loaded PDF document proxy containing numPages.
   */
  const onDocumentLoadSuccess = useCallback(({ numPages: nextNumPages }: PdfLoadSuccessParams) => {
    setNumPages(nextNumPages);
    setIsRendering(false); // PDF rendering successful
    setRenderError(null); // Clear any previous rendering errors
    setPageNumber(prevPageNumber => Math.min(prevPageNumber, nextNumPages) || 1);
    console.log(`PDF document processed successfully with ${nextNumPages} pages.`);
  }, []);

  /**
   * Callback function executed if an error occurs while loading/rendering the document by react-pdf.
   * @param {Error} error - The error object.
   */
  const onDocumentLoadError = useCallback((error: Error) => {
    console.error('Error while processing PDF by react-pdf:', error);
    // Distinguish between fetch error and rendering error
    if (!fetchError) { // Only set render error if fetch was successful
       setRenderError(`Failed to process PDF data. ${error.message}. Is the data corrupted or invalid?`);
    }
    setIsRendering(false); // Stop rendering indicator even if there's an error
    setNumPages(null); // Reset page count on error
  }, [fetchError]); // Depend on fetchError to avoid overwriting it

  /**
   * Callback triggered when the Document component starts loading the data.
   */
  const onDocumentLoadProgress = useCallback(({ loaded, total }: { loaded: number, total: number }) => {
      // Note: Progress events might behave differently with Blobs vs ArrayBuffers
      console.log(`Loading document... ${loaded}/${total}`);
      setIsRendering(true); // Indicate that rendering/processing has started
  }, []);


  /**
   * Navigates to the previous page.
   */
  const goToPrevPage = () => {
    if (numPages === null) return;
    setPageNumber(prevPageNumber => Math.max(prevPageNumber - 1, 1));
  };

  /**
   * Navigates to the next page.
   */
  const goToNextPage = () => {
    if (numPages === null) return;
    setPageNumber(prevPageNumber => Math.min(prevPageNumber + 1, numPages));
  };

  // --- Component Rendering ---
  return (
    <div style={{ fontFamily: 'sans-serif', textAlign: 'center', padding: '20px' }}>
      <h2>React PDF Viewer (from API Data as Blob)</h2>

      {/* Display Fetching Message */}
      {isFetching && <p>Fetching PDF data from API...</p>}

      {/* Display Fetch Error Message */}
      {fetchError && <p style={{ color: 'red' }}>API Error: {fetchError}</p>}

      {/* Display Rendering Message */}
      {pdfData && isRendering && !renderError && <p>Processing PDF data...</p>}

      {/* Display Rendering Error Message */}
      {renderError && <p style={{ color: 'red' }}>PDF Render Error: {renderError}</p>}

      {/* Render the PDF Document only if fetching succeeded and data exists */}
      {!isFetching && !fetchError && pdfData && (
        <>
          {/* Pagination Controls - Show only if rendering is complete and successful */}
          {!isRendering && !renderError && numPages !== null && (
            <div style={{ margin: '10px 0' }}>
              <button
                onClick={goToPrevPage}
                disabled={pageNumber <= 1}
                style={{ marginRight: '10px', padding: '5px 10px' }}
              >
                Previous
              </button>
              <span>
                Page {pageNumber} of {numPages}
              </span>
              <button
                onClick={goToNextPage}
                disabled={pageNumber >= numPages}
                style={{ marginLeft: '10px', padding: '5px 10px' }}
              >
                Next
              </button>
            </div>
          )}

          {/* PDF Document Container */}
          <div style={{ border: '1px solid #ccc', maxWidth: '800px', margin: '20px auto', overflow: 'hidden' }}>
            <Document
              // Pass the Blob directly to the file prop.
              // No need to copy a Blob like an ArrayBuffer.
              file={pdfData} // <<< CHANGE IS HERE
              onLoadSuccess={onDocumentLoadSuccess}
              onLoadError={onDocumentLoadError}
              onLoadProgress={onDocumentLoadProgress} // Optional: track loading progress
              loading={<p>Preparing PDF document...</p>} // Shown while Document component initializes
              error={<p>Error preparing document content.</p>} // Should ideally be caught by onLoadError
              // Add a key based on the Blob size as a simple way to force re-mount if data changes
              key={pdfData.size}
            >
              {/* Render the specific page only if rendering hasn't failed */}
              {!renderError && numPages !== null && (
                 <Page
                    key={`page_${pageNumber}`} // Add key for potential performance benefits on page change
                    pageNumber={pageNumber}
                    loading={<p>Loading page {pageNumber}...</p>}
                    error={<p>Error loading page {pageNumber}.</p>}
                 />
              )}
            </Document>
          </div>

           {/* Repeat Pagination Controls - Show only if rendering is complete and successful */}
           {!isRendering && !renderError && numPages !== null && (
            <div style={{ margin: '10px 0' }}>
              <button
                onClick={goToPrevPage}
                disabled={pageNumber <= 1}
                style={{ marginRight: '10px', padding: '5px 10px' }}
              >
                Previous
              </button>
              <span>
                Page {pageNumber} of {numPages}
              </span>
              <button
                onClick={goToNextPage}
                disabled={pageNumber >= numPages}
                style={{ marginLeft: '10px', padding: '5px 10px' }}
              >
                Next
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// Export the component for use in other parts of your application
export default PdfViewer;
