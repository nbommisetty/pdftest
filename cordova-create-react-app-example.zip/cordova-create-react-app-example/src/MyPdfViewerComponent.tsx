// MyPdfViewerComponent.tsx
// This React component demonstrates how to open a PDF URL
// using either the Cordova InAppBrowser plugin or the SafariViewController plugin,
// written in TypeScript.

import React, { useEffect, useState } from 'react';

// --- Type Definitions for Cordova Plugins ---

// InAppBrowser Types
interface InAppBrowserAPI {
  addEventListener: (
    eventname: 'loadstart' | 'loadstop' | 'loaderror' | 'exit',
    callback: (event: InAppBrowserEvent) => void
  ) => void;
  removeEventListener: (
    eventname: 'loadstart' | 'loadstop' | 'loaderror' | 'exit',
    callback: (event: InAppBrowserEvent) => void
  ) => void;
  close: () => void;
  show: () => void;
  executeScript: (
    script: { code: string } | { file: string },
    callback?: (result: any[]) => void
  ) => void;
  insertCSS: (
    css: { code: string } | { file: string },
    callback?: () => void
  ) => void;
}

interface InAppBrowserEvent {
  type: string;
  url: string;
  code?: number;
  message?: string;
}

// SafariViewController Types
interface SafariViewControllerAPI {
  isAvailable: (callback: (available: boolean) => void) => void;
  show: (
    options: SafariViewControllerShowOptions,
    onSuccess?: (result: { event: 'opened' | 'loaded' | 'closed' }) => void,
    onError?: (error: { error: string }) => void // Note: error structure might vary slightly by plugin version
  ) => void;
  hide: (
    onSuccess?: () => void,
    onError?: (error: string) => void
  ) => void;
  // Add other methods if you plan to use them, e.g., connect, warmUp
}

interface SafariViewControllerShowOptions {
  url: string;
  hidden?: boolean; // default false
  animated?: boolean; // default true
  transition?: 'curl' | 'fade' | 'flip' | 'slide'; // (iOS only)
  enterReaderModeIfAvailable?: boolean; // (iOS only)
  tintColor?: string; // (iOS only) hex color #RRGGBB
  barColor?: string; // (iOS 10+ only) hex color #RRGGBB
  controlTintColor?: string; // (iOS 10+ only) hex color #RRGGBB
}


// Extend the global Window interface to include Cordova properties
declare global {
  interface Window {
    // cordova?: {
    //   InAppBrowser?: {
    //     open: (
    //       url: string,
    //       target: '_blank' | '_system' | '_self',
    //       options?: string
    //     ) => InAppBrowserAPI | null;
    //   };
    //   platformId?: string;
    // };
    SafariViewController?: SafariViewControllerAPI; // Added SafariViewController
  }
}

const MyPdfViewerComponent: React.FC = () => {
  const [message, setMessage] = useState<string>('');

  useEffect(() => {
    const onDeviceReady = (): void => {
      console.log('Cordova device is ready. Plugins can be used.');
      setMessage('Device is ready. You can open a PDF.');
      if (!window.cordova || (!window.cordova.InAppBrowser && !window.SafariViewController)) {
          console.warn("Neither InAppBrowser nor SafariViewController plugin seems to be available.");
          setMessage('Warning: PDF viewer plugins might not be installed.');
      }
    };

    document.addEventListener('deviceready', onDeviceReady, false);
    return () => {
      document.removeEventListener('deviceready', onDeviceReady, false);
    };
  }, []);

  /**
   * Opens the given PDF URL in the InAppBrowser.
   * @param {string} pdfUrl - The URL of the PDF to open.
   */
  const openPdfInAppBrowser = (pdfUrl: string): void => {
    setMessage(`Attempting to open PDF with InAppBrowser: ${pdfUrl}`);
    // Ensure the Cordova InAppBrowser plugin object is available on the window.
    // This check is crucial as Cordova plugins are injected at runtime.
    if (window.cordova && window.cordova.InAppBrowser) {
      const target: '_blank' | '_system' | '_self' = '_blank';
      const options: string = 'location=yes,hidden=no,toolbar=yes,clearcache=yes,clearsessioncache=yes';
      let urlToOpen: string = pdfUrl;

      if (window.cordova.platformId === 'android') {
        // urlToOpen = `https://docs.google.com/gview?embedded=true&url=${encodeURIComponent(pdfUrl)}`;
        console.log('Android platform: InAppBrowser. Consider Google Docs Viewer if direct PDF viewing fails.');
      }

      // Assign to a local variable for clarity and potentially better type inference within this scope.
      const InAppBrowser = window.cordova.InAppBrowser;
      const iabRef: InAppBrowserAPI | null = InAppBrowser.open(urlToOpen, target, options);

      if (iabRef) {
        setMessage(`InAppBrowser opening ${urlToOpen}...`);
        const onLoadStart = (event: InAppBrowserEvent): void => {
          console.log(`IAB event: loadstart - URL: ${event.url}`);
          setMessage(`IAB Loading: ${event.url}`);
        };
        const onLoadStop = (event: InAppBrowserEvent): void => {
          console.log(`IAB event: loadstop - URL: ${event.url}`);
          setMessage(`IAB Finished loading: ${event.url}`);
        };
        const onLoadError = (event: InAppBrowserEvent): void => {
          console.error(`IAB event: loaderror - URL: ${event.url}, Message: ${event.message}, Code: ${event.code}`);
          setMessage(`IAB Error loading ${event.url}: ${event.message || 'Unknown error'}`);
          iabRef.close();
        };
        const onExit = (): void => {
          console.log('IAB event: exit');
          setMessage('InAppBrowser closed.');
          iabRef.removeEventListener('loadstart', onLoadStart);
          iabRef.removeEventListener('loadstop', onLoadStop);
          iabRef.removeEventListener('loaderror', onLoadError);
          iabRef.removeEventListener('exit', onExit);
        };
        iabRef.addEventListener('loadstart', onLoadStart);
        iabRef.addEventListener('loadstop', onLoadStop);
        iabRef.addEventListener('loaderror', onLoadError);
        iabRef.addEventListener('exit', onExit);
      } else {
        console.error('Failed to open InAppBrowser. The reference is null.');
        setMessage('Error: Could not open InAppBrowser.');
      }
    } else {
      console.warn('Cordova InAppBrowser plugin not found. Ensure it is installed and deviceready has fired.');
      setMessage('InAppBrowser plugin not available.');
      window.open(pdfUrl, '_blank'); // Fallback for browsers
    }
  };

  /**
   * Opens the given PDF URL using SafariViewController.
   * @param {string} pdfUrl - The URL of the PDF to open.
   */
  const openPdfInSafariView = (pdfUrl: string): void => {
    setMessage(`Attempting to open PDF with SafariViewController: ${pdfUrl}`);

    // Capture the SafariViewController plugin object from the window.
    // This helps TypeScript understand that 'safariVC' is of type 'SafariViewControllerAPI | undefined'.
    const safariVC = window.SafariViewController;

    // Check if the plugin object exists on the window. This is the type guard.
    if (safariVC) {
      // Inside this block, TypeScript knows 'safariVC' is of type 'SafariViewControllerAPI'.
      safariVC.isAvailable((available: boolean) => {
        if (available) {
          const options: SafariViewControllerShowOptions = {
            url: pdfUrl,
            animated: true,
            // tintColor: "#007bff", // Example: blue tint for controls on iOS
            // barColor: "#ffffff", // Example: white bar color on iOS 10+
            // controlTintColor: "#007bff" // Example: blue control tint on iOS 10+
            // enterReaderModeIfAvailable: true // For articles, not typically for PDFs
          };

          // Note: SafariViewController is generally better for web content than raw PDFs.
          // Direct PDF viewing experience might vary.
          // On Android, this plugin uses Chrome Custom Tabs.
          safariVC.show(options,
            (result?: { event: 'opened' | 'loaded' | 'closed' }) => {
              if (result) {
                console.log(`SafariVC event: ${result.event}`);
                setMessage(`SafariVC event: ${result.event}`);
              }
            },
            (error?: { error: string }) => { // Error object structure can vary
              console.error('SafariVC error:', error);
              setMessage(`SafariVC Error: ${error ? error.error : 'Unknown error'}`);
              // Fallback if SafariVC fails to show for some reason
              // openPdfInAppBrowser(pdfUrl); // Or show an error message
            }
          );
        } else {
          console.warn('SafariViewController/Chrome Custom Tabs not available on this device.');
          setMessage('SafariViewController not available. Trying InAppBrowser as fallback.');
          // Fallback to InAppBrowser if SafariViewController is not available
          openPdfInAppBrowser(pdfUrl);
        }
      });
    } else {
      // This block executes if 'window.SafariViewController' was undefined initially.
      console.warn('Cordova SafariViewController plugin not found. Ensure it is installed and deviceready has fired.');
      setMessage('SafariViewController plugin not available. Trying InAppBrowser as fallback.');
      // Fallback to InAppBrowser if the plugin itself is not on the window object
      openPdfInAppBrowser(pdfUrl);
    }
  };

  const samplePdfUrl: string = 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf';

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif', textAlign: 'center' }}>
      <h2 style={{ color: '#333' }}>Cordova PDF Viewer (TSX)</h2>
      <p style={{ color: '#555', minHeight: '40px', border: '1px solid #eee', padding: '10px', background: '#f9f9f9', margin: '10px 0' }}>
        Status: {message || 'Waiting for action...'}
      </p>
      <button
        onClick={() => openPdfInAppBrowser(samplePdfUrl)}
        style={{
          backgroundColor: '#007bff',
          color: 'white',
          padding: '12px 20px',
          border: 'none',
          borderRadius: '5px',
          fontSize: '16px',
          cursor: 'pointer',
          margin: '5px'
        }}
      >
        Open PDF (InAppBrowser)
      </button>
      <button
        onClick={() => openPdfInSafariView(samplePdfUrl)}
        style={{
          backgroundColor: '#28a745',
          color: 'white',
          padding: '12px 20px',
          border: 'none',
          borderRadius: '5px',
          fontSize: '16px',
          cursor: 'pointer',
          margin: '5px'
        }}
      >
        Open PDF (SafariVC/CustomTabs)
      </button>
      <div style={{ marginTop: '20px', fontSize: '12px', color: '#777' }}>
        <p><strong>Instructions:</strong></p>
        <ol style={{ textAlign: 'left', display: 'inline-block' }}>
          <li>Ensure Cordova plugins are installed:
            <ul>
              <li>`cordova plugin add cordova-plugin-inappbrowser`</li>
              <li>`cordova plugin add cordova-plugin-safariviewcontroller`</li>
            </ul>
          </li>
          <li>Wait for `deviceready` before calling plugin functions.</li>
          <li>Click a button above to open the PDF.</li>
          <li>SafariViewController/Chrome Custom Tabs are generally preferred for web content.</li>
        </ol>
      </div>
    </div>
  );
};

export default MyPdfViewerComponent;

// --- How to integrate this component ---
// 1. Save this code as MyPdfViewerComponent.tsx in your React project's components folder.
// 2. Import and use it in your App.tsx or another relevant component.
//    Example:
//    import MyPdfViewerComponent from './components/MyPdfViewerComponent';
//    function App() {
//      return (
//        <div className="App">
//          <MyPdfViewerComponent />
//        </div>
//      );
//    }
//    export default App;

// --- Crucial: Cordova Initialization (typically in index.tsx or App.tsx of your React app) ---
/*
import ReactDOM from 'react-dom/client'; // Or 'react-dom' for older React versions
import App from './App'; // Assuming your main App component

const rootElement = document.getElementById('root');

const renderApp = () => {
  if (rootElement) {
    const root = ReactDOM.createRoot(rootElement); // For React 18+
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    );
  }
};

if (window.cordova) {
  document.addEventListener('deviceready', () => {
    console.log('Device is ready! Initializing React app within Cordova.');
    renderApp();
  }, false);
} else {
  console.log('Not in Cordova environment. Rendering React app directly.');
  renderApp();
}
*/
