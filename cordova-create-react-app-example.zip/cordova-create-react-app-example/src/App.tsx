import React from 'react';
import logo from './logo.svg';
import './App.css';
import { EmbedPDF } from '@simplepdf/react-embed-pdf';
import PdfViewer from './PdfViewer';
import PdfBlobViewer from './PdfBlobViewer';
import MyPdfBlobViewerComponent from './MyPdfBlobViewerComponent';
import PdfErrorBoundary from './PdfErrorBoundary'; // Import the Error Boundary

function App() {
  return (
    <div className="App">
      <header className="App-header">
        {/* <img src={logo} className="App-logo" alt="logo" /> */}
        {/* Wrap PdfViewer with the Error Boundary */}
        <PdfErrorBoundary
           // Optional: Provide a custom fallback UI component or element
           // fallback={<h2>Oops! PDF failed to load. Please try again later.</h2>}
        >
          {/* <PdfBlobViewer /> */}
          <MyPdfBlobViewerComponent />
        </PdfErrorBoundary>
      </header>
    </div>
  );
}

export default App;
