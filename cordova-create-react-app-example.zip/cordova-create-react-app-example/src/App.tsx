import React from 'react';
import logo from './logo.svg';
import './App.css';
import { EmbedPDF } from '@simplepdf/react-embed-pdf';
import PdfViewer from './PdfViewer';
import PdfBlobViewer from './PdfBlobViewer';
import PdfErrorBoundary from './PdfErrorBoundary'; // Import the Error Boundary

function App() {
  return (
    <div className="App">
      <header className="App-header">
        {/* <img src={logo} className="App-logo" alt="logo" /> */}
        
        {/* // The PDF is displayed using the viewer: all editing features are disabled
        <EmbedPDF
          companyIdentifier="react-viewer"
          mode="inline"
          style={{ width: 900, height: 800 }}
          documentURL="https://cdn.simplepdf.com/simple-pdf/assets/sample.pdf"
        />; */}
        {/* Wrap PdfViewer with the Error Boundary */}
        <PdfErrorBoundary
           // Optional: Provide a custom fallback UI component or element
           // fallback={<h2>Oops! PDF failed to load. Please try again later.</h2>}
        >
          <PdfBlobViewer />
        </PdfErrorBoundary>
      </header>
    </div>
  );
}

export default App;
