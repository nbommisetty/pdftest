// src/polyfills.ts

// --- TypeScript Declaration Augmentation ---
// This block tells TypeScript that the global PromiseConstructor interface
// might have a 'withResolvers' method, even if the default TS libs don't include it.
// This resolves the TS2339 error at compile time.
declare global {
  interface PromiseConstructor {
    /**
     * Creates a new Promise and returns it in an object structured like
     * `{ promise, resolve, reject }`, allowing access to the resolve and
     * reject functions. Conforms to the standard Promise.withResolvers() specification.
     */
    withResolvers<T>(): {
      promise: Promise<T>;
      resolve: (value: T | PromiseLike<T>) => void;
      reject: (reason?: any) => void;
    };
  }
}
// --- End Declaration Augmentation ---


/**
 * Runtime Polyfill for Promise.withResolvers
 * This ensures the function exists in older JavaScript environments
 * like potentially outdated WebViews in Cordova apps.
 * It checks if the function exists and adds it if it doesn't.
 */
if (typeof Promise.withResolvers !== 'function') {
  console.log("Applying runtime polyfill for Promise.withResolvers..."); // Log message added
  Promise.withResolvers = function <T>() { // Added generic type <T>
    let resolve: (value: T | PromiseLike<T>) => void; // Typed resolve
    let reject: (reason?: any) => void; // Typed reject
    const promise = new Promise<T>((res, rej) => {
      resolve = res;
      reject = rej;
    });

    // Ensure resolve and reject are assigned before returning
    // Using non-null assertions as they are assigned within the Promise constructor sync path
    return { promise, resolve: resolve!, reject: reject! };
  };
} else {
  // Optional: Log if the polyfill is not needed
  // console.log("Promise.withResolvers already exists. Polyfill not needed.");
}

// You can add other polyfills to this file as needed.


// Add an empty export statement to satisfy the --isolatedModules flag.
// This tells TypeScript to treat this file as a module, even though
// it doesn't export any specific values.
export {};

